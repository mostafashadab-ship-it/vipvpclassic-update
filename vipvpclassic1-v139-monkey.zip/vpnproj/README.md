# vipvpclassic1 Android VPN source (v64)

GitHub Actions starter based on the supplied Android project.

- Minimum Android: 10 / API 29
- Two connect buttons on the main screen, both using the same User ID / password:
  - **IKEv2 (Android 14+)** - Android's built-in IKEv2 client, unchanged.
  - **L2TP (Android 10+)** - L2TP/IPsec (PSK) client built into the app (IKEv1 + NAT-T ESP + L2TPv2 + PPP,
    code in `app/src/main/java/com/example/myvpn/l2tp/`, service in `L2tpVpnService.kt`). It picks the best
    server automatically: all servers are probed with a real IKE packet and the fastest answer is tried first.
- L2TP servers and the IPsec PSK (`123456`) are in `L2tpProfileConfig.kt` / `L2tpServerPresets.kt`.
- No WireGuard.
- Version: versionCode 64 / versionName 64.0

## Notes
- The L2TP engine could not be tested against the real servers when this version was prepared (it was only
  compiled and checked with RFC test vectors). After installing, check Settings > Error log if it does not connect.
- The quick-settings tile now lights up only for this app's own VPN (it used to light up for any VPN).
- IKEv2 per-server wait time was raised from 10 s to 25 s (slow WiFi handshakes were cancelled too early).
- No MPPE encryption in L2TP (the IPsec layer already encrypts the traffic).

## Build
Upload the contents of the `vpnproj` folder to the root of a GitHub repository (the `app` folder must be in the root),
open the **Actions** tab and run **Android build**. The APK is in the run's **Artifacts**.
