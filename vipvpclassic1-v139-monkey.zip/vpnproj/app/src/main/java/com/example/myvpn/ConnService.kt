package com.example.myvpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.ConnectivityManager
import android.net.Ikev2VpnProfile
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnManager
import android.os.Build
import android.os.IBinder
import android.service.quicksettings.TileService
import kotlin.concurrent.thread

class ConnService : Service() {

    companion object {
        const val ACTION_STATE = "com.example.myvpn.STATE"
        const val ACTION_CONNECT = "com.example.myvpn.CONNECT"
        const val ACTION_DISCONNECT = "com.example.myvpn.DISCONNECT"
        const val ACTION_TOGGLE = "com.example.myvpn.TOGGLE"
        const val EXTRA_HOST = "host"
        const val EXTRA_FALLBACK = "fallback_l2tp" // Android 14+ auto button: if every IKEv2 server fails, continue with Cisco / L2TP

        // Max time (ms) to wait for one server to answer before trying the next.
        // 10 s was too short on WiFi (first IKE packets are often slower there) and the attempt was
        // cancelled in the middle of a working handshake.
        const val SERVER_WAIT_MS = 25_000
        // Auto mode: a server that has not brought the tunnel up after this long is skipped, next one is tried.
        const val AUTO_SERVER_WAIT_MS = 4_000

        // True while the service is alive. Used by the app to detect a stale "Connecting" state.
        @Volatile var running = false

        // All saved servers, one per line.
        fun loadHosts(prefs: SharedPreferences): List<String> =
            (prefs.getString("hosts", "") ?: "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }

        // Remembers resolved addresses for 5 minutes so repeated pings are fast.
        private val dnsCache = java.util.concurrent.ConcurrentHashMap<String, Pair<java.net.InetAddress, Long>>()

        private fun connectTime(addr: java.net.InetAddress, port: Int, net: Network?): Long {
            val t0 = System.nanoTime()
            return try {
                java.net.Socket().use {
                    // While a VPN is on, measure over the real network, not through the tunnel.
                    try { net?.bindSocket(it) } catch (_: Throwable) {}
                    it.connect(java.net.InetSocketAddress(addr, port), 1200)
                }
                (System.nanoTime() - t0) / 1_000_000
            } catch (e: java.net.ConnectException) {
                // "refused" still means the host answered
                if (e.message?.contains("refused", true) == true) (System.nanoTime() - t0) / 1_000_000 else -1
            } catch (e: Exception) {
                -1
            }
        }

        // Measures TCP connect time to the server in ms. Returns -1 if no response.
        // Ports 443 and 80 are tried at the same time. Note: this only measures
        // reachability/latency to the server, not VPN speed.
        fun tcpPing(host: String, net: Network? = null): Long {
            return try {
                val now = System.currentTimeMillis()
                val cached = dnsCache[host]?.takeIf { now - it.second < 300_000 }?.first
                val addr: java.net.InetAddress = if (cached != null) {
                    cached
                } else {
                    val resolved: java.net.InetAddress = Dns.resolve4(host, net)
                        ?: (if (net != null) net.getAllByName(host) else java.net.InetAddress.getAllByName(host)).first()
                    dnsCache[host] = Pair(resolved, now)
                    resolved
                }
                val results = LongArray(2) { -1 }
                val ports = intArrayOf(443, 80)
                ports.mapIndexed { i, port -> thread { results[i] = connectTime(addr, port, net) } }
                    .forEach { it.join() }
                val ok = results.filter { it >= 0 }
                if (ok.isEmpty()) {
                    dnsCache.remove(host)
                    -1
                } else {
                    ok.minOrNull() ?: -1
                }
            } catch (e: Exception) {
                dnsCache.remove(host)
                -1
            }
        }

        fun buildProfile(host: String, user: String, pass: String, psk: String, mtu: Int): Ikev2VpnProfile {
            val b = Ikev2VpnProfile.Builder(host, user)
            if (psk.isNotEmpty()) {
                b.setAuthPsk(psk.toByteArray())
            } else {
                b.setAuthUsernamePassword(user, pass, null)
            }
            // Android requires Max MTU >= 1280
            b.setMaxMtu(mtu.coerceIn(1280, 1500))
            if (Build.VERSION.SDK_INT >= 33) {
                // These two methods only exist on Android 13+ (API 33).
                try {
                    b.setAutomaticNattKeepaliveTimerEnabled(true)
                } catch (_: Throwable) {
                }
                try {
                    b.setAutomaticIpVersionSelectionEnabled(true)
                } catch (_: Throwable) {
                }
            }
            return b.build()
        }
    }

    @Volatile private var vpnUp = false
    @Volatile private var vpnNet: Network? = null
    @Volatile private var busy = false
    @Volatile private var cancel = false
    @Volatile private var stopped = false
    @Volatile private var userStop = false
    @Volatile private var upSince = 0L
    // Server we are connected to, and how many unexpected drops in a row were already answered by an
    // automatic reconnect (reset when a connection stays up for a while).
    @Volatile private var lastHost = ""
    @Volatile private var autoDrops = 0
    @Volatile private var fallbackL2 = false
    @Volatile private var handedOff = false // the L2TP service took over: do not touch the VPN on destroy
    @Volatile private var lastOnly: String? = null // server picked by hand (stays the only one on reconnect)
    private var state = "Disconnected"
    // Use Any to avoid class-loading VpnManager on Android 10 (API 29)
    private var vpnManager: Any? = null
    private lateinit var cm: ConnectivityManager

    private val callback = object : ConnectivityManager.NetworkCallback() {
        // Only count VPNs created by this app (ignore strongSwan and other VPN apps).
        private val own = HashSet<Network>()

        override fun onCapabilitiesChanged(network: Network, nc: NetworkCapabilities) {
            if (stopped) return
            val mine = Build.VERSION.SDK_INT < 31 || nc.ownerUid == android.os.Process.myUid()
            if (!mine) return
            // Require INTERNET so a half-open / failed IKE tunnel is not treated as Connected.
            // This is the main cause of "WiFi icon gone but no internet" on some routers.
            if (!nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return
            val isNew = synchronized(own) { own.add(network) }
            vpnNet = network
            vpnUp = true
            if (isNew) upSince = System.currentTimeMillis()
            if (isNew && !busy) setState("Connected")
        }

        override fun onLost(network: Network) {
            val wasMine = synchronized(own) { own.remove(network) }
            if (!wasMine) return
            if (vpnNet == network) vpnNet = null
            vpnUp = synchronized(own) { own.isNotEmpty() }
            if (!vpnUp && !busy) {
                if (!userStop && upSince > 0) {
                    val secs = (System.currentTimeMillis() - upSince) / 1000
                    ConnLog.log(this@ConnService, "dropped after " + secs + "s")
                    setDetail("dropped:$secs")
                    // Dropping again and again right after connecting usually means the
                    // server is rejecting the account (days/volume finished) -> announce it.
                    var giveUp = false
                    if (secs < 45) {
                        val p = getSharedPreferences("servers", MODE_PRIVATE)
                        val q = p.getInt("quick_drops", 0) + 1
                        p.edit().putInt("quick_drops", q).apply()
                        if (q >= 3) {
                            setDetail("quota:")
                            alertExpired()
                            giveUp = true
                        }
                    }
                    if (secs >= 30) autoDrops = 0
                    autoDrops++
                    // Auto failover: reconnect at once to ANOTHER server instead of staying disconnected.
                    if (!giveUp && autoDrops <= 6 && !stopped) {
                        val failed = lastHost
                        ConnLog.log(this@ConnService, "auto reconnect #" + autoDrops + " (dropped " + failed + ")")
                        connect(lastOnly, failed)
                        return
                    }
                }
                setState("Disconnected")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val ch = NotificationChannel("vpn_status", "VPN status", NotificationManager.IMPORTANCE_DEFAULT).apply {
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
                NotificationChannel("alerts", "Alerts", NotificationManager.IMPORTANCE_HIGH)
            )

            running = true
            ConnLog.log(this, "service created (API " + Build.VERSION.SDK_INT + ")")
            goForeground()

            if (Build.VERSION.SDK_INT < 34) {
                // Product policy: IKEv2 only on Android 14+. Use the L2TP button on older Android.
                setState("Error: IKEv2 requires Android 14+ (use L2TP)")
                return
            }

            vpnManager = getSystemService(Context.VPN_MANAGEMENT_SERVICE)
            val req = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_VPN)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                .build()
            try {
                cm.registerNetworkCallback(req, callback)
            } catch (_: Exception) {
            }
        } catch (e: Exception) {
            try {
                setState("Error: onCreate " + e.javaClass.simpleName + ": " + (e.message ?: ""))
            } catch (_: Exception) {
            }
        }
    }

    // Tries several foreground types; never leaves the service without startForeground()
    // (that would crash the app with "did not call startForeground").
    private fun goForeground() {
        val attempts = ArrayList<() -> Unit>()
        if (Build.VERSION.SDK_INT >= 34) {
            attempts.add {
                startForeground(
                    1, buildNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
            }
            attempts.add { startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) }
            attempts.add { startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) }
        }
        attempts.add { startForeground(1, buildNotification()) }
        var last: Throwable? = null
        for (a in attempts) {
            try {
                a()
                return
            } catch (e: Throwable) {
                last = e
            }
        }
        // Could not become a foreground service: report why and stop cleanly.
        try {
            val msg = (last?.javaClass?.simpleName ?: "?") + ": " + (last?.message ?: "")
            getSharedPreferences("servers", MODE_PRIVATE).edit()
                .putString("state", "Error: foreground $msg").putString("detail", "err:$msg").apply()
            sendBroadcast(Intent(ACTION_STATE).setPackage(packageName))
        } catch (_: Throwable) {
        }
        stopped = true
        stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            if (intent?.action == ACTION_CONNECT || intent?.action == ACTION_TOGGLE) {
                // The service may be reused right after a shutdown; make sure it is foreground again.
                stopped = false
                goForeground()
            }
            when (intent?.action) {
                ACTION_CONNECT -> {
                    fallbackL2 = intent.getBooleanExtra(EXTRA_FALLBACK, false)
                    handedOff = false
                    val want = intent.getStringExtra(EXTRA_HOST)
                    if (busy) {
                        // A connection attempt is still running (e.g. the user tapped another server).
                        // Old behaviour: the new request was ignored and the old row stayed stuck on
                        // "Connecting". Now: cancel the running attempt, wait for it to finish, then start.
                        ConnLog.log(this, "switch request while busy -> " + (want ?: "auto"))
                        cancel = true
                        thread {
                            var w = 0
                            while (busy && w < 10_000) { Thread.sleep(100); w += 100 }
                            if (!stopped) connect(want)
                        }
                    } else {
                        connect(want)
                    }
                }
                ACTION_DISCONNECT -> disconnect()
                ACTION_TOGGLE -> if (busy || vpnUp) disconnect() else { fallbackL2 = Build.VERSION.SDK_INT >= 34; handedOff = false; connect(null) }
                else -> updateNotification()
            }
        } catch (e: Throwable) {
            try {
                setState("Error: " + e.javaClass.simpleName + ": " + (e.message ?: ""))
            } catch (_: Exception) {
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        cancel = true
        stopped = true
        if (!handedOff) stopQuietly()
        try {
            if (!handedOff) (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(1)
        } catch (_: Exception) {
        }
        try {
            cm.unregisterNetworkCallback(callback)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    // ---------- connection ----------
    // only = a specific server chosen by the user. null = test all and pick the best.
    private fun connect(only: String?, avoid: String? = null) {
        if (busy) return
        if (Build.VERSION.SDK_INT < 34) {
            setState("Error: IKEv2 requires Android 14+ (use L2TP)")
            return
        }
        busy = true
        cancel = false
        userStop = false
        if (avoid == null) { lastOnly = only; autoDrops = 0 }
        if (avoid == null) setDetail("")
        thread {
            try {
                ConnLog.log(this, "connect start only=" + only + " underlying=" + underlyingName())
                setState(if (only != null) "Connecting: $only" else "Testing servers...")
                stopQuietly()
                waitDown()
                if (avoid != null) waitForNetwork(10_000)

                val prefs = getSharedPreferences("servers", MODE_PRIVATE)
                val hosts = if (only != null) listOf(only) else loadHosts(prefs)
                if (hosts.isEmpty()) {
                    setState("Add a server first")
                    return@thread
                }
                val user = prefs.getString("user", "") ?: ""
                val pass = prefs.getString("pass", "") ?: ""
                val mtu = prefs.getString("mtu", "1280")?.toIntOrNull() ?: 1280

                val order = if (hosts.size == 1) {
                    hosts
                } else {
                    val pings = HashMap<String, Long>()
                    hosts.map { h ->
                        thread {
                            val t = ping(h)
                            synchronized(pings) { pings[h] = t }
                        }
                    }.forEach { it.join() }
                    val sorted = hosts.sortedBy { pings[it] ?: Long.MAX_VALUE }
                    // After a drop, the server that just failed is tried last.
                    if (avoid != null) sorted.filter { it != avoid } + sorted.filter { it == avoid }
                    else InstagramProbe.prefer(sorted, prefs) { (pings[it] ?: -1L) in 0..99_999L }
                }

                val mgr = vpnManager as? VpnManager
                if (mgr == null) {
                    setState("Error: IKEv2 requires Android 14+ (use L2TP)")
                    return@thread
                }

                // Auto mode: prefer the server that opens Instagram (see InstagramProbe).
                var plan = order
                var probing = only == null && avoid == null && hosts.size > 1
                var igTries = 0
                // Auto mode gives each server only a short time; a manually picked server keeps the long wait.
                val waitMs = if (only == null) AUTO_SERVER_WAIT_MS else SERVER_WAIT_MS
                var fallback: String? = null
                var idx = 0
                while (idx < plan.size) {
                    val host = plan[idx++]
                    if (cancel) break
                    setState("Connecting: $host")
                    ConnLog.log(this, "try " + host)
                    val profile = buildProfile(host, user, pass, "", mtu)
                    val consent = try {
                        mgr.provisionVpnProfile(profile)
                    } catch (e: SecurityException) {
                        ConnLog.log(this, "provision SecurityException: " + (e.message ?: ""))
                        setDetail("err:" + (e.message ?: "SecurityException"))
                        continue
                    }
                    if (consent != null) {
                        ConnLog.log(this, "consent needed")
                        setState("Permission needed: open the app and tap Connect")
                        return@thread
                    }
                    try {
                        mgr.startProvisionedVpnProfile()
                    } catch (e: SecurityException) {
                        ConnLog.log(this, "start SecurityException: " + (e.message ?: ""))
                        setDetail("err:" + (e.message ?: "SecurityException"))
                        stopQuietly()
                        waitDown()
                        continue
                    }
                    // Wait (max SERVER_WAIT_MS) for the VPN network to come up with INTERNET.
                    // On Android 11-13 the first start call is sometimes ignored; issue it once more.
                    var waited = 0
                    var retried = false
                    while (waited < waitMs && !vpnUp && !cancel) {
                        Thread.sleep(500)
                        waited += 500
                        if (!retried && waited >= 3000 && Build.VERSION.SDK_INT <= 33 && !vpnUp) {
                            retried = true
                            ConnLog.log(this, "retry startProvisionedVpnProfile (API " + Build.VERSION.SDK_INT + ")")
                            try { mgr.startProvisionedVpnProfile() } catch (_: Exception) {}
                        }
                    }
                    if (vpnUp) {
                        ConnLog.log(this, "up after " + waited + "ms")
                        // Extra short settle so VALIDATED can appear (avoids false "Connected" on WiFi).
                        Thread.sleep(800)
                        if (vpnUp && !cancel && probing) {
                            igTries++
                            val ok = InstagramProbe.opens(vpnNet)
                            ConnLog.log(this, "instagram via " + host + " = " + ok)
                            if (ok) {
                                InstagramProbe.remember(prefs, host)
                                probing = false
                            } else {
                                if (fallback == null) fallback = host
                                if (igTries < InstagramProbe.MAX_TRIES && idx < plan.size) {
                                    stopQuietly()
                                    waitDown()
                                    continue
                                }
                                probing = false
                                if (fallback != host) {
                                    // No server opened Instagram: go back to the first one that connected.
                                    plan = listOf(fallback!!)
                                    idx = 0
                                    stopQuietly()
                                    waitDown()
                                    continue
                                }
                            }
                        }
                        if (vpnUp && !cancel) {
                            ConnLog.log(this, "connected " + host)
                            lastHost = host
                            setState("Connected: $host")
                            return@thread
                        }
                    }
                    if (!cancel) {
                        ConnLog.log(this, "no answer from " + host + " after " + (waitMs / 1000.0) + "s")
                        setDetail("noanswer:$host")
                    }
                    stopQuietly()
                    waitDown()
                }
                if (!cancel && !stopped && fallbackL2 && only == null && startL2tpFallback()) return@thread
                if (!cancel) {
                    ConnLog.log(this, "all servers failed")
                    setState("Failed: no server connected")
                    // No server answered: maybe the subscription (days / traffic) is finished.
                    alertExpired()
                }
            } catch (e: Throwable) {
                try { setDetail("err:" + e.javaClass.simpleName + ": " + (e.message ?: "")) } catch (_: Throwable) {}
                setState("Error: ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                busy = false
                if (!cancel && !stopped) updateNotification()
            }
        }
    }

    // Android 14+ auto button: IKEv2 first, then Cisco / L2TP. Hands the job to the L2TP service.
    private fun startL2tpFallback(): Boolean {
        try {
            if (android.net.VpnService.prepare(this) != null) {
                ConnLog.log(this, "fallback to L2TP skipped: VPN permission missing")
                return false
            }
            ConnLog.log(this, "IKEv2 failed on every server -> trying Cisco / L2TP")
            stopQuietly()
            getSharedPreferences("servers", MODE_PRIVATE).edit()
                .putString("mode", "l2tp").putString("state", "Testing servers...").putString("detail", "").apply()
            sendBroadcast(Intent(ACTION_STATE).setPackage(packageName))
            handedOff = true
            stopped = true // ignore IKEv2 network callbacks from now on
            startForegroundService(Intent(this, L2tpVpnService::class.java).setAction(L2tpVpnService.ACTION_CONNECT))
            Thread.sleep(1500)
            try { stopForeground(STOP_FOREGROUND_DETACH) } catch (_: Throwable) {}
            stopSelf()
            return true
        } catch (e: Throwable) {
            handedOff = false
            stopped = false
            getSharedPreferences("servers", MODE_PRIVATE).edit().putString("mode", "ikev2").apply()
            ConnLog.log(this, "fallback to L2TP failed: " + e.javaClass.simpleName + " " + (e.message ?: ""))
            return false
        }
    }

    // "wifi" / "cellular" / "other" - only used for the connection log.
    private fun underlyingName(): String = try {
        val nc = cm.getNetworkCapabilities(cm.activeNetwork)
        when {
            nc == null -> "none"
            nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "vpn"
            nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
            else -> "other"
        }
    } catch (_: Throwable) { "?" }

    private fun disconnect() {
        ConnLog.log(this, "user disconnect")
        autoDrops = 0
        cancel = true
        userStop = true
        setDetail("")
        stopQuietly()
        setState("Disconnected")
    }

    private fun stopQuietly() {
        if (Build.VERSION.SDK_INT < 30) return
        try {
            (vpnManager as? VpnManager)?.stopProvisionedVpnProfile()
        } catch (_: Exception) {
        }
    }

    // Waits (max maxMs) until a normal internet network (not a VPN) is available again.
    private fun waitForNetwork(maxMs: Int) {
        var w = 0
        while (w < maxMs && !cancel) {
            val ok = try {
                val nc = cm.getNetworkCapabilities(cm.activeNetwork)
                nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    !nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
            } catch (_: Throwable) { true }
            if (ok) return
            Thread.sleep(250); w += 250
        }
    }

    private fun waitDown() {
        var w = 0
        while (vpnUp && w < 3000) {
            Thread.sleep(250)
            w += 250
        }
    }

    // Short reason shown under the status in the app.
    private fun setDetail(d: String) {
        getSharedPreferences("servers", MODE_PRIVATE).edit().putString("detail", d).apply()
    }

    // Lower is better. Unreachable servers get a huge value.
    private fun ping(host: String): Long {
        val t = tcpPing(host)
        return if (t >= 0) t else 100_000L
    }

    // ---------- state + notification ----------
    private fun setState(s: String) {
        state = s
        ConnLog.log(this, "state=$s")
        if (s.startsWith("Connected")) {
            getSharedPreferences("servers", MODE_PRIVATE).edit().putInt("quick_drops", 0).apply()
        }
        val ed = getSharedPreferences("servers", MODE_PRIVATE).edit().putString("state", s)
        // Remember that IKEv2 is the protocol in use (only for real connection states).
        if (s.startsWith("Connecting") || s.startsWith("Testing") || s.startsWith("Connected")) ed.putString("mode", "ikev2")
        ed.apply()
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName))
        try {
            TileService.requestListeningState(this, ComponentName(this, VpnTile::class.java))
        } catch (_: Exception) {
        }
        val active = s.startsWith("Connecting") || s.startsWith("Testing") || s.startsWith("Connected")
        if (active) updateNotification() else shutdown()
    }

    // When the VPN is off, nothing stays in the notification bar.
    private fun shutdown() {
        stopped = true
        stopForeground(STOP_FOREGROUND_REMOVE)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(1)
        stopSelf()
    }

    private fun updateNotification() {
        if (stopped) return
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, buildNotification())
    }

    // Announces that the subscription (days or traffic volume) may have run out.
    private fun alertExpired() {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel("alerts", "Alerts", NotificationManager.IMPORTANCE_HIGH)
            )
            val open = PendingIntent.getActivity(
                this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val text = if (Lang.isFa(this)) {
                "اتصال برقرار نشد یا پیاپی قطع شد. اگر این وضعیت ادامه دارد، ممکن است روز یا حجم سرویس شما تمام شده باشد. با پشتیبانی تماس بگیرید."
            } else {
                "Could not connect or the connection kept dropping. If this continues, your service days or data volume may be finished. Contact support."
            }
            nm.notify(2, Notification.Builder(this, "alerts")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("vipvpclassic1")
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(open)
                .build())
            ConnLog.log(this, "alert: service may be expired")
        } catch (_: Throwable) {
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val toggle = try {
            PendingIntent.getForegroundService(
                this, 1,
                Intent(this, ConnService::class.java).setAction(ACTION_TOGGLE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        } catch (_: Exception) {
            PendingIntent.getService(
                this, 1,
                Intent(this, ConnService::class.java).setAction(ACTION_TOGGLE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_lock_power_off),
            if (Lang.isFa(this)) "قطع اتصال" else "Disconnect",
            toggle
        ).build()
        val b = Notification.Builder(this, "vpn_status")
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("IKEv2")
            .setContentText(Lang.state(this, state))
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(action)
            .setOnlyAlertOnce(true)
        // Android 12+ delays foreground-service notifications by ~10 s unless this is set.
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        return b.build()
    }
}
