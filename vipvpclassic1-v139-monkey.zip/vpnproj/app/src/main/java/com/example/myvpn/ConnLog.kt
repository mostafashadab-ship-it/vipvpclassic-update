package com.example.myvpn

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Ring-buffer connection log. Shown in Settings > Error log so the user can see
// exactly why the VPN did or did not connect. Keeps the last 200 lines.
object ConnLog {
    private const val MAX_LINES = 200
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US)

    @Synchronized
    fun log(ctx: Context, msg: String) {
        try {
            val f = File(ctx.filesDir, "conn.log")
            val old = if (f.exists()) f.readLines().filter { it.isNotEmpty() } else emptyList()
            val line = fmt.format(Date()) + "  " + msg
            f.writeText(old.plus(line).takeLast(MAX_LINES).joinToString("\n") + "\n")
        } catch (_: Throwable) {
        }
    }

    fun read(ctx: Context): String = try {
        File(ctx.filesDir, "conn.log").takeIf { it.exists() }?.readText() ?: ""
    } catch (_: Throwable) { "" }

    fun clear(ctx: Context) {
        try { File(ctx.filesDir, "conn.log").delete() } catch (_: Throwable) {}
    }
}
