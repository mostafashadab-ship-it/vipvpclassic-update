package com.example.myvpn.l2tp

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * One ESP security association pair (transport mode, UDP-encapsulated on port 4500).
 * Plaintext handed to [seal] is a complete UDP datagram (next header 17).
 */
class EspSa(
    val spiOut: Int,
    val spiIn: Int,
    val des3: Boolean,
    val encKeyOut: ByteArray,
    val encKeyIn: ByteArray,
    val macName: String,
    val authKeyOut: ByteArray,
    val authKeyIn: ByteArray,
    val icvLen: Int
) {
    private val blockSize = if (des3) 8 else 16
    private var seq = 0L
    private val macOut = Mac.getInstance(macName).also { it.init(SecretKeySpec(authKeyOut, macName)) }
    private val macIn = Mac.getInstance(macName).also { it.init(SecretKeySpec(authKeyIn, macName)) }

    @Synchronized
    fun seal(payload: ByteArray, nextHeader: Int = 17): ByteArray {
        seq++
        val padLen = (blockSize - ((payload.size + 2) % blockSize)) % blockSize
        val plain = W().b(payload)
        for (i in 1..padLen) plain.u8(i)
        plain.u8(padLen).u8(nextHeader)
        val iv = Crypto.random(blockSize)
        val ct = Crypto.cbc(true, des3, encKeyOut, iv, plain.bytes())
        val head = W().u32(spiOut).u32(seq).b(iv).b(ct).bytes()
        macOut.reset()
        val icv = macOut.doFinal(head)
        return head + icv.copyOf(icvLen)
    }

    /** Returns the decrypted inner payload (padding removed), or null if invalid. */
    @Synchronized
    fun open(pkt: ByteArray, off: Int = 0, len: Int = pkt.size - off): ByteArray? {
        if (len < 8 + blockSize + blockSize + icvLen) return null
        if (be32(pkt, off).toInt() != spiIn) return null
        val bodyLen = len - icvLen
        macIn.reset()
        macIn.update(pkt, off, bodyLen)
        val icv = macIn.doFinal().copyOf(icvLen)
        var diff = 0
        for (i in 0 until icvLen) diff = diff or (icv[i].toInt() xor pkt[off + bodyLen + i].toInt())
        if (diff != 0) return null
        val iv = pkt.copyOfRange(off + 8, off + 8 + blockSize)
        val ct = pkt.copyOfRange(off + 8 + blockSize, off + bodyLen)
        if (ct.isEmpty() || ct.size % blockSize != 0) return null
        val plain = try { Crypto.cbc(false, des3, encKeyIn, iv, ct) } catch (e: Exception) { return null }
        val padLen = plain[plain.size - 2].toInt() and 0xFF
        if (padLen + 2 > plain.size) return null
        return plain.copyOf(plain.size - 2 - padLen)
    }
}

/** UDP header helpers for the transport-mode inner datagram (L2TP uses 1701 <-> 1701). */
object Udp {
    fun build(srcPort: Int, dstPort: Int, payload: ByteArray): ByteArray =
        W().u16(srcPort).u16(dstPort).u16(payload.size + 8).u16(0).b(payload).bytes()
}
