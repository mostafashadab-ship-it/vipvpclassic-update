package com.example.myvpn.l2tp

/**
 * L2TPv2 control/data channel (RFC 2661, we act as the LAC making an incoming call) plus a small PPP
 * implementation: LCP, PAP / CHAP-MD5 / MS-CHAPv2, IPCP. Everything is event driven; [onPacket] is called
 * with every L2TP payload that arrived over ESP and [tick] about twice a second.
 * MPPE/CCP is not supported: a CCP request from the server is rejected.
 */
class L2tpPpp(
    private val user: String,
    private val pass: String,
    private val sendUdp: (ByteArray) -> Unit,
    private val onIp: (ByteArray) -> Unit,
    private val onUp: () -> Unit,
    private val log: (String) -> Unit
) {
    private val lock = Any()

    @Volatile var failure: String? = null
    @Volatile var up = false
    @Volatile var authOk = false
    var ourIp = ByteArray(4); var peerIp = ByteArray(4)
    var dns1 = ByteArray(4); var dns2 = ByteArray(4)
    var mtu = 1280

    // ---------- L2TP state ----------
    private val ourTid = 1 + Crypto.rnd.nextInt(60000)
    private val ourSid = 1 + Crypto.rnd.nextInt(60000)
    private var peerTid = 0
    private var peerSid = 0
    private var ns = 0
    private var nrExpected = 0
    private class Pending(val sid: Int, val avps: ByteArray, var ns: Int = 0, var sentAt: Long = 0, var tries: Int = 0)
    private val outQ = ArrayList<Pending>()
    private var inFlight: Pending? = null
    private var pppStartAfterAck = false
    private var lastRx = System.currentTimeMillis()
    private var lastHello = System.currentTimeMillis()
    private var lastEcho = System.currentTimeMillis()

    private fun avp(type: Int, value: ByteArray) = W().u16(0x8000 or (6 + value.size)).u16(0).u16(type).b(value).bytes()
    private fun msgType(t: Int) = avp(0, W().u16(t).bytes())

    fun start() = synchronized(lock) {
        val a = W().b(msgType(1))
            .b(avp(2, byteArrayOf(1, 0)))
            .b(avp(3, W().u32(3).bytes()))
            .b(avp(7, "android".toByteArray()))
            .b(avp(9, W().u16(ourTid).bytes()))
            .b(avp(10, W().u16(4).bytes()))
            .bytes()
        enqueue(0, a)
        log("L2TP: SCCRQ")
    }

    private fun enqueue(sid: Int, avps: ByteArray) {
        outQ.add(Pending(sid, avps))
        pump()
    }

    private fun controlPacket(sid: Int, nsv: Int, avps: ByteArray): ByteArray =
        W().u16(0xC802).u16(12 + avps.size).u16(peerTid).u16(sid).u16(nsv).u16(nrExpected).b(avps).bytes()

    private fun pump() {
        if (inFlight != null || outQ.isEmpty()) return
        val p = outQ.removeAt(0)
        p.ns = ns
        ns = (ns + 1) and 0xFFFF
        p.sentAt = System.currentTimeMillis()
        p.tries = 1
        inFlight = p
        sendUdp(controlPacket(p.sid, p.ns, p.avps))
    }

    private fun sendZlb() {
        sendUdp(controlPacket(0, ns, ByteArray(0)))
    }

    private fun sendData(ppp: ByteArray) {
        if (peerSid == 0) return
        sendUdp(W().u16(0x4002).u16(8 + ppp.size).u16(peerTid).u16(peerSid).b(ppp).bytes())
    }

    fun fail(msg: String) {
        if (failure == null) { failure = msg; log("FAIL: $msg") }
    }

    // ---------- inbound ----------
    fun onPacket(d: ByteArray) = synchronized(lock) {
        try { handle(d) } catch (e: Exception) { log("L2TP rx error: " + e.javaClass.simpleName + " " + e.message) }
    }

    private fun handle(d: ByteArray) {
        if (d.size < 6) return
        lastRx = System.currentTimeMillis()
        val r = R(d)
        val flags = r.u16()
        if ((flags and 0x0F) != 2) return
        val isCtl = flags and 0x8000 != 0
        if (flags and 0x4000 != 0) r.u16() // length
        val tid = r.u16(); val sid = r.u16()
        var nsR = 0; var nrR = 0
        if (flags and 0x0800 != 0) { nsR = r.u16(); nrR = r.u16() }
        if (flags and 0x0200 != 0) { val o = r.u16(); r.b(o) }
        if (!isCtl) {
            if (tid != ourTid) return
            handlePpp(r.rest())
            return
        }
        // A late message of an older tunnel (same server address, e.g. right after a quick reconnect) must
        // not close this new tunnel.
        if (peerTid != 0 && tid != 0 && tid != ourTid) return
        // ack processing
        val f = inFlight
        if (f != null && nrR == ((f.ns + 1) and 0xFFFF)) {
            inFlight = null
            if (pppStartAfterAck && outQ.isEmpty()) { pppStartAfterAck = false; startPpp() }
        }
        if (r.left() == 0) { pump(); return } // ZLB
        if (nsR != nrExpected) { sendZlb(); return } // duplicate or out of order
        nrExpected = (nrExpected + 1) and 0xFFFF
        val before = ns
        var msg = -1
        val avps = HashMap<Int, ByteArray>()
        while (r.left() >= 6) {
            val fl = r.u16()
            val len = fl and 0x03FF
            r.u16()
            val type = r.u16()
            val v = r.b(len - 6)
            if (fl and 0x4000 != 0) continue // hidden AVP, we never negotiate it
            avps[type] = v
            if (type == 0 && v.size >= 2) msg = be16(v, 0)
        }
        when (msg) {
            2 -> { // SCCRP
                peerTid = avps[9]?.let { be16(it, 0) } ?: 0
                log("L2TP: SCCRP tunnel=$peerTid")
                val a = W().b(msgType(3))
                avps[11]?.let { ch ->
                    a.b(avp(13, Crypto.hash("MD5", byteArrayOf(3), ch)))
                }
                enqueue(0, a.bytes())
                enqueue(0, W().b(msgType(10)).b(avp(14, W().u16(ourSid).bytes()))
                    .b(avp(15, W().u32(Crypto.rnd.nextInt()).bytes())).bytes())
            }
            11 -> { // ICRP
                peerSid = avps[14]?.let { be16(it, 0) } ?: 0
                log("L2TP: ICRP session=$peerSid")
                enqueue(peerSid, W().b(msgType(12)).b(avp(24, W().u32(10_000_000).bytes()))
                    .b(avp(19, W().u32(1).bytes())).bytes())
                pppStartAfterAck = true
            }
            4 -> fail("server closed the tunnel" + resultText(avps[1]))
            14 -> fail("server ended the call" + resultText(avps[1]))
            else -> {}
        }
        if (ns == before && inFlight == null) pump()
        if (ns == before) sendZlb()
    }

    private fun resultText(v: ByteArray?): String {
        if (v == null || v.size < 4) return ""
        val code = be16(v, 0); val err = be16(v, 2)
        val txt = if (v.size > 4) String(v, 4, v.size - 4, Charsets.UTF_8) else ""
        return " (result $code, error $err $txt)"
    }

    // ---------- timers ----------
    private var lastTick = System.currentTimeMillis()

    fun tick() = synchronized(lock) {
        val now = System.currentTimeMillis()
        // The loop runs every 250 ms. A long gap means the phone was asleep: that is not a dead link, so
        // restart the silence timer and ask the server right now.
        if (now - lastTick > 5000) { lastRx = now; lastEcho = 0 }
        lastTick = now
        val f = inFlight
        if (f != null && now - f.sentAt > 1000L * f.tries.coerceAtMost(4)) {
            if (f.tries >= 7) { fail("L2TP server does not answer"); return@synchronized }
            f.tries++
            f.sentAt = now
            sendUdp(controlPacket(f.sid, f.ns, f.avps))
        }
        if (lcpWaiting && now - lcpSentAt > 2000) { lcpTries++; if (lcpTries > 8) fail("PPP LCP timeout") else sendLcpReq() }
        if (ipcpWaiting && now - ipcpSentAt > 2000) { ipcpTries++; if (ipcpTries > 8) fail("PPP IPCP timeout") else sendIpcpReq() }
        if (!pppStarted && peerSid == 0 && failure == null && now - lastRx > 15000) fail("L2TP server does not answer")
        if (up) {
            if (now - lastEcho > 10000) {
                lastEcho = now
                sendCp(0xC021, 9, ++echoId and 0xFF, W().u32(ourMagic).bytes())
            }
            if (now - lastRx > 30000) fail("connection lost (no data for 30 s)")
        }
        if (peerSid != 0 && inFlight == null && now - lastHello > 60000) {
            lastHello = now
            enqueue(0, msgType(6))
        }
    }

    fun close() = synchronized(lock) {
        try {
            if (pppStarted) sendCp(0xC021, 5, 0x7F, ByteArray(0))
            if (peerSid != 0) sendUdp(controlPacket(peerSid, ns, W().b(msgType(14)).b(avp(1, W().u16(3).u16(0).bytes())).b(avp(14, W().u16(ourSid).bytes())).bytes()))
            if (peerTid != 0) sendUdp(controlPacket(0, ns, W().b(msgType(4)).b(avp(1, W().u16(1).u16(0).bytes())).b(avp(9, W().u16(ourTid).bytes())).bytes()))
        } catch (_: Exception) {}
    }

    // ================= PPP =================
    private var pppStarted = false
    private var echoId = 0

    // LCP
    private var ourMagic = 0
    private var ourMru = 1400
    private var useMru = true
    private var useMagic = true
    private var lcpId = 0
    private var lcpWaiting = false
    private var lcpSentAt = 0L
    private var lcpTries = 0
    private var ourLcpAcked = false
    private var peerLcpAcked = false
    private var lcpOpened = false
    private var authProto = 0      // 0 none, 0xC023 PAP, 0xC223 CHAP
    private var chapAlg = 0

    // IPCP
    private var ipcpId = 0
    private var ipcpWaiting = false
    private var ipcpSentAt = 0L
    private var ipcpTries = 0
    private var ipcpStarted = false
    private var ourIpcpAcked = false
    private var peerIpcpAcked = false
    private var reqIp = ByteArray(4); private var reqDns1 = ByteArray(4); private var reqDns2 = ByteArray(4)
    private var useDns1 = true; private var useDns2 = true

    // MS-CHAPv2 state for verifying the server's answer
    private var mschapNt: ByteArray? = null
    private var mschapPeerCh: ByteArray? = null
    private var mschapAuthCh: ByteArray? = null

    private fun startPpp() {
        pppStarted = true
        ourMagic = Crypto.rnd.nextInt()
        log("PPP: start")
        sendLcpReq()
    }

    private fun sendPpp(proto: Int, data: ByteArray) {
        sendData(W().u8(0xFF).u8(0x03).u16(proto).b(data).bytes())
    }

    private fun sendCp(proto: Int, code: Int, id: Int, data: ByteArray) {
        sendPpp(proto, W().u8(code).u8(id).u16(data.size + 4).b(data).bytes())
    }

    fun sendIp(pkt: ByteArray) = synchronized(lock) {
        if (up) sendData(W().u8(0xFF).u8(0x03).u16(0x0021).b(pkt).bytes())
    }

    private fun sendLcpReq() {
        lcpId = (lcpId + 1) and 0xFF
        val o = W()
        if (useMru) o.u8(1).u8(4).u16(ourMru)
        if (useMagic) o.u8(5).u8(6).u32(ourMagic)
        sendCp(0xC021, 1, lcpId, o.bytes())
        lcpWaiting = true; lcpSentAt = System.currentTimeMillis()
    }

    private fun sendIpcpReq() {
        ipcpId = (ipcpId + 1) and 0xFF
        val o = W().u8(3).u8(6).b(reqIp)
        if (useDns1) o.u8(0x81).u8(6).b(reqDns1)
        if (useDns2) o.u8(0x83).u8(6).b(reqDns2)
        sendCp(0x8021, 1, ipcpId, o.bytes())
        ipcpWaiting = true; ipcpSentAt = System.currentTimeMillis()
    }

    private class Opt(val type: Int, val data: ByteArray)

    private fun opts(d: ByteArray): List<Opt> {
        val out = ArrayList<Opt>()
        var p = 0
        while (p + 2 <= d.size) {
            val l = d[p + 1].toInt() and 0xFF
            if (l < 2 || p + l > d.size) break
            out.add(Opt(d[p].toInt() and 0xFF, d.copyOfRange(p + 2, p + l)))
            p += l
        }
        return out
    }

    private fun enc(o: Opt) = W().u8(o.type).u8(o.data.size + 2).b(o.data).bytes()

    private fun handlePpp(raw: ByteArray) {
        var p = 0
        if (raw.size >= 2 && raw[0] == 0xFF.toByte() && raw[1] == 0x03.toByte()) p = 2
        if (p >= raw.size) return
        var proto = raw[p].toInt() and 0xFF
        if (proto and 1 == 1) p += 1 else { if (p + 2 > raw.size) return; proto = (proto shl 8) or (raw[p + 1].toInt() and 0xFF); p += 2 }
        val body = raw.copyOfRange(p, raw.size)
        if (proto == 0x0021) { if (up) onIp(body); return }
        if (!pppStarted) return
        when (proto) {
            0xC021 -> handleLcp(body)
            0xC023 -> handlePap(body)
            0xC223 -> handleChap(body)
            0x8021 -> handleIpcp(body)
            0x80FD -> handleCcp(body)
            else -> {
                if (lcpOpened) {
                    sendCp(0xC021, 8, (++echoId) and 0xFF, W().u16(proto).b(body.copyOf(minOf(body.size, 64))).bytes())
                }
            }
        }
    }

    private fun parseCp(d: ByteArray): Triple<Int, Int, ByteArray>? {
        if (d.size < 4) return null
        val len = be16(d, 2)
        if (len < 4 || len > d.size) return null
        return Triple(d[0].toInt() and 0xFF, d[1].toInt() and 0xFF, d.copyOfRange(4, len))
    }

    // ---------- LCP ----------
    private fun handleLcp(d: ByteArray) {
        val (code, id, data) = parseCp(d) ?: return
        when (code) {
            1 -> { // Configure-Request from server
                val ack = ArrayList<Opt>(); val nak = ArrayList<Opt>(); val rej = ArrayList<Opt>()
                var newAuth = 0; var newAlg = 0
                for (o in opts(data)) {
                    when (o.type) {
                        1 -> { if (o.data.size == 2) { val m = be16(o.data, 0); if (m in 576..1500) mtu = minOf(mtu, maxOf(m, 1280)) }; ack.add(o) }
                        2, 7, 8 -> ack.add(o)
                        5 -> ack.add(o)
                        3 -> {
                            val pr = if (o.data.size >= 2) be16(o.data, 0) else 0
                            if (pr == 0xC023 && o.data.size == 2) { newAuth = pr; ack.add(o) }
                            else if (pr == 0xC223 && o.data.size == 3 && (o.data[2].toInt() and 0xFF) in intArrayOf(0x05, 0x81)) {
                                newAuth = pr; newAlg = o.data[2].toInt() and 0xFF; ack.add(o)
                            } else nak.add(Opt(3, byteArrayOf(0xC2.toByte(), 0x23, 0x81.toByte())))
                        }
                        else -> rej.add(o)
                    }
                }
                if (rej.isNotEmpty()) sendCp(0xC021, 4, id, rej.fold(ByteArray(0)) { a, o -> a + enc(o) })
                else if (nak.isNotEmpty()) sendCp(0xC021, 3, id, nak.fold(ByteArray(0)) { a, o -> a + enc(o) })
                else {
                    authProto = newAuth; chapAlg = newAlg
                    sendCp(0xC021, 2, id, data)
                    peerLcpAcked = true
                    log("PPP: LCP peer request acked auth=" + Integer.toHexString(authProto) + " alg=" + chapAlg)
                    checkLcpOpen()
                }
            }
            2 -> if (id == lcpId) { ourLcpAcked = true; lcpWaiting = false; checkLcpOpen() }
            3 -> if (id == lcpId) {
                for (o in opts(data)) {
                    if (o.type == 1 && o.data.size == 2) ourMru = be16(o.data, 0)
                    if (o.type == 5) ourMagic = Crypto.rnd.nextInt()
                }
                lcpTries = 0; sendLcpReq()
            }
            4 -> if (id == lcpId) {
                for (o in opts(data)) { if (o.type == 1) useMru = false; if (o.type == 5) useMagic = false }
                lcpTries = 0; sendLcpReq()
            }
            5 -> { sendCp(0xC021, 6, id, ByteArray(0)); fail("server ended the PPP session") }
            9 -> sendCp(0xC021, 10, id, W().u32(ourMagic).b(if (data.size > 4) data.copyOfRange(4, data.size) else ByteArray(0)).bytes())
            6, 10, 11, 7, 8 -> {}
        }
    }

    private fun checkLcpOpen() {
        if (ourLcpAcked && peerLcpAcked && !lcpOpened) {
            lcpOpened = true
            log("PPP: LCP open")
            when (authProto) {
                0xC023 -> sendPapReq()
                0 -> startIpcp()
                else -> {} // wait for the server's CHAP challenge
            }
        }
    }

    // ---------- authentication ----------
    private var papId = 0
    private fun sendPapReq() {
        val u = user.toByteArray(Charsets.UTF_8); val pw = pass.toByteArray(Charsets.UTF_8)
        papId = (papId + 1) and 0xFF
        sendCp(0xC023, 1, papId, W().u8(u.size).b(u).u8(pw.size).b(pw).bytes())
    }

    private fun handlePap(d: ByteArray) {
        val (code, _, data) = parseCp(d) ?: return
        if (code == 2) { log("PPP: PAP accepted"); authOk = true; startIpcp() }
        else if (code == 3) fail("login refused by the server (wrong username/password or expired account)")
    }

    private fun handleChap(d: ByteArray) {
        val (code, id, data) = parseCp(d) ?: return
        when (code) {
            1 -> {
                if (data.isEmpty()) return
                val vs = data[0].toInt() and 0xFF
                if (data.size < 1 + vs) return
                val ch = data.copyOfRange(1, 1 + vs)
                val value: ByteArray
                if (chapAlg == 0x81) {
                    val peerCh = Crypto.random(16)
                    val nt = MsChapV2.generateNtResponse(ch, peerCh, user, pass)
                    mschapNt = nt; mschapPeerCh = peerCh; mschapAuthCh = ch
                    value = W().b(peerCh).b(ByteArray(8)).b(nt).u8(0).bytes()
                } else {
                    value = Crypto.hash("MD5", byteArrayOf(id.toByte()), pass.toByteArray(Charsets.UTF_8), ch)
                }
                val name = user.toByteArray(Charsets.UTF_8)
                sendCp(0xC223, 2, id, W().u8(value.size).b(value).b(name).bytes())
            }
            3 -> {
                val msg = String(data, Charsets.ISO_8859_1)
                if (chapAlg == 0x81 && mschapNt != null) {
                    val exp = MsChapV2.authenticatorResponse(pass, mschapNt!!, mschapPeerCh!!, mschapAuthCh!!, user)
                    if (!msg.startsWith(exp)) log("PPP: warning, server authenticator response does not match")
                }
                log("PPP: login accepted")
                authOk = true
                startIpcp()
            }
            4 -> {
                val msg = String(data, Charsets.ISO_8859_1)
                fail("login refused by the server (wrong username/password or expired account) $msg".trim())
            }
        }
    }

    // ---------- IPCP ----------
    private fun startIpcp() {
        if (ipcpStarted) return
        ipcpStarted = true
        ipcpTries = 0
        sendIpcpReq()
    }

    private fun handleIpcp(d: ByteArray) {
        if (!ipcpStarted) startIpcp()
        val (code, id, data) = parseCp(d) ?: return
        when (code) {
            1 -> {
                val rej = ArrayList<Opt>()
                var pIp: ByteArray? = null
                for (o in opts(data)) {
                    if (o.type == 3 && o.data.size == 4) pIp = o.data
                    else if ((o.type == 0x81 || o.type == 0x83) && o.data.size == 4) {}
                    else rej.add(o)
                }
                if (rej.isNotEmpty()) sendCp(0x8021, 4, id, rej.fold(ByteArray(0)) { a, o -> a + enc(o) })
                else {
                    if (pIp != null) peerIp = pIp
                    sendCp(0x8021, 2, id, data)
                    peerIpcpAcked = true
                    checkUp()
                }
            }
            2 -> if (id == ipcpId) { ourIpcpAcked = true; ipcpWaiting = false; checkUp() }
            3 -> if (id == ipcpId) {
                for (o in opts(data)) {
                    if (o.data.size != 4) continue
                    when (o.type) { 3 -> reqIp = o.data; 0x81 -> reqDns1 = o.data; 0x83 -> reqDns2 = o.data }
                }
                ipcpTries = 0; sendIpcpReq()
            }
            4 -> if (id == ipcpId) {
                for (o in opts(data)) { if (o.type == 0x81) useDns1 = false; if (o.type == 0x83) useDns2 = false }
                ipcpTries = 0; sendIpcpReq()
            }
            5 -> { sendCp(0x8021, 6, id, ByteArray(0)); fail("server ended the PPP session") }
        }
    }

    private fun checkUp() {
        if (ourIpcpAcked && peerIpcpAcked && !up) {
            ourIp = reqIp.copyOf(); dns1 = reqDns1.copyOf(); dns2 = reqDns2.copyOf()
            if (ourIp.all { it == 0.toByte() }) { fail("server did not assign an IP address"); return }
            up = true
            lastRx = System.currentTimeMillis(); lastEcho = lastRx
            log("PPP: up ip=" + ipStr(ourIp) + " dns=" + ipStr(dns1) + "," + ipStr(dns2))
            onUp()
        }
    }

    private fun handleCcp(d: ByteArray) {
        val (code, id, data) = parseCp(d) ?: return
        if (code == 1 && data.isNotEmpty()) {
            log("PPP: server asked for compression/encryption (CCP), rejecting")
            sendCp(0x80FD, 4, id, data)
        } else if (code == 1) sendCp(0x80FD, 2, id, data)
    }

    companion object {
        fun ipStr(b: ByteArray) = b.joinToString(".") { (it.toInt() and 0xFF).toString() }
    }
}
