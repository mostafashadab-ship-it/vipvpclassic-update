package com.example.myvpn

import android.content.Context

// Language helper. Language is stored in prefs "servers" -> "lang" ("en" or "fa").
object Lang {
    fun isFa(ctx: Context): Boolean =
        ctx.getSharedPreferences("servers", Context.MODE_PRIVATE).getString("lang", "") == "fa"

    fun isSet(ctx: Context): Boolean =
        !ctx.getSharedPreferences("servers", Context.MODE_PRIVATE).getString("lang", "").isNullOrEmpty()

    fun set(ctx: Context, lang: String) {
        ctx.getSharedPreferences("servers", Context.MODE_PRIVATE).edit().putString("lang", lang).apply()
    }

    // The service stores the state in English (the code checks it with startsWith).
    // This only translates it for display. Server hostnames are hidden.
    fun state(ctx: Context, s: String): String {
        val fa = isFa(ctx)
        return when {
            s == "Disconnected" -> if (fa) "قطع شد" else s
            s == "Connected" -> if (fa) "متصل شد" else s
            s == "Testing servers..." -> if (fa) "در حال تست سرورها..." else s
            s == "Add a server first" -> if (fa) "اول یک سرور اضافه کن" else s
            s == "Failed: no server connected" -> if (fa) "ناموفق: به هیچ سروری وصل نشد" else s
            s == "Failed: no internet" -> if (fa) "ناموفق: اینترنت گوشی وصل نیست" else s
            s == "Permission needed: open the app and tap Connect" ->
                if (fa) "مجوز لازم است: برنامه را باز کن و Connect بزن" else s
            s.startsWith("Connecting: ") -> if (fa) "در حال اتصال..." else "Connecting..."
            s.startsWith("Connected: ") -> if (fa) "متصل شد" else "Connected"
            s == "Error: enter username and password" ->
                if (fa) "خطا: نام کاربری و رمز عبور را وارد کن" else s
            s.startsWith("Error: IKEv2 requires Android 14+") ->
                if (fa) "خطا: IKEv2 به اندروید ۱۴+ نیاز دارد (از دکمه L2TP استفاده کن)" else s
            s == "Error: Android 11+ required" ->
                if (fa) "خطا: اندروید ۱۱ یا بالاتر لازم است" else s
            s.startsWith("Error: ") -> if (fa) "خطا: " + s.removePrefix("Error: ") else s
            else -> s
        }
    }
}
