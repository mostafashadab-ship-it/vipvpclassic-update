package com.example.myvpn.cisco

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * Cisco AnyConnect (SSL VPN) client: HTTPS login with XML (user + password), then the CSTP tunnel
 * (CONNECT /CSCOSSLC/tunnel) that carries raw IPv4 packets in 8-byte framed records over TLS (TCP 443).
 *
 * Usage: run() blocks until the tunnel ends. onUp() is called once the server has given us an address.
 */
class CiscoClient(
    private val host: String,
    private val ip: InetAddress,
    private val user: String,
    private val pass: String,
    private val protect: (Socket) -> Unit,
    private val log: (String) -> Unit,
    private val events: Events,
    private val authOnly: Boolean = false
) {
    interface Events {
        fun onUp(ip: ByteArray, dns: List<ByteArray>, mtu: Int)
        fun onIpPacket(p: ByteArray)
    }

    companion object {
        private const val VERSION = "4.10.07061"
        private const val UA = "AnyConnect Linux_64 $VERSION"
        private const val PORT = 443

        // TLS mode that worked last time (tried first next time). Some networks / servers close the connection
        // on the default ClientHello, so the client falls back: 0 = default TLS + SNI, 1 = TLS 1.2 only + SNI,
        // 2 = TLS 1.2 only, no SNI, 3 = default TLS, no SNI.
        @Volatile private var tlsMode = 0

        private const val T_DATA = 0
        private const val T_DISCONNECT = 5
        private const val T_DPD_REQ = 3
        private const val T_DPD_RESP = 4
        private const val T_KEEPALIVE = 7
        private const val T_COMPRESSED = 8

        // Time (ms) a TCP connection to port 443 takes. Used as "ping". -1 = no answer.
        fun probe(ip: InetAddress, protect: (Socket) -> Unit, timeoutMs: Int): Long {
            val s = Socket()
            return try {
                s.bind(InetSocketAddress(0)) // creates the fd that protect() needs
                protect(s)
                val t0 = System.currentTimeMillis()
                s.connect(InetSocketAddress(ip, PORT), timeoutMs)
                System.currentTimeMillis() - t0
            } catch (_: Throwable) {
                -1L
            } finally {
                try { s.close() } catch (_: Throwable) {}
            }
        }

        // The servers use their own certificates, so the certificate is not checked (same as the L2TP PSK model).
        private val sslContext: SSLContext by lazy {
            val tm = object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
                override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
            }
            SSLContext.getInstance("TLS").apply { init(null, arrayOf<TrustManager>(tm), SecureRandom()) }
        }
    }

    // Cookies the server hands out during the multi-step login (it uses them to remember the session).
    private val jar = LinkedHashMap<String, String>()

    @Volatile var established = false
    @Volatile var authOk = false
    @Volatile var error: String? = null
    @Volatile private var stopped = false
    @Volatile private var sock: SSLSocket? = null
    @Volatile private var out: OutputStream? = null
    @Volatile private var lastRx = 0L
    @Volatile private var lastTx = 0L

    private class Resp(val status: Int, val headers: List<Pair<String, String>>, val body: String) {
        fun header(name: String): String? = headers.firstOrNull { it.first.equals(name, true) }?.second
        fun all(name: String): List<String> = headers.filter { it.first.equals(name, true) }.map { it.second }
    }

    fun stop() {
        stopped = true
        try { sock?.close() } catch (_: Throwable) {}
    }

    fun sendIp(p: ByteArray) {
        if (!established) return
        sendFrame(T_DATA, p, p.size)
    }

    private fun sendFrame(type: Int, payload: ByteArray?, len: Int) {
        val o = out ?: return
        val buf = ByteArray(8 + len)
        buf[0] = 'S'.code.toByte(); buf[1] = 'T'.code.toByte(); buf[2] = 'F'.code.toByte(); buf[3] = 1
        buf[4] = (len shr 8).toByte(); buf[5] = len.toByte()
        buf[6] = type.toByte(); buf[7] = 0
        if (payload != null && len > 0) System.arraycopy(payload, 0, buf, 8, len)
        try {
            synchronized(o) { o.write(buf); o.flush() }
            lastTx = System.currentTimeMillis()
        } catch (e: Throwable) {
            if (error == null && !stopped) error = "send failed: " + (e.message ?: e.javaClass.simpleName)
            stop()
        }
    }

    private fun openTls(timeoutMs: Int): SSLSocket {
        val start = tlsMode
        var last: Throwable = IllegalStateException("tls stopped")
        for (k in 0 until 4) {
            if (stopped) break
            val mode = (start + k) % 4
            val raw = Socket()
            var tcpUp = false
            try {
                raw.bind(InetSocketAddress(0)) // creates the fd that protect() needs
                protect(raw)
                raw.tcpNoDelay = true
                raw.connect(InetSocketAddress(ip, PORT), 8000)
                tcpUp = true
                val noSni = mode >= 2
                val tls12 = mode == 1 || mode == 2
                // An IP address as "host name" makes the TLS library send no SNI.
                val s = sslContext.socketFactory.createSocket(raw, if (noSni) ip.hostAddress else host, PORT, true) as SSLSocket
                if (tls12) s.enabledProtocols = arrayOf("TLSv1.2")
                s.soTimeout = if (k == 0) 7000 else 5000
                s.startHandshake()
                s.soTimeout = timeoutMs
                if (mode != start) log("TLS mode $mode works (mode $start failed)")
                tlsMode = mode
                return s
            } catch (e: Throwable) {
                try { raw.close() } catch (_: Throwable) {}
                last = e
                if (!tcpUp) throw e // TCP itself failed: other TLS modes cannot help
                log("TLS mode $mode failed: " + e.javaClass.simpleName + " " + (e.message ?: ""))
            }
        }
        throw last
    }

    // ---------- tiny HTTPS client (Connection: close) ----------
    private fun readLine(i: InputStream): String? {
        val b = ByteArrayOutputStream()
        while (true) {
            val c = i.read()
            if (c < 0) return if (b.size() == 0) null else b.toString("ISO-8859-1")
            if (c == '\n'.code) break
            if (c != '\r'.code) b.write(c)
        }
        return b.toString("ISO-8859-1")
    }

    private fun readHeaders(i: InputStream): Pair<Int, List<Pair<String, String>>>? {
        val first = readLine(i) ?: return null
        val status = Regex("^HTTP/\\d\\.\\d\\s+(\\d+)").find(first)?.groupValues?.get(1)?.toIntOrNull() ?: return null
        val hs = ArrayList<Pair<String, String>>()
        while (true) {
            val l = readLine(i) ?: break
            if (l.isEmpty()) break
            val k = l.indexOf(':')
            if (k > 0) hs.add(l.substring(0, k).trim() to l.substring(k + 1).trim())
        }
        return status to hs
    }

    private fun readBody(i: InputStream, hs: List<Pair<String, String>>): String {
        val te = hs.firstOrNull { it.first.equals("Transfer-Encoding", true) }?.second ?: ""
        val cl = hs.firstOrNull { it.first.equals("Content-Length", true) }?.second?.toIntOrNull()
        val bo = ByteArrayOutputStream()
        if (te.contains("chunked", true)) {
            while (true) {
                val sz = (readLine(i) ?: break).substringBefore(';').trim().toIntOrNull(16) ?: break
                if (sz == 0) break
                var left = sz
                val buf = ByteArray(4096)
                while (left > 0) {
                    val n = i.read(buf, 0, minOf(buf.size, left))
                    if (n < 0) break
                    bo.write(buf, 0, n); left -= n
                }
                readLine(i)
            }
        } else if (cl != null) {
            var left = cl
            val buf = ByteArray(4096)
            while (left > 0) {
                val n = i.read(buf, 0, minOf(buf.size, left))
                if (n < 0) break
                bo.write(buf, 0, n); left -= n
            }
        } else {
            val buf = ByteArray(4096)
            try {
                while (true) { val n = i.read(buf); if (n < 0) break; bo.write(buf, 0, n) }
            } catch (_: Throwable) {}
        }
        return bo.toString("UTF-8")
    }

    private fun post(path: String, body: String, cookie: String? = null): Resp {
        val s = openTls(15000)
        try {
            val data = body.toByteArray(Charsets.UTF_8)
            val sb = StringBuilder()
            sb.append("POST ").append(path).append(" HTTP/1.1\r\n")
            sb.append("Host: ").append(host).append("\r\n")
            sb.append("User-Agent: ").append(UA).append("\r\n")
            sb.append("Accept: */*\r\nAccept-Encoding: identity\r\n")
            sb.append("Content-Type: application/xml\r\n")
            sb.append("Content-Length: ").append(data.size).append("\r\n")
            sb.append("X-Transcend-Version: 1\r\nX-Aggregate-Auth: 1\r\nX-AnyConnect-Platform: linux-64\r\n")
            val ck = cookieHeader(cookie)
            if (ck.isNotEmpty()) sb.append("Cookie: ").append(ck).append("\r\n")
            sb.append("Connection: close\r\n\r\n")
            val o = s.outputStream
            o.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
            o.write(data)
            o.flush()
            val i = BufferedInputStream(s.inputStream)
            val (status, hs) = readHeaders(i) ?: throw IllegalStateException("no HTTP answer")
            storeCookies(hs)
            return Resp(status, hs, readBody(i, hs))
        } finally {
            try { s.close() } catch (_: Throwable) {}
        }
    }

    private fun storeCookies(hs: List<Pair<String, String>>) {
        for ((k, v) in hs) {
            if (!k.equals("Set-Cookie", true)) continue
            val nv = v.substringBefore(';')
            val name = nv.substringBefore('=', "").trim()
            val value = nv.substringAfter('=', "").trim()
            if (name.isEmpty()) continue
            if (value.isEmpty() || value == "\"\"") jar.remove(name) else jar[name] = value
        }
        log("cookies: " + jar.keys.joinToString(","))
    }

    private fun cookieHeader(extraWebvpn: String?): String {
        val m = LinkedHashMap(jar)
        if (extraWebvpn != null && !m.containsKey("webvpn")) m["webvpn"] = extraWebvpn
        return m.entries.joinToString("; ") { it.key + "=" + it.value }
    }

    // Short one-line version of a server answer for the log (the answer never contains our password).
    private fun brief(b: String): String = b.replace(Regex("\\s+"), " ").take(900)

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")

    private fun unesc(s: String) = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
        .replace("&apos;", "'").replace("&amp;", "&")

    // Logs in. Returns the webvpn session cookie value, or null (error is set).
    private fun login(): String? {
        val initXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<config-auth client=\"vpn\" type=\"init\" aggregate-auth-version=\"2\">" +
            "<version who=\"vpn\">$VERSION</version><device-id>linux-64</device-id>" +
            "<group-access>https://${esc(host)}</group-access></config-auth>"
        var r = post("/", initXml)
        if (r.status == 405 || r.status == 404) {
            log("auth init at / -> HTTP ${r.status}, trying /auth")
            r = post("/auth", initXml)
        }
        log("auth init -> HTTP ${r.status}: " + brief(r.body))
        var guard = 0
        var passSent = false
        while (guard++ < 6) {
            if (stopped) return null
            val token = Regex("<session-token>([^<]+)</session-token>").find(r.body)?.groupValues?.get(1)?.trim()
            if (r.body.contains("type=\"complete\"") || token != null) {
                if (!token.isNullOrEmpty()) return token
                val c = r.all("Set-Cookie").mapNotNull { Regex("webvpn=([^;]+)").find(it)?.groupValues?.get(1) }
                    .lastOrNull { it.isNotEmpty() && it != "\"\"" }
                if (c != null) return c
                jar["webvpn"]?.let { return it }
                error = "no session token"
                return null
            }
            if (r.status == 401 || r.status == 403 || r.body.contains("<error")) {
                error = "login refused"
                return null
            }
            if (!r.body.contains("auth-request") && !r.body.contains("<form")) {
                // Some servers send the cookie in the headers without XML.
                val c = r.all("Set-Cookie").mapNotNull { Regex("webvpn=([^;]+)").find(it)?.groupValues?.get(1) }
                    .lastOrNull { it.isNotEmpty() && it != "\"\"" }
                if (c != null) return c
                error = "unexpected answer HTTP ${r.status}"
                return null
            }
            // "User max-login error": the user name AND password were accepted, the account just has too many
            // sessions open. Not a wrong password, so it must not be reported as "login refused".
            if (r.body.contains("max-login", true)) {
                authOk = true
                error = "max-login: too many devices are connected with this account"
                return null
            }
            // auth-request: a form that asks for user + password
            val action = Regex("<form[^>]*action=\"([^\"]*)\"").find(r.body)?.groupValues?.get(1)?.let { unesc(it) }
            val path = when {
                action.isNullOrEmpty() -> "/"
                action.startsWith("http") -> "/" + action.substringAfter("://").substringAfter('/', "")
                else -> action
            }
            val inputs = Regex("<input\\b[^>]*>").findAll(r.body).map { it.value }.toList()
            fun attr(tag: String, a: String) = Regex("\\b$a=\"([^\"]*)\"").find(tag)?.groupValues?.get(1)
            val textName = inputs.firstOrNull { attr(it, "type") == "text" }?.let { attr(it, "name") }
            val passName = inputs.firstOrNull { attr(it, "type") == "password" }?.let { attr(it, "name") }
            // The server may ask for the user name and the password in separate steps: answer only what this form asks.
            if (passName != null && passSent) { error = "login refused"; return null } // password asked again = wrong login
            if (textName == null && passName == null) { error = "unsupported login form"; return null }
            val fields = (if (textName != null) "<$textName>${esc(user)}</$textName>" else "") +
                (if (passName != null) "<$passName>${esc(pass)}</$passName>" else "")
            if (passName != null) passSent = true
            val opaque = Regex("<opaque[\\s\\S]*?</opaque>").find(r.body)?.value ?: ""
            val group = Regex("<select[^>]*name=\"group_list\"[\\s\\S]*?</select>").find(r.body)?.value?.let { sel ->
                Regex("<option[^>]*selected[^>]*>([^<]*)</option>").find(sel)?.groupValues?.get(1)
                    ?: Regex("<option[^>]*value=\"([^\"]*)\"").find(sel)?.groupValues?.get(1)
            }
            val reply = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<config-auth client=\"vpn\" type=\"auth-reply\" aggregate-auth-version=\"2\">" +
                "<version who=\"vpn\">$VERSION</version><device-id>linux-64</device-id>" +
                "<session-token/><session-id/>" + opaque +
                "<auth>$fields</auth>" +
                (if (group != null) "<group-select>${esc(unesc(group))}</group-select>" else "") +
                "</config-auth>"
            r = post(path, reply)
            log("auth reply -> HTTP ${r.status}: " + brief(r.body))
        }
        error = "login refused"
        return null
    }

    // ---------- main ----------
    fun run() {
        try {
            var attempt = 0
            while (true) {
                val cookie = login()
                if (cookie == null || stopped) {
                    if (error == null && !stopped) error = "login failed"
                    return
                }
                authOk = true
                if (authOnly) return
                log("logged in, opening tunnel")
                tunnel(cookie)
                // The server accepted the login but then refused the tunnel (HTTP 401/403): this happens now and
                // then right after a fresh login (session not ready yet). One clean retry fixes it.
                if (error == "tunnel auth rejected" && attempt == 0 && !stopped) {
                    attempt++
                    log("tunnel auth rejected -> logging in again once")
                    error = null
                    authOk = false
                    jar.clear()
                    try { sock?.close() } catch (_: Throwable) {}
                    try { Thread.sleep(1500) } catch (_: InterruptedException) {}
                    continue
                }
                break
            }
        } catch (e: Throwable) {
            if (error == null && !stopped) error = e.javaClass.simpleName + ": " + (e.message ?: "")
        } finally {
            established = false
            try { sock?.close() } catch (_: Throwable) {}
        }
    }

    private fun tunnel(cookie: String) {
        val s = openTls(20000)
        sock = s
        if (stopped) { s.close(); return }
        val o = s.outputStream
        val req = "CONNECT /CSCOSSLC/tunnel HTTP/1.1\r\n" +
            "Host: $host\r\n" +
            "User-Agent: $UA\r\n" +
            "Cookie: ${cookieHeader(cookie)}\r\n" +
            "X-CSTP-Version: 1\r\n" +
            "X-CSTP-Hostname: android\r\n" +
            "X-CSTP-MTU: 1280\r\n" +
            "X-CSTP-Base-MTU: 1500\r\n" +
            "X-CSTP-Address-Type: IPv4\r\n" +
            "X-CSTP-Full-IPv6-Capability: false\r\n" +
            "\r\n"
        o.write(req.toByteArray(Charsets.ISO_8859_1)); o.flush()
        val i = BufferedInputStream(s.inputStream, 65536)
        val (status, hs) = readHeaders(i) ?: run { error = "no tunnel answer"; return }
        if (status != 200) {
            error = if (status == 401 || status == 403) "tunnel auth rejected" else "tunnel refused HTTP $status"
            return
        }
        fun h(n: String) = hs.firstOrNull { it.first.equals(n, true) }?.second
        val addr = h("X-CSTP-Address")
        if (addr == null) { error = "server gave no address"; return }
        val ipBytes = try { InetAddress.getByName(addr).address } catch (_: Throwable) { null }
        if (ipBytes == null || ipBytes.size != 4) { error = "bad address $addr"; return }
        val dns = hs.filter { it.first.equals("X-CSTP-DNS", true) }.mapNotNull {
            try { InetAddress.getByName(it.second.trim()).address.takeIf { a -> a.size == 4 } } catch (_: Throwable) { null }
        }
        val mtu = (h("X-CSTP-MTU")?.trim()?.toIntOrNull() ?: 1280).coerceIn(576, 1400)
        val dpd = (h("X-CSTP-DPD")?.trim()?.toIntOrNull() ?: 30).coerceIn(10, 120)
        log("tunnel up: addr=$addr mtu=$mtu dpd=$dpd dns=${dns.size}")

        s.soTimeout = 0
        out = o
        lastRx = System.currentTimeMillis()
        lastTx = lastRx
        events.onUp(ipBytes, dns, mtu)
        established = true

        // Watchdog: sends DPD requests and closes the socket when the server has been silent too long.
        val wd = Thread {
            try {
                while (!stopped && established) {
                    Thread.sleep(1000)
                    val now = System.currentTimeMillis()
                    if (now - lastTx > dpd * 1000L) sendFrame(T_DPD_REQ, null, 0)
                    if (now - lastRx > dpd * 3000L + 5000L) {
                        if (error == null) error = "server silent"
                        stop()
                        break
                    }
                }
            } catch (_: Throwable) {}
        }
        wd.isDaemon = true
        wd.name = "cisco-watchdog"
        wd.start()

        val hdr = ByteArray(8)
        try {
            while (!stopped) {
                readFully(i, hdr, 8)
                if (hdr[0] != 'S'.code.toByte() || hdr[1] != 'T'.code.toByte() || hdr[2] != 'F'.code.toByte()) {
                    error = "bad record header"
                    break
                }
                val len = ((hdr[4].toInt() and 0xff) shl 8) or (hdr[5].toInt() and 0xff)
                val type = hdr[6].toInt() and 0xff
                val payload = ByteArray(len)
                if (len > 0) readFully(i, payload, len)
                lastRx = System.currentTimeMillis()
                when (type) {
                    T_DATA -> if (len > 0) events.onIpPacket(payload)
                    T_DPD_REQ -> sendFrame(T_DPD_RESP, null, 0)
                    T_DISCONNECT -> { if (error == null) error = "server closed the tunnel"; break }
                    T_KEEPALIVE, T_DPD_RESP, T_COMPRESSED -> {}
                    else -> {}
                }
            }
        } catch (e: Throwable) {
            if (!stopped && error == null) error = "tunnel read: " + (e.message ?: e.javaClass.simpleName)
        } finally {
            established = false
            try { sendFrame(T_DISCONNECT, null, 0) } catch (_: Throwable) {}
            try { s.close() } catch (_: Throwable) {}
        }
        if (!stopped && error == null) error = "tunnel closed"
    }

    private fun readFully(i: InputStream, b: ByteArray, n: Int) {
        var off = 0
        while (off < n) {
            val r = i.read(b, off, n - off)
            if (r < 0) throw java.io.EOFException("connection closed")
            off += r
        }
    }
}
