package com.example.myvpn

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

// Saves the stack trace of any crash so the app can show it on the next launch.
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Dns.init(this)
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                File(filesDir, "crash.txt").writeText(
                    "Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT}) " +
                        "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\nthread=${t.name}\n$sw"
                )
            } catch (_: Throwable) {
            }
            old?.uncaughtException(t, e)
        }
    }
}
