package com.example.myvpn.l2tp

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

class IkeException(msg: String) : Exception(msg)

/**
 * IKEv1 (RFC 2409) Main Mode with pre-shared key + Quick Mode, with NAT-T (RFC 3947) forced on,
 * which is what L2TP/IPsec ("L2TP/IPSec PSK") servers expect. Result: a pair of ESP SAs in
 * UDP-encapsulated transport mode protecting UDP port 1701.
 */
class Ike(
    private val t: Transport,
    private val psk: ByteArray,
    private val log: (String) -> Unit,
    // true: give up on the FIRST packet after about 1.2 s (3 sends, 400 ms apart). Used for servers that did not
    // even answer the quick probe, so that the app moves on to the next server / the Cisco servers fast.
    private val quickFirst: Boolean = false
) {
    companion object {
        const val SA = 1; const val PROP = 2; const val TRANS = 3; const val KE = 4; const val ID = 5
        const val HASH = 8; const val NONCE = 10; const val NOTIFY = 11; const val DELETE = 12; const val VID = 13
        const val NATD = 20; const val NATOA = 21
        const val EXCH_MAIN = 2; const val EXCH_INFO = 5; const val EXCH_QUICK = 32
        const val N_RUTHERE = 36136; const val N_RUTHERE_ACK = 36137

        private fun md5(s: String) = Crypto.hash("MD5", s.toByteArray(Charsets.US_ASCII))
        val VID_NATT_RFC = md5("RFC 3947")
        val VID_DPD = "afcad71368a1f1c96b8696fc77570100".chunked(2).map { it.toInt(16).toByte() }.toByteArray()

        class Tf(val enc: Int, val keyBits: Int, val hash: Int, val group: Int)

        // Order = our preference. Servers pick the first one they like.
        val offers = listOf(
            Tf(7, 256, 2, 14), Tf(7, 128, 2, 14), Tf(7, 256, 4, 14), Tf(7, 128, 4, 14),
            Tf(7, 256, 2, 2), Tf(7, 128, 2, 2), Tf(5, 0, 2, 2), Tf(7, 256, 2, 5), Tf(7, 128, 2, 5), Tf(5, 0, 2, 14),
            Tf(7, 256, 4, 2), Tf(7, 128, 4, 2)
        )

        // ----- message building blocks -----
        fun payload(next: Int, body: ByteArray): ByteArray = W().u8(next).u8(0).u16(body.size + 4).b(body).bytes()

        /** Returns (first payload type, chained bytes). */
        fun chain(items: List<Pair<Int, ByteArray>>): Pair<Int, ByteArray> {
            val w = W()
            for ((i, it) in items.withIndex()) {
                val next = if (i + 1 < items.size) items[i + 1].first else 0
                w.b(payload(next, it.second))
            }
            return Pair(items[0].first, w.bytes())
        }

        fun header(ic: ByteArray, rc: ByteArray, next: Int, exch: Int, flags: Int, msgId: Long, totalLen: Int): ByteArray =
            W().b(ic).b(rc).u8(next).u8(0x10).u8(exch).u8(flags).u32(msgId).u32(totalLen).bytes()

        fun tv(type: Int, v: Int): ByteArray = W().u16(0x8000 or type).u16(v).bytes()

        class P(val type: Int, val body: ByteArray, val start: Int, val end: Int)

        /** Walks a payload chain inside [d] (from [off]); stops at next == 0 or when data runs out. */
        fun parse(d: ByteArray, off: Int, first: Int): List<P> {
            val out = ArrayList<P>()
            var p = off
            var type = first
            while (type != 0 && p + 4 <= d.size) {
                val next = d[p].toInt() and 0xFF
                val len = be16(d, p + 2)
                if (len < 4 || p + len > d.size) throw IkeException("bad payload length")
                out.add(P(type, d.copyOfRange(p + 4, p + len), p, p + len))
                p += len
                type = next
            }
            return out
        }

        fun attrs(r: R): Map<Int, Long> {
            val m = HashMap<Int, Long>()
            while (r.left() >= 4) {
                val t = r.u16()
                if (t and 0x8000 != 0) m[t and 0x7FFF] = r.u16().toLong()
                else {
                    val l = r.u16()
                    val v = r.b(l)
                    var x = 0L
                    for (b in v) x = (x shl 8) or (b.toLong() and 0xFF)
                    m[t] = x
                }
            }
            return m
        }

        fun mm1Packet(ic: ByteArray): Pair<ByteArray, ByteArray> {
            val trans = W()
            for ((i, o) in offers.withIndex()) {
                val a = W().b(tv(1, o.enc))
                if (o.enc == 7) a.b(tv(14, o.keyBits))
                a.b(tv(2, o.hash)).b(tv(3, 1)).b(tv(4, o.group)).b(tv(11, 1)).b(tv(12, 28800))
                val ab = a.bytes()
                trans.u8(if (i + 1 < offers.size) TRANS else 0).u8(0).u16(8 + ab.size)
                    .u8(i + 1).u8(1).u16(0).b(ab)
            }
            val tb = trans.bytes()
            val prop = W().u8(0).u8(0).u16(8 + tb.size).u8(1).u8(1).u8(0).u8(offers.size).b(tb).bytes()
            val saBody = W().u32(1).u32(1).b(prop).bytes()
            val (first, body) = chain(listOf(Pair(SA, saBody), Pair(VID, VID_NATT_RFC), Pair(VID, VID_DPD)))
            val pk = W().b(header(ic, ByteArray(8), first, EXCH_MAIN, 0, 0, 28 + body.size)).b(body).bytes()
            return Pair(pk, saBody)
        }

        /** Measures the round trip of the first IKE answer. -1 = no answer. Used to pick the best server. */
        fun probe(server: InetAddress, mk: (Int) -> DatagramSocket, timeoutMs: Int): Long {
            var s: DatagramSocket? = null
            return try {
                s = mk(0)
                s.soTimeout = timeoutMs
                val ic = Crypto.random(8)
                val pk = mm1Packet(ic).first
                val t0 = System.nanoTime()
                s.send(DatagramPacket(pk, pk.size, server, 500))
                val buf = ByteArray(2048)
                val dp = DatagramPacket(buf, buf.size)
                var resent = 0
                val end = System.currentTimeMillis() + timeoutMs
                while (true) {
                    // UDP can be lost: ask again after 500 ms and 1000 ms inside the same time window.
                    val left = (end - System.currentTimeMillis()).toInt()
                    if (left <= 0) return -1L
                    s.soTimeout = minOf(left, 500)
                    try {
                        s.receive(dp)
                    } catch (e: java.net.SocketTimeoutException) {
                        if (resent < 2 && System.currentTimeMillis() < end) {
                            resent++
                            s.send(DatagramPacket(pk, pk.size, server, 500))
                        }
                        continue
                    }
                    if (dp.length >= 28 && dp.address == server && buf.copyOf(8).contentEquals(ic))
                        return (System.nanoTime() - t0) / 1_000_000
                }
                -1L
            } catch (e: Exception) {
                -5L // socket / protect error (not "no answer")
            } finally {
                try { s?.close() } catch (_: Exception) {}
            }
        }
    }

    // ---- negotiated state ----
    private lateinit var ic: ByteArray
    private lateinit var rc: ByteArray
    private var hashId = 2
    private var des3 = false
    private var keyLen = 32
    private var blockSize = 16
    private lateinit var macAlg: String
    private lateinit var hashAlg: String
    private lateinit var encKey: ByteArray
    private lateinit var skeyidD: ByteArray
    private lateinit var skeyidA: ByteArray
    private var p1Iv = ByteArray(0)      // running CBC state of phase 1
    private var p1Final = ByteArray(0)   // IV state at the end of phase 1 (base for new exchanges)
    private var group = 14
    private lateinit var localIp: ByteArray
    private lateinit var serverIp: ByteArray

    private fun prf(key: ByteArray, vararg d: ByteArray) = Crypto.hmac(macAlg, key, *d)

    private fun encrypt(plain: ByteArray, iv: ByteArray): ByteArray {
        val padded = plain.copyOf(((plain.size + blockSize - 1) / blockSize) * blockSize)
        return Crypto.cbc(true, des3, encKey, iv, padded)
    }

    private fun decrypt(ct: ByteArray, iv: ByteArray): ByteArray {
        if (ct.isEmpty() || ct.size % blockSize != 0) throw IkeException("bad encrypted length")
        return Crypto.cbc(false, des3, encKey, iv, ct)
    }

    private fun lastBlock(ct: ByteArray) = ct.copyOfRange(ct.size - blockSize, ct.size)

    private fun expandKey(skeyidE: ByteArray, need: Int): ByteArray {
        if (skeyidE.size >= need) return skeyidE.copyOf(need)
        var k = prf(skeyidE, byteArrayOf(0))
        var all = k
        while (all.size < need) {
            k = prf(skeyidE, k)
            all += k
        }
        return all.copyOf(need)
    }

    // ---- network helper with retransmission ----
    // Sends [send], waits for an accepted answer and sends again when nothing comes (UDP gets lost, and some
    // servers / routers answer slowly). About 11 s in total. Every resend and the final result go to the log.
    private fun exchange(step: String, send: () -> Unit, accept: (Pkt) -> Boolean): Pkt {
        val t0 = System.currentTimeMillis()
        var tries = 0
        val quick = quickFirst && step == "MM1"
        val maxTries = if (quick) 3 else 6
        while (tries < maxTries) {
            if (tries > 0) log("IKE $step: no answer yet, resend #$tries (+" + (System.currentTimeMillis() - t0) + " ms)")
            send()
            val deadline = System.currentTimeMillis() + (if (quick) 400L else 900L + tries * 400L)
            while (true) {
                val left = deadline - System.currentTimeMillis()
                if (left <= 0) break
                val p = t.q.poll(left, java.util.concurrent.TimeUnit.MILLISECONDS) ?: break
                if (accept(p)) {
                    log("IKE $step: answer after " + (System.currentTimeMillis() - t0) + " ms (sent " + (tries + 1) + "x)")
                    return p
                }
            }
            tries++
        }
        throw IkeException("no answer from server at $step after " + (System.currentTimeMillis() - t0) + " ms (" + t.diag() + ")")
    }

    private fun stripMarker(p: Pkt): ByteArray? {
        if (p.port == 4500) {
            if (p.data.size < 4 || be32(p.data, 0) != 0L) return null // ESP or keepalive
            return p.data.copyOfRange(4, p.data.size)
        }
        return p.data
    }

    private fun notifyText(d: ByteArray): String {
        return try {
            val ps = parse(d, 28, d[16].toInt() and 0xFF)
            val n = ps.firstOrNull { it.type == NOTIFY } ?: return "informational"
            val r = R(n.body)
            r.u32(); r.u8(); val sl = r.u8(); val type = r.u16(); r.b(sl)
            "notify $type" + if (type == 14) " (no proposal chosen)" else if (type == 18) " (invalid ID / bad PSK?)" else ""
        } catch (e: Exception) { "informational" }
    }

    /** For an encrypted informational message: the type of an error notification (1..8191) it carries, else -1. */
    private fun infoErrorType(d: ByteArray): Int {
        return try {
            if ((d[19].toInt() and 1) == 0) return -1
            val ct = d.copyOfRange(28, d.size).let { it.copyOf(it.size - it.size % blockSize) }
            val pl = decrypt(ct, Crypto.hash(hashAlg, p1Final, d.copyOfRange(20, 24)).copyOf(blockSize))
            for (p in parse(pl, 0, d[16].toInt() and 0xFF)) {
                if (p.type == NOTIFY) {
                    val r = R(p.body)
                    r.u32(); r.u8(); val sl = r.u8(); val type = r.u16(); r.b(sl)
                    if (type in 1..8191) return type
                }
            }
            -1
        } catch (e: Exception) { -1 }
    }

    // ================== negotiation ==================
    class Result(val esp: EspSa, val lifeSec: Int)

    fun negotiate(): Result {
        serverIp = t.server.address
        localIp = t.localAddr.address
        if (serverIp.size != 4 || localIp.size != 4) throw IkeException("IPv4 only")
        ic = Crypto.random(8)

        // ---- MM1 / MM2 ----
        val (mm1, saBody) = mm1Packet(ic)
        log("IKE: MM1 -> " + t.server.hostAddress)
        val m2p = exchange("MM1", { t.send500(mm1) }) { p ->
            p.port == 500 && p.data.size >= 28 && p.data.copyOf(8).contentEquals(ic)
        }
        val m2 = m2p.data
        if ((m2[18].toInt() and 0xFF) == EXCH_INFO) throw IkeException("server refused: " + notifyText(m2))
        rc = m2.copyOfRange(8, 16)
        val ps2 = parse(m2, 28, m2[16].toInt() and 0xFF)
        val saP = ps2.firstOrNull { it.type == SA } ?: throw IkeException("MM2 without SA")
        run {
            val r = R(saP.body)
            r.u32(); r.u32()
            r.u8(); r.u8(); r.u16(); r.u8(); r.u8()
            val spiSize = r.u8(); r.u8(); r.b(spiSize)
            r.u8(); r.u8(); r.u16(); r.u8(); r.u8(); r.u16()
            val a = attrs(r)
            val enc = (a[1] ?: 0L).toInt()
            hashId = (a[2] ?: 2L).toInt()
            group = (a[4] ?: 2L).toInt()
            if ((a[3] ?: 1L).toInt() != 1) throw IkeException("server chose unsupported auth method " + a[3])
            des3 = enc == 5
            if (enc != 5 && enc != 7) throw IkeException("server chose unsupported cipher $enc")
            keyLen = if (des3) 24 else ((a[14] ?: 128L).toInt() / 8)
            blockSize = if (des3) 8 else 16
            log("IKE: server chose enc=$enc/${keyLen * 8} hash=$hashId group=$group")
        }
        macAlg = Crypto.macName(hashId)
        hashAlg = Crypto.hashName(hashId)
        val dhGroup = Crypto.groups[group] ?: throw IkeException("unsupported DH group $group")
        val nattOk = ps2.any { it.type == VID && it.body.contentEquals(VID_NATT_RFC) }
        if (!nattOk) log("IKE: warning, server did not announce NAT-T (RFC 3947)")

        // ---- MM3 / MM4 ----
        val dh = Crypto.DhPair(dhGroup)
        val ni = Crypto.random(32)
        // NAT-D: first the server's address, then ours. Ours is deliberately wrong so the server always
        // believes we are behind NAT and switches to UDP-encapsulated ESP on port 4500 (what Android needs).
        val natdR = Crypto.hash(hashAlg, ic, rc, serverIp, byteArrayOf(0x01, 0xF4.toByte()))
        val fakeIp = Crypto.random(4)
        val natdI = Crypto.hash(hashAlg, ic, rc, fakeIp, byteArrayOf(0x01, 0xF4.toByte()))
        val (f3, b3) = chain(listOf(Pair(KE, dh.pub), Pair(NONCE, ni), Pair(NATD, natdR), Pair(NATD, natdI)))
        val mm3 = W().b(header(ic, rc, f3, EXCH_MAIN, 0, 0, 28 + b3.size)).b(b3).bytes()
        log("IKE: MM3 ->")
        val m4p = exchange("MM3", { t.send500(mm3) }) { p ->
            p.port == 500 && p.data.size >= 28 && p.data.copyOf(8).contentEquals(ic) &&
                p.data.copyOfRange(8, 16).contentEquals(rc)
        }
        val m4 = m4p.data
        if ((m4[18].toInt() and 0xFF) == EXCH_INFO) throw IkeException("server refused: " + notifyText(m4))
        val ps4 = parse(m4, 28, m4[16].toInt() and 0xFF)
        val ker = ps4.firstOrNull { it.type == KE }?.body ?: throw IkeException("MM4 without KE")
        val nr = ps4.firstOrNull { it.type == NONCE }?.body ?: throw IkeException("MM4 without nonce")
        val gxy = dh.shared(ker)
        val skeyid = prf(psk, ni, nr)
        skeyidD = prf(skeyid, gxy, ic, rc, byteArrayOf(0))
        skeyidA = prf(skeyid, skeyidD, gxy, ic, rc, byteArrayOf(1))
        val skeyidE = prf(skeyid, skeyidA, gxy, ic, rc, byteArrayOf(2))
        encKey = expandKey(skeyidE, keyLen)
        p1Iv = Crypto.hash(hashAlg, dh.pub, ker).copyOf(blockSize)

        // ---- MM5 / MM6 (encrypted, now on port 4500) ----
        val idBody = W().u8(1).u8(0).u16(0).b(localIp).bytes()
        val hashI = prf(skeyid, dh.pub, ker, ic, rc, saBody, idBody)
        val (f5, b5) = chain(listOf(Pair(ID, idBody), Pair(HASH, hashI)))
        val ct5 = encrypt(b5, p1Iv)
        val mm5 = W().u32(0).b(header(ic, rc, f5, EXCH_MAIN, 1, 0, 28 + ct5.size)).b(ct5).bytes()
        val ivAfter5 = lastBlock(ct5)
        log("IKE: MM5 -> :4500")
        val m6p = exchange("MM5", { t.send4500(mm5) }) { p ->
            val d = stripMarker(p)
            d != null && d.size >= 28 && d.copyOf(8).contentEquals(ic) && d.copyOfRange(8, 16).contentEquals(rc)
        }
        val m6 = stripMarker(m6p)!!
        if ((m6[18].toInt() and 0xFF) == EXCH_INFO) throw IkeException("server refused: " + notifyText(m6))
        val ct6 = m6.copyOfRange(28, m6.size)
        val pl6 = decrypt(ct6.copyOf(ct6.size - ct6.size % blockSize), ivAfter5)
        val ps6 = parse(pl6, 0, m6[16].toInt() and 0xFF)
        val idr = ps6.firstOrNull { it.type == ID }?.body ?: throw IkeException("MM6 without ID")
        val hr = ps6.firstOrNull { it.type == HASH }?.body ?: throw IkeException("MM6 without HASH")
        val expect = prf(skeyid, ker, dh.pub, rc, ic, saBody, idr)
        if (!expect.contentEquals(hr)) throw IkeException("wrong pre-shared key (server hash mismatch)")
        p1Iv = lastBlock(ct6.copyOf(ct6.size - ct6.size % blockSize))
        p1Final = p1Iv
        log("IKE: phase 1 done")

        // ---- Quick Mode ----
        try {
            return quickMode(false)
        } catch (e: IkeException) {
            if (e.message?.contains("notify 14") == true) {
                log("IKE: retry quick mode with PFS")
                return quickMode(true)
            }
            throw e
        }
    }

    private class EspOffer(val enc: Int, val keyBits: Int, val auth: Int)
    private val espOffers = listOf(
        EspOffer(12, 256, 2), EspOffer(12, 128, 2), EspOffer(12, 256, 5), EspOffer(12, 128, 5), EspOffer(3, 0, 2)
    )

    private fun newMsgId(): Long {
        while (true) {
            val v = be32(Crypto.random(4), 0)
            if (v != 0L) return v
        }
    }

    private fun quickMode(pfs: Boolean): Result {
        val msgId = newMsgId()
        val spiIn = ByteArray(4)
        while (true) {
            Crypto.rnd.nextBytes(spiIn)
            if (be32(spiIn, 0) > 4096L) break
        }
        val ni = Crypto.random(20)
        val dhq = if (pfs) Crypto.DhPair(Crypto.groups[group]!!) else null

        val trans = W()
        for ((i, o) in espOffers.withIndex()) {
            val a = W().b(tv(1, 1)).b(tv(2, 28800)).b(tv(4, 4))
            if (pfs) a.b(tv(3, group))
            a.b(tv(5, o.auth))
            if (o.enc == 12) a.b(tv(6, o.keyBits))
            val ab = a.bytes()
            trans.u8(if (i + 1 < espOffers.size) TRANS else 0).u8(0).u16(8 + ab.size).u8(i + 1).u8(o.enc).u16(0).b(ab)
        }
        val tb = trans.bytes()
        val prop = W().u8(0).u8(0).u16(8 + 4 + tb.size).u8(1).u8(3).u8(4).u8(espOffers.size).b(spiIn).b(tb).bytes()
        val saBody = W().u32(1).u32(1).b(prop).bytes()
        fun idPl(ip: ByteArray) = W().u8(1).u8(17).u16(1701).b(ip).bytes()
        fun oaPl(ip: ByteArray) = W().u8(1).u8(0).u16(0).b(ip).bytes()
        val items = ArrayList<Pair<Int, ByteArray>>()
        items.add(Pair(SA, saBody))
        items.add(Pair(NONCE, ni))
        if (pfs) items.add(Pair(KE, dhq!!.pub))
        items.add(Pair(ID, idPl(localIp)))
        items.add(Pair(ID, idPl(serverIp)))
        items.add(Pair(NATOA, oaPl(localIp)))
        items.add(Pair(NATOA, oaPl(serverIp)))
        val (_, rest) = chain(items)
        val msgIdBytes = W().u32(msgId).bytes()
        val hash1 = prf(skeyidA, msgIdBytes, rest)
        val body = W().b(payload(items[0].first, hash1)).b(rest).bytes()
        val iv0 = Crypto.hash(hashAlg, p1Final, msgIdBytes).copyOf(blockSize)
        val ct1 = encrypt(body, iv0)
        val qm1 = W().u32(0).b(header(ic, rc, HASH, EXCH_QUICK, 1, msgId, 28 + ct1.size)).b(ct1).bytes()
        log("IKE: QM1 ->")
        val qp = exchange("QM1", { t.send4500(qm1) }) { p ->
            val d = stripMarker(p)
            if (d == null || d.size < 28 || !d.copyOf(8).contentEquals(ic) || !d.copyOfRange(8, 16).contentEquals(rc)) false
            else if ((d[18].toInt() and 0xFF) == EXCH_INFO) infoErrorType(d) > 0   // only error notifications end the exchange
            else be32(d, 20) == msgId
        }
        val q2 = stripMarker(qp)!!
        if ((q2[18].toInt() and 0xFF) == EXCH_INFO) {
            throw IkeException("server refused quick mode: notify " + infoErrorType(q2))
        }
        val ctq = q2.copyOfRange(28, q2.size).let { it.copyOf(it.size - it.size % blockSize) }
        val iv2 = lastBlock(ct1)
        val plain = decrypt(ctq, iv2)
        val ps = parse(plain, 0, q2[16].toInt() and 0xFF)
        val hashP = ps.firstOrNull { it.type == HASH } ?: throw IkeException("QM2 without HASH")
        val last = ps.last().end
        val restR = plain.copyOfRange(hashP.end, last)
        val expect = prf(skeyidA, msgIdBytes, ni, restR)
        if (!expect.contentEquals(hashP.body)) throw IkeException("QM2 hash mismatch")
        val sa2 = ps.firstOrNull { it.type == SA } ?: throw IkeException("QM2 without SA")
        val nr = ps.firstOrNull { it.type == NONCE }?.body ?: throw IkeException("QM2 without nonce")
        val ker = ps.firstOrNull { it.type == KE }?.body

        val r = R(sa2.body)
        r.u32(); r.u32()
        r.u8(); r.u8(); r.u16(); r.u8()
        val proto = r.u8()
        val spiSize = r.u8(); r.u8()
        val spiOut = r.b(spiSize)
        if (proto != 3 || spiSize != 4) throw IkeException("QM2: unexpected protocol")
        r.u8(); r.u8(); r.u16(); r.u8()
        val encId = r.u8(); r.u16()
        val a = attrs(r)
        val mode = (a[4] ?: 0L).toInt()
        if (mode != 4 && mode != 61444 && mode != 3) log("IKE: warning, server chose encapsulation mode $mode")
        if (mode == 2 || mode == 1) throw IkeException("server chose non UDP-encapsulated ESP (mode $mode)")
        val authId = (a[5] ?: 2L).toInt()
        val macName = when (authId) {
            1 -> "HmacMD5"; 2 -> "HmacSHA1"; 5 -> "HmacSHA256"; 6 -> "HmacSHA384"; 7 -> "HmacSHA512"
            else -> throw IkeException("unsupported ESP auth $authId")
        }
        val authLen = when (authId) { 1 -> 16; 2 -> 20; 5 -> 32; 6 -> 48; else -> 64 }
        val icvLen = when (authId) { 1 -> 12; 2 -> 12; 5 -> 16; 6 -> 24; else -> 32 }
        val d3 = encId == 3
        if (encId != 3 && encId != 12) throw IkeException("unsupported ESP cipher $encId")
        val encLen = if (d3) 24 else ((a[6] ?: 128L).toInt() / 8)
        val life = (a[2] ?: 3600L).toInt()
        log("IKE: ESP cipher=$encId/${encLen * 8} auth=$authId life=${life}s")

        var gxyQ = ByteArray(0)
        if (pfs) {
            if (ker == null) throw IkeException("QM2 without KE")
            gxyQ = dhq!!.shared(ker)
        }
        fun keymat(spi: ByteArray): ByteArray {
            val need = encLen + authLen
            val seed = Crypto.concat(gxyQ, byteArrayOf(3), spi, ni, nr)
            var k = prf(skeyidD, seed)
            var all = k
            while (all.size < need) {
                k = prf(skeyidD, k, seed)
                all += k
            }
            return all.copyOf(need)
        }
        val kOut = keymat(spiOut)
        val kIn = keymat(spiIn)

        // QM3
        val hash3 = prf(skeyidA, byteArrayOf(0), msgIdBytes, ni, nr)
        val b3 = payload(0, hash3)
        val ct3 = encrypt(b3, lastBlock(ctq))
        val qm3 = W().u32(0).b(header(ic, rc, HASH, EXCH_QUICK, 1, msgId, 28 + ct3.size)).b(ct3).bytes()
        t.send4500(qm3)
        log("IKE: quick mode done")

        val esp = EspSa(
            spiOut = be32(spiOut, 0).toInt(), spiIn = be32(spiIn, 0).toInt(), des3 = d3,
            encKeyOut = kOut.copyOfRange(0, encLen), encKeyIn = kIn.copyOfRange(0, encLen),
            macName = macName,
            authKeyOut = kOut.copyOfRange(encLen, encLen + authLen), authKeyIn = kIn.copyOfRange(encLen, encLen + authLen),
            icvLen = icvLen
        )
        return Result(esp, life)
    }

    /**
     * Handles an IKE packet that arrives after the tunnel is up (marker already removed).
     * Returns a reply packet to send on 4500 (marker included) or null. Throws if the server deleted the SA.
     */
    fun onInformational(d: ByteArray): ByteArray? {
        if (d.size < 28 || !d.copyOf(8).contentEquals(ic)) return null
        if ((d[18].toInt() and 0xFF) != EXCH_INFO || (d[19].toInt() and 1) == 0) return null
        val msgIdB = d.copyOfRange(20, 24)
        val ct = d.copyOfRange(28, d.size).let { it.copyOf(it.size - it.size % blockSize) }
        val plain = decrypt(ct, Crypto.hash(hashAlg, p1Final, msgIdB).copyOf(blockSize))
        val ps = parse(plain, 0, d[16].toInt() and 0xFF)
        for (p in ps) {
            if (p.type == DELETE) throw IkeException("server deleted the IPsec SA")
            if (p.type == NOTIFY) {
                val r = R(p.body)
                r.u32(); r.u8(); val sl = r.u8(); val type = r.u16(); r.b(sl)
                if (type == N_RUTHERE) {
                    val data = r.rest()
                    val nBody = W().u32(1).u8(1).u8(16).u16(N_RUTHERE_ACK).b(ic).b(rc).b(data).bytes()
                    val nPl = payload(0, nBody)
                    val mid = newMsgId()
                    val midB = W().u32(mid).bytes()
                    val h = prf(skeyidA, midB, nPl)
                    val body = W().b(payload(NOTIFY, h)).b(nPl).bytes()
                    val ctr = encrypt(body, Crypto.hash(hashAlg, p1Final, midB).copyOf(blockSize))
                    return W().u32(0).b(header(ic, rc, HASH, EXCH_INFO, 1, mid, 28 + ctr.size)).b(ctr).bytes()
                }
            }
        }
        return null
    }
}
