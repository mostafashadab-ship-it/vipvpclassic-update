package com.example.myvpn

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/**
 * A quiet, permanent notification ("tap to open the app") that sits in the status bar / notification shade.
 * It is posted when the app is opened, right after the app has been installed / updated
 * ([PinReceiver], no need to open the app) and after the phone restarts.
 * It makes no sound and no pop-up; tapping it opens the app.
 */
object PinNotice {
    private const val ID = 3
    private const val CH = "app_pin"

    fun post(c: Context) {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return
            val fa = Lang.isFa(c)
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                CH,
                if (fa) "میان‌بر برنامه" else "App shortcut",
                NotificationManager.IMPORTANCE_LOW
            )
            ch.setShowBadge(false)
            ch.enableVibration(false)
            ch.setSound(null, null)
            nm.createNotificationChannel(ch)
            val open = PendingIntent.getActivity(
                c, 3,
                Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(c, CH)
                .setSmallIcon(R.drawable.ic_tile)
                .setContentTitle("vipvpclassic1")
                .setContentText(if (fa) "برای باز کردن برنامه بزنید" else "Tap to open the app")
                .setOngoing(true)
                .setShowWhen(false)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_STATUS)
                .setContentIntent(open)
                .build()
            nm.notify(ID, n)
        } catch (_: Throwable) {
        }
    }

    fun cancel(c: Context) {
        try {
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID)
        } catch (_: Throwable) {
        }
    }
}

/** After the app is installed over an older version (update) or the phone restarts: show the notification again. */
class PinReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val a = i.action
        if (a == Intent.ACTION_MY_PACKAGE_REPLACED || a == Intent.ACTION_BOOT_COMPLETED) PinNotice.post(c)
    }
}
