package com.example.myvpn

import android.content.SharedPreferences
import android.net.Network
import java.net.HttpURLConnection
import java.net.URL

// Auto mode prefers the server that opens Instagram. After a server connects, Instagram is opened THROUGH the
// tunnel; if it answers quickly the server is kept (and remembered, tried first next time), otherwise the next
// server is tried. If no server opens Instagram, the first connected one (best ping) is used.
object InstagramProbe {
    const val MAX_TRIES = 3
    private const val KEY = "ig_best"

    // true = Instagram answered through the tunnel within the timeout (any HTTP answer counts).
    fun opens(net: Network?): Boolean {
        repeat(2) {
            try {
                val u = URL("https://www.instagram.com/")
                val c = (if (net != null) net.openConnection(u) else u.openConnection()) as HttpURLConnection
                c.connectTimeout = 5000
                c.readTimeout = 5000
                c.instanceFollowRedirects = false
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                val code = try { c.responseCode } finally { c.disconnect() }
                if (code > 0) return true
            } catch (_: Throwable) {
            }
        }
        return false
    }

    fun best(p: SharedPreferences): String = p.getString(KEY, "") ?: ""
    fun remember(p: SharedPreferences, host: String) { p.edit().putString(KEY, host).apply() }

    // Puts the remembered Instagram server first (only if it is in the list and answered the ping/probe).
    fun prefer(order: List<String>, p: SharedPreferences, usable: (String) -> Boolean): List<String> {
        val b = best(p)
        val hit = order.firstOrNull { it.equals(b, true) } ?: return order
        if (!usable(hit)) return order
        return listOf(hit) + order.filter { it != hit }
    }
}
