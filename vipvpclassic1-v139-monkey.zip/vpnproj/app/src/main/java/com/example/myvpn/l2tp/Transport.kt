package com.example.myvpn.l2tp

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.LinkedBlockingQueue

class Pkt(val port: Int, val data: ByteArray)

/**
 * The two UDP sockets used towards one L2TP/IPsec server: one for IKE on 500 and one
 * for IKE + ESP after the NAT-T "float" to 4500. Every received datagram ends up in [q].
 * [mk] must return a socket that is already excluded from the VPN (protect()) and bound to the port
 * (0 = any free port).
 */
class Transport(val server: InetAddress, mk: (Int) -> DatagramSocket) {
    val s500: DatagramSocket = mk(0)
    val s4500: DatagramSocket = try { mk(4500) } catch (e: Exception) { mk(0) }
    val q = LinkedBlockingQueue<Pkt>()
    @Volatile var closed = false
    // Diagnostics for the error log: what arrived on the sockets (and from whom) while we waited.
    @Volatile var rxTotal = 0
    @Volatile var rxOther = 0
    @Volatile var rxErr: String? = null
    val localAddr: InetAddress

    init {
        s500.connect(server, 500)
        localAddr = s500.localAddress
        for (s in listOf(s500, s4500)) {
            val t = Thread {
                val buf = ByteArray(2048)
                while (!closed) {
                    try {
                        val dp = DatagramPacket(buf, buf.size)
                        s.receive(dp)
                        rxTotal++
                        if (dp.address != server) rxOther++
                        if (dp.address == server) q.put(Pkt(dp.port, dp.data.copyOfRange(dp.offset, dp.offset + dp.length)))
                    } catch (e: Exception) {
                        if (closed) break
                        rxErr = e.javaClass.simpleName + ":" + (e.message ?: "")
                        try { Thread.sleep(50) } catch (_: InterruptedException) { break }
                        if (s.isClosed) break
                    }
                }
            }
            t.isDaemon = true
            t.name = "udp-rx-" + s.localPort
            t.start()
        }
    }

    fun diag(): String =
        "local=" + s500.localPort + "/" + s4500.localPort + " rx=" + rxTotal + " otherIp=" + rxOther + (rxErr?.let { " sockErr=" + it } ?: "")

    fun send500(b: ByteArray) { s500.send(DatagramPacket(b, b.size)) }
    fun send4500(b: ByteArray) { s4500.send(DatagramPacket(b, b.size, server, 4500)) }

    fun close() {
        closed = true
        try { s500.close() } catch (_: Exception) {}
        try { s4500.close() } catch (_: Exception) {}
    }
}
