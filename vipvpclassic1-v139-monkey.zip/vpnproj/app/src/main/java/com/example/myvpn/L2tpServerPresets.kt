package com.example.myvpn

/**
 * Server list of the "Cisco & L2TP servers" section.
 * These are kept separate from the IKEv2 host list so they are never accidentally passed to the IKEv2 engine.
 * A host with "cisco:" in front is a Cisco AnyConnect server (TCP 443); every other host is L2TP/IPsec.
 */
object L2tpServerPresets {
    // Raise this when the built-in list changes: every phone then gets the built-in servers back once (ones the
    // user deleted return; servers the user added himself are kept, after the built-in ones).
    private const val LIST_VERSION = 7

    // Built-in servers that were taken out of the list: removed from every saved list once (on the version bump).
    private val REMOVED = listOf("cisco:Mu2.gsmxr.net", "L2tp.gsmxr.net")

    // User-editable list (one host per line). Before the first save the built-in hosts are used.
    fun load(prefs: android.content.SharedPreferences): List<String> {
        if (prefs.getInt("l2preset_ver", 0) < LIST_VERSION) {
            val old = (prefs.getString("l2hosts", null) ?: "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
            val merged = hosts + old.filter { o ->
                hosts.none { it.equals(o, true) } && REMOVED.none { it.equals(o, true) }
            }
            prefs.edit().putString("l2hosts", merged.joinToString("\n")).putInt("l2preset_ver", LIST_VERSION).apply()
        }
        val raw = prefs.getString("l2hosts", null) ?: return hosts
        return raw.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    }

    val hosts: List<String> = listOf(
        "L3tp.gsmxr.net",
        "L4tp.gsmxr.net",
        "Sstp2.gsmxr.net",
        "cisco:Mu1.gsmxr.net"
    )
}
