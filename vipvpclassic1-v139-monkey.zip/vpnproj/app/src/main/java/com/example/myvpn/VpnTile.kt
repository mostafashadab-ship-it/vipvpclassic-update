package com.example.myvpn

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.Icon
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnManager
import android.net.VpnService
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class VpnTile : TileService() {

    companion object {
        // After the user turns the VPN off from the tile, ignore a still-up network for a few seconds.
        @Volatile private var offUntil = 0L
    }

    private var registered = false
    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            refresh()
        }
    }

    private fun savedState(): String =
        getSharedPreferences("servers", MODE_PRIVATE).getString("state", "Disconnected") ?: "Disconnected"

    private fun prefsActive(): Boolean {
        val s = savedState()
        return s.startsWith("Connecting") || s.startsWith("Testing") || s.startsWith("Connected")
    }

    private fun ownServiceRunning(): Boolean = ConnService.running || L2tpVpnService.running

    // True only when the active network is a VPN created by THIS app. Before, any VPN (another
    // filter-breaker app, for example) made this tile light up as "Connected".
    // On Android 12+ the network says which app owns it; older versions fall back to the saved state.
    private fun ownVpnUp(): Boolean = if (System.currentTimeMillis() < offUntil) false else try {
        if (Build.VERSION.SDK_INT < 31) {
            false
        } else {
            val cm = getSystemService(ConnectivityManager::class.java)
            val nc = cm.getNetworkCapabilities(cm.activeNetwork)
            nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN) &&
                nc.ownerUid == android.os.Process.myUid()
        }
    } catch (_: Exception) {
        false
    }

    // The saved state only counts while one of our services is alive (so it cannot be stale).
    private fun isActive(): Boolean =
        (prefsActive() && ownServiceRunning() && System.currentTimeMillis() >= offUntil) || ownVpnUp()

    override fun onTileAdded() {
        super.onTileAdded()
        refresh()
    }

    override fun onStartListening() {
        super.onStartListening()
        // Update live while the panel is open.
        if (!registered) {
            val f = IntentFilter(ConnService.ACTION_STATE)
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(rx, f)
            }
            registered = true
        }
        refresh()
    }

    override fun onStopListening() {
        if (registered) {
            try {
                unregisterReceiver(rx)
            } catch (_: Exception) {
            }
            registered = false
        }
        super.onStopListening()
    }

    private fun refresh(forceOff: Boolean = false) {
        val tile = qsTile ?: return
        val active = !forceOff && isActive()
        val s = if (forceOff) "Disconnected" else savedState()
        tile.label = "vipvpclassic1"
        tile.icon = Icon.createWithResource(this, R.drawable.ic_tile)
        tile.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        // If our own VPN is up but the saved state is old, still show "Connected".
        tile.subtitle = if (active && !prefsActive()) Lang.state(this, "Connected") else Lang.state(this, s)
        tile.updateTile()
    }

    // Which protocol the tile should use: the one used last. Android < 14 can only do L2TP.
    private fun l2tpMode(): Boolean =
        Build.VERSION.SDK_INT < 34

    override fun onClick() {
        super.onClick()
        if (isActive()) {
            if (Build.VERSION.SDK_INT >= 34) {
                try {
                    (getSystemService(VPN_MANAGEMENT_SERVICE) as VpnManager).stopProvisionedVpnProfile()
                } catch (_: Exception) {
                }
            }
            stopService(Intent(this, ConnService::class.java))
            L2tpVpnService.requestStop(this)
            getSharedPreferences("servers", MODE_PRIVATE).edit().putString("state", "Disconnected").putString("detail", "").apply()
            sendBroadcast(Intent(ConnService.ACTION_STATE).setPackage(packageName))
            offUntil = System.currentTimeMillis() + 5000
            refresh(forceOff = true)
        } else if (l2tpMode()) {
            // The VPN permission dialog can only be shown by the app itself.
            if (VpnService.prepare(this) != null) {
                openApp()
                return
            }
            try {
                startForegroundService(Intent(this, L2tpVpnService::class.java).setAction(L2tpVpnService.ACTION_CONNECT))
            } catch (_: Exception) {
                openApp()
            }
        } else {
            try {
                startForegroundService(Intent(this, ConnService::class.java).setAction(ConnService.ACTION_CONNECT).putExtra(ConnService.EXTRA_FALLBACK, true))
            } catch (_: Exception) {
                openApp()
            }
        }
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}
