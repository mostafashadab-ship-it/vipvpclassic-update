package com.example.myvpn

import android.os.Handler
import android.os.Looper
import com.example.myvpn.cisco.CiscoClient
import com.example.myvpn.l2tp.L2tpClient
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * Checks the User ID / password against the real servers before the login screen lets the user in.
 * Same order as the automatic connection: first ALL L2TP servers are asked (together, each only up to the moment
 * the server says "accepted" or "refused"; no VPN tunnel is created). Only if none of them accepts, the Cisco
 * servers (AnyConnect login over HTTPS) are asked. The first server that accepts the login lets the user in.
 * "Refused" is reported only after both groups were asked and nobody accepted (one server may be out of date
 * or reject a login for its own reasons).
 */
object AuthCheck {
    enum class Result { OK, REFUSED, UNKNOWN }

    private const val L2TP_SERVER_MS = 10_000L
    private const val CISCO_SERVER_MS = 30_000L   // CiscoClient may try several TLS modes

    fun check(hosts: List<String>, user: String, pass: String, done: (Result) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        val list = hosts.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        if (list.isEmpty()) { main.post { done(Result.UNKNOWN) }; return }
        val l2 = list.filter { !L2tpVpnService.isCisco(it) }
        val ci = list.filter { L2tpVpnService.isCisco(it) }
        val finished = AtomicBoolean(false)
        val stoppers = CopyOnWriteArrayList<() -> Unit>()
        fun finish(r: Result) {
            if (finished.compareAndSet(false, true)) {
                stoppers.forEach { try { it() } catch (_: Throwable) {} }
                main.post { done(r) }
            }
        }
        thread(name = "auth-check", isDaemon = true) {
            var anyRefused = false
            for (group in listOf(l2, ci)) {
                if (group.isEmpty() || finished.get()) continue
                val results = CopyOnWriteArrayList<Result>()
                val latch = CountDownLatch(group.size)
                for (key in group) {
                    thread(name = "auth-one", isDaemon = true) {
                        val r = try { checkOne(key, user, pass, stoppers) } catch (_: Throwable) { Result.UNKNOWN }
                        if (r == Result.OK) finish(Result.OK)
                        results.add(r)
                        latch.countDown()
                    }
                }
                // Wait until every server of the group answered, or someone accepted.
                while (!finished.get() && !latch.await(200, TimeUnit.MILLISECONDS)) { }
                if (results.any { it == Result.REFUSED }) anyRefused = true
            }
            finish(if (anyRefused) Result.REFUSED else Result.UNKNOWN)
        }
    }

    // Asks one server. Never throws for network problems: those are UNKNOWN.
    private fun checkOne(key: String, user: String, pass: String, stoppers: MutableList<() -> Unit>): Result {
        val h = L2tpVpnService.plainOf(key)
        if (L2tpVpnService.isCisco(key)) {
            val ip = Dns.resolve4(h, null) { } ?: return Result.UNKNOWN
            val c = CiscoClient(h, ip, user, pass, { }, { }, object : CiscoClient.Events {
                override fun onUp(ip: ByteArray, dns: List<ByteArray>, mtu: Int) {}
                override fun onIpPacket(p: ByteArray) {}
            }, true)
            stoppers.add { c.stop() }
            val t = thread(name = "auth-run", isDaemon = true) { c.run() }
            t.join(CISCO_SERVER_MS)
            if (t.isAlive) { c.stop(); t.join(3000) }
            return when {
                c.authOk -> Result.OK
                (c.error ?: "").contains("login refused") -> Result.REFUSED
                else -> Result.UNKNOWN
            }
        }
        val c = L2tpClient(
            h, user, pass, L2tpProfileConfig.IPSEC_PSK.toByteArray(),
            { _ ->
                // Many checks run at the same time: every socket takes its own free port
                // (a shared port 4500 would deliver the answers to only one of them).
                val s = DatagramSocket(null)
                try { s.reuseAddress = true; s.bind(InetSocketAddress(0)) }
                catch (e: Throwable) { try { s.close() } catch (_: Throwable) {}; throw e }
                s
            },
            { }, // no log
            object : L2tpClient.Events {
                override fun onUp(ip: ByteArray, dns: List<ByteArray>, mtu: Int) {}
                override fun onIpPacket(p: ByteArray) {}
            },
            true
        )
        stoppers.add { c.stop() }
        val t = thread(name = "auth-run", isDaemon = true) { c.run() }
        t.join(L2TP_SERVER_MS)
        if (t.isAlive) { c.stop(); t.join(3000) }
        return when {
            c.authOk -> Result.OK
            (c.error ?: "").contains("login refused") -> Result.REFUSED
            else -> Result.UNKNOWN
        }
    }
}
