package com.example.myvpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.service.quicksettings.TileService
import com.example.myvpn.l2tp.Ike
import com.example.myvpn.l2tp.L2tpClient
import android.system.ErrnoException
import android.system.Os
import android.system.OsConstants
import android.system.StructPollfd
import java.io.FileOutputStream
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import com.example.myvpn.cisco.CiscoClient

/**
 * L2TP/IPsec (PSK) client. Works on every Android version the app installs on (10+) because the whole
 * protocol stack (IKEv1, ESP over UDP 4500, L2TP, PPP) runs inside the app and talks to Android
 * only through a normal VpnService TUN interface.
 */
class L2tpVpnService : VpnService() {

    companion object {
        const val ACTION_CONNECT = "com.example.myvpn.L2TP_CONNECT"
        const val ACTION_DISCONNECT = "com.example.myvpn.L2TP_DISCONNECT"
        const val EXTRA_HOST = "host"

        // In the server list a Cisco AnyConnect server (SSL, TCP 443) is saved as "cisco:host"; everything else is L2TP.
        const val CISCO_PREFIX = "cisco:"
        fun isCisco(h: String) = h.startsWith(CISCO_PREFIX, true)
        fun plainOf(h: String) = if (isCisco(h)) h.substring(CISCO_PREFIX.length).trim() else h

        // Max time (ms) to wait for one server to bring the tunnel up before trying the next.
        const val SERVER_WAIT_MS = 12_000

        // Automatic mode, L2TP only: on WiFi the UDP 500 "ping" can be answered while the rest of IPsec
        // (UDP 4500 / ESP) is blocked. Such a server must not eat 12 s each before Cisco (TCP 443) gets a turn.
        const val L2TP_AUTO_WAIT_MS = 4_000
        // Automatic mode: every L2TP server is tried first (at most this many fails); then ONE Cisco server;
        // if it fails too, the rest continue in order.
        const val L2TP_FAILS_BEFORE_CISCO = 4
        // Cisco needs more time: several TLS modes may be tried (see CiscoClient.openTls).
        const val CISCO_WAIT_MS = 20_000
        // If L2TP failed and Cisco worked on WiFi, next time on WiFi Cisco goes first for this long.
        const val L2TP_BLOCKED_TTL_MS = 6L * 60 * 60 * 1000

        // How many times in a row the app silently reconnects after an unexpected drop.
        const val MAX_AUTO_RECONNECTS = 6

        @Volatile var running = false

        // Turns L2TP off from the app / tile. stopService() alone is NOT enough: while the VPN is up the
        // system stays bound to this VpnService, so Android keeps it alive and the TUN is never closed.
        // The explicit ACTION_DISCONNECT closes the TUN, which makes the system unbind and end the VPN.
        fun requestStop(ctx: Context) {
            if (running) {
                try {
                    ctx.startService(Intent(ctx, L2tpVpnService::class.java).setAction(ACTION_DISCONNECT))
                } catch (_: Throwable) {
                }
            }
            try {
                ctx.stopService(Intent(ctx, L2tpVpnService::class.java))
            } catch (_: Throwable) {
            }
        }
    }

    @Volatile private var cancel = false
    @Volatile private var userStop = false
    @Volatile private var stopped = false
    @Volatile private var destroyed = false
    @Volatile private var worker: Thread? = null
    // One running connection, L2TP or Cisco. The loop below does not care which.
    private class Conn(val stopFn: () -> Unit, val runFn: () -> Unit, val estFn: () -> Boolean, val errFn: () -> String?) {
        val established: Boolean get() = estFn()
        val error: String? get() = errFn()
        fun stop() = stopFn()
        fun run() = runFn()
    }

    @Volatile private var client: Conn? = null
    // Where packets read from the TUN go: the current L2TP or Cisco client.
    @Volatile private var sender: ((ByteArray) -> Unit)? = null
    @Volatile private var tun: ParcelFileDescriptor? = null
    @Volatile private var tunOut: FileOutputStream? = null
    private var state = "Disconnected"
    private var curProto: String? = null   // "Cisco" or "L2TP": the protocol of the server being tried / connected
    private var upSince = 0L

    // Set when the tunnel was ended because the phone's network went away / was suspended (for example
    // mobile data pausing during a phone call). Such drops are not counted as "bad server" drops.
    @Volatile private var netDrop = false

    // True if some normal (non-VPN) network can carry internet right now. VALIDATED is NOT required on
    // purpose: on some networks the Google connectivity check never succeeds although the internet works.
    private fun goodNetworkExists(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return try {
            cm.allNetworks.any { n ->
                val nc = cm.getNetworkCapabilities(n)
                nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    !nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN) &&
                    nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_SUSPENDED)
            }
        } catch (_: Throwable) { true }
    }

    // True if the phone's normal (non-VPN) internet comes through WiFi.
    private fun onWifi(): Boolean = try {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.allNetworks.any { n ->
            val nc = cm.getNetworkCapabilities(n)
            nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                !nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN) &&
                nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        }
    } catch (_: Throwable) { false }

    // Fast detection of a lost / suspended network: the L2TP sockets belong to the network that just went
    // away, so the tunnel is dead. Ending the client here lets the worker reconnect the moment the network
    // is back, instead of waiting for a timeout.
    private val netCb = object : ConnectivityManager.NetworkCallback() {
        private fun hit(why: String) {
            if (!cancel && state.startsWith("Connected")) {
                ConnLog.log(this@L2tpVpnService, "L2TP network $why -> reconnect when it is back")
                netDrop = true
                client?.stop()
            }
        }

        override fun onLost(network: Network) = hit("lost")

        override fun onCapabilitiesChanged(network: Network, nc: NetworkCapabilities) {
            if (!nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_SUSPENDED) && !goodNetworkExists()) hit("suspended")
        }
    }

    // Traffic counters for the dead-tunnel watchdog (packets we sent into the tunnel / got back from it).
    @Volatile private var lastIpRx = 0L
    @Volatile private var txSinceRx = 0
    @Volatile private var firstUnansweredTx = 0L

    // Proves that data really flows through the tunnel in BOTH directions (a TCP handshake or a DNS answer
    // must come back). Our own sockets are not protected, so they travel through the TUN. PPP being "up" only
    // proves that login worked, not that the server forwards traffic.
    private fun dataPathOk(maxMs: Int): Boolean {
        val targets = listOf("1.1.1.1" to 443, "8.8.8.8" to 443, "9.9.9.9" to 443, "208.67.222.222" to 443)
        val end = System.currentTimeMillis() + maxMs
        while (System.currentTimeMillis() < end && !cancel) {
            for ((ip, port) in targets) {
                if (cancel || System.currentTimeMillis() >= end) break
                try {
                    java.net.Socket().use { sk ->
                        sk.connect(InetSocketAddress(ip, port), 1500)
                        return true
                    }
                } catch (_: Throwable) {
                }
            }
            if (dnsAnswers("8.8.8.8")) return true
            try { Thread.sleep(300) } catch (_: Throwable) {}
        }
        return false
    }

    private fun dnsAnswers(server: String): Boolean = try {
        val q = byteArrayOf(
            0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0,
            7, 'e'.code.toByte(), 'x'.code.toByte(), 'a'.code.toByte(), 'm'.code.toByte(), 'p'.code.toByte(), 'l'.code.toByte(), 'e'.code.toByte(),
            3, 'c'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte(), 0, 0, 1, 0, 1
        )
        DatagramSocket().use { ds ->
            ds.soTimeout = 1500
            ds.send(java.net.DatagramPacket(q, q.size, InetAddress.getByName(server), 53))
            val buf = ByteArray(512)
            val rp = java.net.DatagramPacket(buf, buf.size)
            ds.receive(rp)
            rp.length >= 12 && buf[0] == 0x12.toByte() && buf[1] == 0x34.toByte()
        }
    } catch (_: Throwable) { false }

    private fun waitForNetwork(maxMs: Int) {
        var w = 0
        while (w < maxMs && !cancel) {
            if (goodNetworkExists()) return
            Thread.sleep(250); w += 250
        }
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("vpn_status", "VPN status", NotificationManager.IMPORTANCE_DEFAULT).apply {
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            })
            nm.createNotificationChannel(NotificationChannel("alerts", "Alerts", NotificationManager.IMPORTANCE_HIGH))
        } catch (_: Throwable) {
        }
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.registerNetworkCallback(
                NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                    .build(), netCb
            )
        } catch (_: Throwable) {
        }
        ConnLog.log(this, "L2TP service created (API " + Build.VERSION.SDK_INT + ")")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            when (intent?.action) {
                ACTION_CONNECT -> {
                    stopped = false
                    goForeground()
                    connect(intent.getStringExtra(EXTRA_HOST))
                }
                ACTION_DISCONNECT -> disconnect()
                else -> {}
            }
        } catch (e: Throwable) {
            try { setState("Error: " + e.javaClass.simpleName + ": " + (e.message ?: "")) } catch (_: Throwable) {}
        }
        return START_NOT_STICKY
    }

    override fun onRevoke() {
        // Another VPN app took over.
        ConnLog.log(this, "L2TP revoked by system")
        disconnect()
        super.onRevoke()
    }

    override fun onDestroy() {
        try { (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(netCb) } catch (_: Throwable) {}
        destroyed = true
        cancel = true
        stopped = true
        client?.stop()
        closeTun()
        running = false
        try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(1) } catch (_: Throwable) {}
        super.onDestroy()
    }

    private fun goForeground() {
        val attempts = ArrayList<() -> Unit>()
        if (Build.VERSION.SDK_INT >= 34) {
            attempts.add { startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) }
        }
        attempts.add { startForeground(1, buildNotification()) }
        for (a in attempts) {
            try { a(); return } catch (_: Throwable) {}
        }
        // A VpnService keeps working without a foreground notification; Android shows its own key icon.
    }

    // ---------- connection ----------
    private fun mk(port: Int): DatagramSocket {
        val s = DatagramSocket(null)
        try {
            s.reuseAddress = true
            if (!protect(s)) throw IllegalStateException("protect() failed")
            s.bind(InetSocketAddress(port))
        } catch (e: Throwable) {
            try { s.close() } catch (_: Throwable) {}
            throw e
        }
        return s
    }

    // One line about the phone's networks for the error log (wifi / cell, validated, own IP, other VPN).
    private fun netInfo(): String = try {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.allNetworks.mapNotNull { n ->
            val nc = cm.getNetworkCapabilities(n) ?: return@mapNotNull null
            val kind = when {
                nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "vpn"
                nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cell"
                nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "eth"
                else -> "other"
            }
            val ips = cm.getLinkProperties(n)?.linkAddresses?.joinToString("/") { it.address.hostAddress ?: "?" } ?: "?"
            kind + "(" + (if (n == cm.activeNetwork) "active," else "") +
                "validated=" + nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) + ",ip=" + ips + ")"
        }.joinToString(" ")
    } catch (_: Throwable) { "?" }

    private fun resolve(host: String): InetAddress? = try {
        Dns.resolve4(host, null) { m -> ConnLog.log(this, m) }
    } catch (_: Throwable) { null }

    private fun makeL2tp(host: String, user: String, pass: String, quick: Boolean = false): Conn {
        val c = L2tpClient(
            host, user, pass, L2tpProfileConfig.IPSEC_PSK.toByteArray(),
            { p -> mk(p) },
            { m -> ConnLog.log(this, "L2TP: $m") },
            object : L2tpClient.Events {
                override fun onUp(ip: ByteArray, dns: List<ByteArray>, mtu: Int) = openTun(null, ip, dns, mtu)
                override fun onIpPacket(p: ByteArray) {
                    lastIpRx = System.currentTimeMillis(); txSinceRx = 0; firstUnansweredTx = 0L
                    try { tunOut?.write(p) } catch (_: Throwable) {}
                }
            },
            false,
            quick
        )
        sender = { p -> c.sendIp(p) }
        return Conn({ c.stop() }, { c.run() }, { c.established }, { c.error })
    }

    private fun makeCisco(host: String, user: String, pass: String): Conn {
        val ip = resolve(host)
        if (ip == null) return Conn({}, {}, { false }, { "address not found" })
        val c = CiscoClient(
            host, ip, user, pass,
            { sk -> if (!protect(sk)) throw IllegalStateException("protect() failed") },
            { m -> ConnLog.log(this, "Cisco: $m") },
            object : CiscoClient.Events {
                override fun onUp(ip: ByteArray, dns: List<ByteArray>, mtu: Int) = openTun(null, ip, dns, mtu)
                override fun onIpPacket(p: ByteArray) {
                    lastIpRx = System.currentTimeMillis(); txSinceRx = 0; firstUnansweredTx = 0L
                    try { tunOut?.write(p) } catch (_: Throwable) {}
                }
            }
        )
        sender = { p -> c.sendIp(p) }
        return Conn({ c.stop() }, { c.run() }, { c.established }, { c.error })
    }

    // only = one server picked by the user. null = test all servers and use the best one.
    private fun connect(only: String?) {
        if (worker?.isAlive == true) return
        cancel = false
        userStop = false
        setDetail("")
        worker = thread(name = "l2tp-main") {
            try {
                run(only)
            } catch (e: Throwable) {
                try { setDetail("err:" + e.javaClass.simpleName + ": " + (e.message ?: "")) } catch (_: Throwable) {}
                setState("Error: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    private fun run(only: String?) {
        val prefs = getSharedPreferences("servers", MODE_PRIVATE)
        val user = prefs.getString("user", "") ?: ""
        val pass = prefs.getString("pass", "") ?: ""
        if (user.isEmpty() || pass.isEmpty()) {
            setState("Error: enter username and password")
            return
        }
        ConnLog.log(this, "L2TP connect start; networks: " + netInfo())
        // No internet on the phone: do not pretend to connect.
        if (!goodNetworkExists()) waitForNetwork(5000)
        if (cancel) return
        if (!goodNetworkExists()) {
            ConnLog.log(this, "L2TP: no internet on the phone")
            setDetail("nonet:")
            setState("Failed: no internet")
            return
        }
        setState("Testing servers...")

        // 1) Ask every server in parallel (real IKE handshake packet) and sort by answer time.
        val hosts = if (only != null) listOf(only) else L2tpServerPresets.load(prefs)
        if (hosts.isEmpty()) {
            setState("Add a server first")
            return
        }
        val rtt = HashMap<String, Long>()
        hosts.map { h ->
            thread {
                val ip = resolve(plainOf(h))
                val t = if (ip == null) -1L
                else if (isCisco(h)) CiscoClient.probe(ip, { sk -> if (!protect(sk)) throw IllegalStateException("protect() failed") }, 3000)
                else Ike.probe(ip, { p -> mk(p) }, 1200)
                synchronized(rtt) { rtt[h] = t }
            }
        }.forEach { it.join() }
        if (cancel) return
        ConnLog.log(this, "L2TP probe: " + hosts.joinToString { (if (isCisco(it)) "cisco-" else "") + plainOf(it).substringBefore('.') + "=" + (rtt[it] ?: -1) + (if ((rtt[it] ?: -1L) == -5L) "(socket error)" else "") })
        // Automatic mode: L2TP servers first (best ping first; the best one gets a second chance because a single
        // IKE packet is sometimes lost), Cisco servers only after every L2TP server failed.
        val l2 = hosts.filter { !isCisco(it) }
        val ci = hosts.filter { isCisco(it) }
        val l2ok = l2.filter { (rtt[it] ?: -1) >= 0 }.sortedBy { rtt[it] }
        val l2bad = l2.filter { (rtt[it] ?: -1) < 0 }
        val ciok = ci.filter { (rtt[it] ?: -1) >= 0 }.sortedBy { rtt[it] }
        val cibad = ci.filter { (rtt[it] ?: -1) < 0 }
        // A Cisco server that answers MUCH faster (less than half the best L2TP time) goes first.
        val bestL2 = l2ok.firstOrNull()?.let { rtt[it] ?: Long.MAX_VALUE } ?: Long.MAX_VALUE
        val ciFast = ciok.filter { (rtt[it] ?: Long.MAX_VALUE) * 2 < bestL2 }
        val ciRest = ciok.filter { it !in ciFast }
        val wifiNow = only == null && onWifi()
        val l2Blocked = wifiNow && System.currentTimeMillis() - prefs.getLong("l2_blocked_wifi", 0L) < L2TP_BLOCKED_TTL_MS
        val order = if (l2Blocked && ciok.isNotEmpty()) {
            ConnLog.log(this, "L2TP was blocked on WiFi recently -> Cisco first")
            ciok + cibad + l2ok + l2bad
        } else {
            ciFast.take(1) + l2ok + l2ok.take(1) + l2bad + ciFast.drop(1) + ciRest + cibad
        }
        var l2Fails = 0
        var ciPromoted = false
        val l2Tried = HashSet<String>()                 // L2TP host names already tried in this run
        val failedAt = HashMap<String, String>()        // "l|ip" / "c|ip" -> host that failed (same IP = same machine)

        var lastError = ""
        var refused = false
        var sawMaxLogin = false
        var drops = 0
        val queue = ArrayDeque(order)
        while (queue.isNotEmpty()) {
            // Automatic mode: all L2TP servers were tried (or 4 failed) -> ONE Cisco server next. If that fails
            // too, the rest go in order.
            if (only == null && !ciPromoted && !isCisco(queue.first())) {
                val l2Left = queue.any { !isCisco(it) && plainOf(it) !in l2Tried }
                if (l2Fails >= L2TP_FAILS_BEFORE_CISCO || !l2Left) {
                    val ck = queue.firstOrNull { isCisco(it) && (rtt[it] ?: -1L) >= 0 } ?: queue.firstOrNull { isCisco(it) }
                    if (ck != null) {
                        ciPromoted = true
                        queue.remove(ck); queue.addFirst(ck)
                        ConnLog.log(this, "L2TP failed $l2Fails time(s) -> trying one Cisco now")
                    }
                }
            }
            val key = queue.removeFirst()
            val cisco = isCisco(key)
            val host = plainOf(key)
            curProto = if (cisco) "Cisco" else "L2TP"
            if (cancel) return
            // Two names on the same IP are the same machine (Mu1 / Mu2, L2tp / Sstp2): do not repeat a failure.
            val ipStr = if (only == null) resolve(host)?.hostAddress else null
            val ipKey = (if (cisco) "c|" else "l|") + ipStr
            if (ipStr != null && failedAt[ipKey]?.let { !it.equals(host, true) } == true) {
                ConnLog.log(this, "skip $host: same address as " + failedAt[ipKey] + " which already failed")
                continue
            }
            if (!cisco) l2Tried.add(host)
            setState("Connecting: $host")
            ConnLog.log(this, (if (cisco) "Cisco" else "L2TP") + " try $host")
            // Automatic mode: a server that did not answer the quick probe only gets ~1.2 s, then the next one is tried.
            val quick = only == null && !cisco && (rtt[key] ?: -1L) < 0
            val c = if (cisco) makeCisco(host, user, pass) else makeL2tp(host, user, pass, quick)
            client = c
            val t = thread(name = "l2tp-client") { c.run() }
            var waited = 0
            val waitLimit = if (cisco) CISCO_WAIT_MS else if (only == null) L2TP_AUTO_WAIT_MS else SERVER_WAIT_MS
            // Wait until PPP is up AND the TUN exists (onUp sets "established" a moment before openTun finishes).
            while (waited < waitLimit && !(c.established && tun != null) && t.isAlive && !cancel) {
                Thread.sleep(250); waited += 250
            }
            if (cancel) { c.stop(); closeTun(); return }
            if (c.established && tun != null) {
                // Login worked. Before saying "Connected" make sure traffic really passes through this server.
                lastIpRx = 0L; txSinceRx = 0; firstUnansweredTx = 0L
                val okPath = t.isAlive && dataPathOk(8000)
                if (cancel) { c.stop(); closeTun(); return }
                if (!okPath) {
                    ConnLog.log(this, "L2TP $host: logged in but no traffic passes -> next server")
                    lastError = "no data through the tunnel"
                    if (ipStr != null) failedAt[ipKey] = host
                    if (!cisco) l2Fails++
                    c.stop()
                    t.join(4000)
                    closeTun()
                    continue
                }
                // Automatic mode: the country flag proves the server really carries data (the answer of a public
                // "which country is this IP" page comes back THROUGH the tunnel). Logged in but no answer = a server
                // that opens nothing, so drop it and go to the next one instead of showing "Connected".
                if (only == null) {
                    val code = fetchCountry(7000)
                    if (cancel) { c.stop(); closeTun(); return }
                    if (code == null) {
                        ConnLog.log(this, (if (cisco) "Cisco" else "L2TP") + " $host: logged in but no country/flag answer through the tunnel -> next server")
                        lastError = "no data through the tunnel (no country answer)"
                        if (ipStr != null) failedAt[ipKey] = host
                        if (!cisco) l2Fails++
                        c.stop()
                        t.join(4000)
                        closeTun()
                        continue
                    }
                    saveCountry(host, code)
                } else {
                    lookupCountry(host)
                }
                if (only == null && cisco && l2Fails >= L2TP_FAILS_BEFORE_CISCO && wifiNow)
                    prefs.edit().putLong("l2_blocked_wifi", System.currentTimeMillis()).apply()
                else if (only == null && !cisco && wifiNow)
                    prefs.edit().remove("l2_blocked_wifi").apply()
                ConnLog.log(this, (if (cisco) "Cisco" else "L2TP") + " connected $host after ${waited}ms")
                upSince = System.currentTimeMillis()
                setState("Connected: $host")
                while (t.isAlive && !cancel) {
                    Thread.sleep(500)
                    // Watchdog: we keep sending but nothing ever comes back -> the tunnel is dead, switch server.
                    val fu = firstUnansweredTx
                    if (fu != 0L && txSinceRx >= 8 && System.currentTimeMillis() - fu > 30_000 &&
                        System.currentTimeMillis() - maxOf(lastIpRx, upSince) > 30_000) {
                        ConnLog.log(this, "L2TP: no data coming back for 30 s -> reconnect")
                        c.stop()
                        break
                    }
                }
                if (cancel) {
                    // The user turned it off: disconnect() already published the state.
                    closeTun()
                    return
                }
                val secs = (System.currentTimeMillis() - upSince) / 1000
                ConnLog.log(this, "L2TP dropped after ${secs}s: " + (c.error ?: ""))
                closeTun()
                c.stop()
                t.join(1500)
                val byNetwork = netDrop
                netDrop = false
                // A connection that stayed up for a while was healthy: start counting again.
                if (secs >= 30) drops = 0
                l2Fails = 0; ciPromoted = false
                if (!byNetwork) drops++ // the phone losing its network says nothing about the server
                if (drops > MAX_AUTO_RECONNECTS) {
                    setDetail("dropped:$secs")
                    setState("Disconnected")
                    return
                }
                // Auto failover: go to ANOTHER server at once (the one that just dropped is tried last).
                queue.clear()
                val all = order.distinct()
                queue.addAll(all.filter { it != key })
                queue.addLast(key)
                ConnLog.log(this, "L2TP auto reconnect #$drops -> " + queue.first())
                setState("Connecting: " + plainOf(queue.first()))
                // After a network loss (phone call, tunnel, airplane mode...) wait up to 2 minutes for it to return.
                waitForNetwork(if (byNetwork) 120_000 else 10_000)
                if (cancel) return
                var w = 0
                while (w < 300 && !cancel) { Thread.sleep(100); w += 100 }
                lastError = c.error ?: "dropped"
                continue
            }
            lastError = c.error ?: "no answer"
            if (!cisco) l2Fails++
            if (ipStr != null && !lastError.contains("login refused")) failedAt[ipKey] = host
            ConnLog.log(this, "L2TP failed on $host: $lastError")
            if (lastError.contains("max-login")) sawMaxLogin = true
            c.stop()
            t.join(4000)
            closeTun()
            if (lastError.contains("login refused")) {
                // Automatic mode with Cisco servers still waiting: an L2TP server that refuses the login must not
                // stop the run (the L2TP servers may not know the account); go on, Cisco gets its turn.
                if (only == null && !cisco && queue.any { isCisco(it) }) {
                    ConnLog.log(this, "L2TP login refused on $host -> going on with the next server")
                } else {
                    // Wrong password / expired account: other servers would say the same.
                    refused = true
                    break
                }
            }
        }
        if (cancel) return
        if (!cancel) {
            if (sawMaxLogin) {
                // Password was accepted, but the account still has an old session open on the server.
                setDetail("l2tpmax:")
                setState("Failed: no server connected")
                alertExpired()
            } else if (refused) {
                setDetail("l2tpauth:")
                setState("Failed: no server connected")
                alertExpired()
            } else if (lastError.contains("no data")) {
                setDetail("l2tpnodata:")
                setState("Failed: no server connected")
                alertNoData()
            } else {
                setDetail("l2tpfail:$lastError")
                setState("Failed: no server connected")
                alertExpired()
            }
        }
    }

    private fun alertNoData() {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val text = if (Lang.isFa(this)) {
                "به سرور وصل شد ولی هیچ داده‌ای رد نشد. شبکه را عوض کن (نت گوشی / وای‌فای دیگر) یا بعداً دوباره امتحان کن."
            } else {
                "Connected to the server but no data passed. Try another network (mobile data / other WiFi) or try again later."
            }
            nm.notify(2, Notification.Builder(this, "alerts")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("vipvpclassic1")
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(open)
                .build())
        } catch (_: Throwable) {
        }
    }

    // The L2TP host names (l2tp, l3tp...) do not say where the server is. After the tunnel is up, ask a
    // public "which country is this IP" page THROUGH the tunnel, remember the answer per server and tell the
    // app, which then shows the country flag like it does for IKEv2.
    private fun lookupCountry(host: String) {
        thread(name = "l2tp-geo") {
            try { Thread.sleep(800) } catch (_: Throwable) {}
            val sources = listOf("https://api.country.is/" to "country", "https://ipwho.is/?fields=country_code" to "country_code")
            for ((url, key) in sources) {
                if (cancel || destroyed) return@thread
                try {
                    val con = URL(url).openConnection() as HttpURLConnection
                    con.connectTimeout = 4000
                    con.readTimeout = 4000
                    val body = con.inputStream.bufferedReader().use { it.readText() }
                    val code = Regex("\"" + key + "\"\\s*:\\s*\"([A-Za-z]{2})\"").find(body)?.groupValues?.get(1)?.uppercase()
                    if (code != null) {
                        getSharedPreferences("servers", MODE_PRIVATE).edit().putString("l2c_" + host.lowercase(), code).apply()
                        ConnLog.log(this, "L2TP exit country $host = $code")
                        sendBroadcast(Intent(ConnService.ACTION_STATE).setPackage(packageName))
                        return@thread
                    }
                } catch (_: Throwable) {
                }
            }
        }
    }

    // Asks several public "which country is this IP" pages at once through the tunnel; first valid answer wins.
    private fun fetchCountry(maxMs: Long): String? {
        val sources = listOf(
            Triple("https://api.country.is/", "country", true),
            Triple("https://ipwho.is/?fields=country_code", "country_code", true),
            Triple("https://ipapi.co/country/", "", false),
            Triple("https://ifconfig.co/country-iso", "", false)
        )
        val found = java.util.concurrent.atomic.AtomicReference<String?>(null)
        val latch = java.util.concurrent.CountDownLatch(1)
        for ((url, key, json) in sources) {
            thread(name = "l2tp-geo-check", isDaemon = true) {
                try {
                    val con = URL(url).openConnection() as HttpURLConnection
                    con.connectTimeout = 4000
                    con.readTimeout = 4000
                    con.setRequestProperty("User-Agent", "curl/8.0")
                    val body = con.inputStream.bufferedReader().use { it.readText() }
                    val code = if (json) {
                        Regex("\"" + key + "\"\\s*:\\s*\"([A-Za-z]{2})\"").find(body)?.groupValues?.get(1)
                    } else {
                        body.trim().takeIf { it.length == 2 && it.all { ch -> ch.isLetter() } }
                    }
                    if (code != null && found.compareAndSet(null, code.uppercase())) latch.countDown()
                } catch (_: Throwable) {
                }
            }
        }
        try { latch.await(maxMs, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: InterruptedException) {}
        return found.get()
    }

    private fun saveCountry(host: String, code: String) {
        getSharedPreferences("servers", MODE_PRIVATE).edit().putString("l2c_" + host.lowercase(), code).apply()
        ConnLog.log(this, "L2TP exit country $host = $code")
        sendBroadcast(Intent(ConnService.ACTION_STATE).setPackage(packageName))
    }

    private fun c0(): Any? = client

    private fun openTun(c: Any?, ip: ByteArray, dns: List<ByteArray>, mtu: Int) {
        closeTun()
        val b = Builder()
            .setSession("vipvpclassic1")
            .setMtu(mtu.coerceIn(1200, 1500))
            .addAddress(InetAddress.getByAddress(ip), 32)
            .addRoute("0.0.0.0", 0)
        var any = false
        for (d in dns) { try { b.addDnsServer(InetAddress.getByAddress(d)); any = true } catch (_: Throwable) {} }
        // Public DNS as a fallback after the server's own DNS: if the server's DNS is dead nothing would open.
        try { b.addDnsServer("8.8.8.8"); b.addDnsServer("1.1.1.1") } catch (_: Throwable) {}
        // Non-blocking + poll: a thread blocked in read() would keep the TUN (and the key icon) alive after close().
        b.setBlocking(false)
        // The tunnel carries IPv4 only: send IPv6 into the TUN as well so it cannot leak around the VPN.
        try { b.addRoute("::", 0) } catch (_: Throwable) {}
        val fd: ParcelFileDescriptor? = b.establish()
        if (fd == null) throw IllegalStateException("VPN permission was revoked")
        tun = fd
        val out = FileOutputStream(fd.fileDescriptor)
        tunOut = out
        val send = sender ?: return
        thread(name = "tun-read") {
            val buf = ByteArray(32767)
            val pfd = StructPollfd()
            pfd.fd = fd.fileDescriptor
            pfd.events = OsConstants.POLLIN.toShort()
            val arr = arrayOf(pfd)
            try {
                while (!cancel && tun === fd) {
                    pfd.revents = 0
                    if (Os.poll(arr, 200) <= 0) continue
                    val n = try { Os.read(fd.fileDescriptor, buf, 0, buf.size) } catch (e: ErrnoException) {
                        if (e.errno == OsConstants.EAGAIN || e.errno == OsConstants.EINTR) continue
                        throw e
                    }
                    if (n <= 0) continue
                    val ver = buf[0].toInt() ushr 4
                    if (ver == 4) {
                        if (txSinceRx == 0) firstUnansweredTx = System.currentTimeMillis()
                        txSinceRx++
                        send(buf.copyOf(n))
                    }
                    else if (ver == 6) rejectV6(buf, n) // tunnel is IPv4 only: answer "unreachable" so apps (Telegram...) fall back to IPv4 at once
                }
            } catch (_: Throwable) {
            }
        }
    }

    // Answers an IPv6 packet from the TUN with ICMPv6 "destination unreachable" so the app gives up on IPv6
    // immediately instead of waiting for a timeout (silently dropping it makes Telegram hang).
    private fun rejectV6(p: ByteArray, n: Int) {
        if (n < 40) return
        val nh = p[6].toInt() and 0xff
        if (nh == 58 || (p[24].toInt() and 0xff) == 0xff) return // never answer ICMPv6 or multicast
        val out = tunOut ?: return
        val body = minOf(n, 1232)
        val len = 8 + body
        val r = ByteArray(40 + len)
        r[0] = 0x60
        r[4] = (len shr 8).toByte(); r[5] = len.toByte()
        r[6] = 58; r[7] = 64
        System.arraycopy(p, 24, r, 8, 16)   // source = the address that was tried
        System.arraycopy(p, 8, r, 24, 16)   // destination = the app
        r[40] = 1; r[41] = 0                // type 1 (unreachable), code 0 (no route)
        System.arraycopy(p, 0, r, 48, body)
        var sum = 0L
        var i = 8
        while (i < 40) { sum += ((r[i].toInt() and 0xff) shl 8) or (r[i + 1].toInt() and 0xff); i += 2 }
        sum += len.toLong() + 58L
        i = 40
        while (i + 1 < 40 + len) { sum += ((r[i].toInt() and 0xff) shl 8) or (r[i + 1].toInt() and 0xff); i += 2 }
        if (len % 2 == 1) sum += (r[39 + len].toInt() and 0xff) shl 8
        while ((sum shr 16) != 0L) sum = (sum and 0xffff) + (sum shr 16)
        val ck = sum.inv().toInt() and 0xffff
        r[42] = (ck shr 8).toByte(); r[43] = ck.toByte()
        try { out.write(r) } catch (_: Throwable) {}
    }

    private fun closeTun() {
        try { tunOut?.close() } catch (_: Throwable) {}
        tunOut = null
        try { tun?.close() } catch (_: Throwable) {}
        tun = null
    }

    private fun disconnect() {
        ConnLog.log(this, "L2TP user disconnect")
        cancel = true
        userStop = true
        setDetail("")
        client?.stop()
        closeTun()
        setState("Disconnected")
    }

    // ---------- state + notification ----------
    private fun setDetail(d: String) {
        getSharedPreferences("servers", MODE_PRIVATE).edit().putString("detail", d).apply()
    }

    private fun setState(s: String) {
        // After onDestroy the caller (app / tile) has already saved the final state. A late update from the
        // worker thread must not overwrite what another connection (for example IKEv2) wrote meanwhile.
        if (destroyed) return
        state = s
        ConnLog.log(this, "L2TP state=$s")
        val p = getSharedPreferences("servers", MODE_PRIVATE)
        if (s.startsWith("Connected")) p.edit().putInt("quick_drops", 0).apply()
        p.edit().putString("state", s).putString("mode", "l2tp").apply()
        sendBroadcast(Intent(ConnService.ACTION_STATE).setPackage(packageName))
        try {
            TileService.requestListeningState(this, ComponentName(this, VpnTile::class.java))
        } catch (_: Exception) {
        }
        val active = s.startsWith("Connecting") || s.startsWith("Testing") || s.startsWith("Connected")
        if (active) {
            if (!stopped) try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, buildNotification()) } catch (_: Throwable) {}
        } else {
            stopped = true
            try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
            try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(1) } catch (_: Throwable) {}
            stopSelf()
        }
    }

    // The "could not connect / service may be finished" notification was removed on request.
    // The reason is still shown inside the app (detail text under the status).
    private fun alertExpired() {
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val off = PendingIntent.getService(
            this, 3, Intent(this, L2tpVpnService::class.java).setAction(ACTION_DISCONNECT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_lock_power_off),
            if (Lang.isFa(this)) "قطع اتصال" else "Disconnect", off
        ).build()
        val b = Notification.Builder(this, "vpn_status")
            .setSmallIcon(R.drawable.ic_tile)
            // once a server is being tried / is connected the title names the protocol really used
            .setContentTitle(
                if (state.startsWith("Connecting") || state.startsWith("Connected")) curProto ?: (if (Lang.isFa(this)) "Cisco و L2TP" else "Cisco & L2TP")
                else if (Lang.isFa(this)) "Cisco و L2TP" else "Cisco & L2TP"
            )
            .setContentText(Lang.state(this, state))
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(action)
            .setOnlyAlertOnce(true)
        // Android 12+ delays foreground-service notifications by ~10 s unless this is set.
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        return b.build()
    }
}
