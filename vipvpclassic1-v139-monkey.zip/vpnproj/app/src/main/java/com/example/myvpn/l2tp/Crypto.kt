package com.example.myvpn.l2tp

import java.io.ByteArrayOutputStream
import java.math.BigInteger
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Small byte helpers shared by the IKE / L2TP / PPP code. Pure Kotlin, no Android classes. */
class W {
    private val o = ByteArrayOutputStream()
    fun u8(v: Int): W { o.write(v and 0xFF); return this }
    fun u16(v: Int): W { o.write((v shr 8) and 0xFF); o.write(v and 0xFF); return this }
    fun u32(v: Long): W { u16(((v shr 16) and 0xFFFF).toInt()); u16((v and 0xFFFF).toInt()); return this }
    fun u32(v: Int): W = u32(v.toLong() and 0xFFFFFFFFL)
    fun b(x: ByteArray): W { o.write(x, 0, x.size); return this }
    fun b(x: ByteArray, off: Int, len: Int): W { o.write(x, off, len); return this }
    fun size() = o.size()
    fun bytes(): ByteArray = o.toByteArray()
}

class R(val d: ByteArray, var p: Int = 0, val end: Int = d.size) {
    fun left() = end - p
    fun u8(): Int { if (p >= end) throw IllegalStateException("short"); return d[p++].toInt() and 0xFF }
    fun u16(): Int = (u8() shl 8) or u8()
    fun u32(): Long = (u16().toLong() shl 16) or u16().toLong()
    fun b(n: Int): ByteArray {
        if (n < 0 || p + n > end) throw IllegalStateException("short")
        val r = d.copyOfRange(p, p + n); p += n; return r
    }
    fun rest(): ByteArray = b(left())
}

fun ByteArray.hex(): String = joinToString("") { "%02x".format(it.toInt() and 0xFF) }
fun be32(d: ByteArray, o: Int): Long =
    ((d[o].toLong() and 0xFF) shl 24) or ((d[o + 1].toLong() and 0xFF) shl 16) or
        ((d[o + 2].toLong() and 0xFF) shl 8) or (d[o + 3].toLong() and 0xFF)
fun be16(d: ByteArray, o: Int): Int = ((d[o].toInt() and 0xFF) shl 8) or (d[o + 1].toInt() and 0xFF)

object Crypto {
    val rnd = SecureRandom()
    fun random(n: Int): ByteArray = ByteArray(n).also { rnd.nextBytes(it) }

    fun hashName(ike: Int) = when (ike) {
        1 -> "MD5"; 2 -> "SHA-1"; 4 -> "SHA-256"; 5 -> "SHA-384"; 6 -> "SHA-512"
        else -> throw IllegalArgumentException("hash $ike")
    }
    fun macName(ike: Int) = when (ike) {
        1 -> "HmacMD5"; 2 -> "HmacSHA1"; 4 -> "HmacSHA256"; 5 -> "HmacSHA384"; 6 -> "HmacSHA512"
        else -> throw IllegalArgumentException("mac $ike")
    }

    fun hash(alg: String, vararg parts: ByteArray): ByteArray {
        val md = MessageDigest.getInstance(alg)
        for (p in parts) md.update(p)
        return md.digest()
    }

    fun hmac(alg: String, key: ByteArray, vararg parts: ByteArray): ByteArray {
        val m = Mac.getInstance(alg)
        m.init(SecretKeySpec(if (key.isEmpty()) ByteArray(1) else key, alg))
        for (p in parts) m.update(p)
        return m.doFinal()
    }

    fun concat(vararg parts: ByteArray): ByteArray {
        val w = W(); for (p in parts) w.b(p); return w.bytes()
    }

    // ---------- Diffie-Hellman (RFC 2409 / 3526 MODP groups, generator 2) ----------
    private const val P1024 = "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece65381ffffffffffffffff"
    private const val P1536 = "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca237327ffffffffffffffff"
    private const val P2048 = "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aacaa68ffffffffffffffff"

    class DhGroup(val id: Int, val p: BigInteger) {
        val len = (p.bitLength() + 7) / 8
    }
    val groups: Map<Int, DhGroup> = mapOf(
        2 to DhGroup(2, BigInteger(P1024, 16)),
        5 to DhGroup(5, BigInteger(P1536, 16)),
        14 to DhGroup(14, BigInteger(P2048, 16))
    )
    private val TWO = BigInteger.valueOf(2)

    class DhPair(val g: DhGroup) {
        private val priv: BigInteger = run {
            var x: BigInteger
            do { x = BigInteger(320, rnd) } while (x.bitLength() < 200)
            x
        }
        val pub: ByteArray = fixed(TWO.modPow(priv, g.p), g.len)
        fun shared(peerPub: ByteArray): ByteArray {
            val y = BigInteger(1, peerPub)
            if (y <= BigInteger.ONE || y >= g.p.subtract(BigInteger.ONE)) throw IllegalStateException("bad DH public value")
            return fixed(y.modPow(priv, g.p), g.len)
        }
    }

    fun fixed(v: BigInteger, len: Int): ByteArray {
        val raw = v.toByteArray()
        val out = ByteArray(len)
        val src = if (raw.size > len) raw.copyOfRange(raw.size - len, raw.size) else raw
        System.arraycopy(src, 0, out, len - src.size, src.size)
        return out
    }

    // ---------- CBC helpers ----------
    fun cbc(encrypt: Boolean, des3: Boolean, key: ByteArray, iv: ByteArray, data: ByteArray): ByteArray {
        val c = if (des3) Cipher.getInstance("DESede/CBC/NoPadding") else Cipher.getInstance("AES/CBC/NoPadding")
        c.init(
            if (encrypt) Cipher.ENCRYPT_MODE else Cipher.DECRYPT_MODE,
            SecretKeySpec(key, if (des3) "DESede" else "AES"),
            javax.crypto.spec.IvParameterSpec(iv)
        )
        return c.doFinal(data)
    }
}

/** MD4 (RFC 1320). Needed for the MS-CHAP NT password hash; JCA has no MD4. */
object Md4 {
    fun digest(msg: ByteArray): ByteArray {
        val n = msg.size
        val padLen = ((56 - (n + 1) % 64) + 64) % 64
        val total = n + 1 + padLen + 8
        val buf = ByteArray(total)
        System.arraycopy(msg, 0, buf, 0, n)
        buf[n] = 0x80.toByte()
        val bits = n.toLong() * 8
        for (i in 0 until 8) buf[total - 8 + i] = ((bits ushr (8 * i)) and 0xFF).toByte()
        var a = 0x67452301; var b = 0xefcdab89.toInt(); var c = 0x98badcfe.toInt(); var d = 0x10325476
        val x = IntArray(16)
        var off = 0
        while (off < total) {
            for (i in 0 until 16) {
                x[i] = (buf[off + i * 4].toInt() and 0xFF) or ((buf[off + i * 4 + 1].toInt() and 0xFF) shl 8) or
                    ((buf[off + i * 4 + 2].toInt() and 0xFF) shl 16) or ((buf[off + i * 4 + 3].toInt() and 0xFF) shl 24)
            }
            val aa = a; val bb = b; val cc = c; val dd = d
            fun f(x: Int, y: Int, z: Int) = (x and y) or (x.inv() and z)
            fun g(x: Int, y: Int, z: Int) = (x and y) or (x and z) or (y and z)
            fun h(x: Int, y: Int, z: Int) = x xor y xor z
            fun rol(v: Int, s: Int) = (v shl s) or (v ushr (32 - s))
            val s1 = intArrayOf(3, 7, 11, 19)
            for (i in 0 until 16) {
                val t = rol(a + f(b, c, d) + x[i], s1[i % 4])
                a = d; d = c; c = b; b = t
            }
            val s2 = intArrayOf(3, 5, 9, 13)
            val o2 = intArrayOf(0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15)
            for (i in 0 until 16) {
                val t = rol(a + g(b, c, d) + x[o2[i]] + 0x5a827999, s2[i % 4])
                a = d; d = c; c = b; b = t
            }
            val s3 = intArrayOf(3, 9, 11, 15)
            val o3 = intArrayOf(0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15)
            for (i in 0 until 16) {
                val t = rol(a + h(b, c, d) + x[o3[i]] + 0x6ed9eba1, s3[i % 4])
                a = d; d = c; c = b; b = t
            }
            a += aa; b += bb; c += cc; d += dd
            off += 64
        }
        val out = ByteArray(16)
        for ((k, v) in intArrayOf(a, b, c, d).withIndex()) for (i in 0 until 4) out[k * 4 + i] = ((v ushr (8 * i)) and 0xFF).toByte()
        return out
    }
}

/** MS-CHAP v2 (RFC 2759). */
object MsChapV2 {
    private fun desKey(k7: ByteArray): ByteArray {
        val k = ByteArray(8)
        k[0] = k7[0]
        k[1] = (((k7[0].toInt() and 0x01) shl 7) or ((k7[1].toInt() and 0xFF) ushr 1)).toByte()
        k[2] = (((k7[1].toInt() and 0x03) shl 6) or ((k7[2].toInt() and 0xFF) ushr 2)).toByte()
        k[3] = (((k7[2].toInt() and 0x07) shl 5) or ((k7[3].toInt() and 0xFF) ushr 3)).toByte()
        k[4] = (((k7[3].toInt() and 0x0F) shl 4) or ((k7[4].toInt() and 0xFF) ushr 4)).toByte()
        k[5] = (((k7[4].toInt() and 0x1F) shl 3) or ((k7[5].toInt() and 0xFF) ushr 5)).toByte()
        k[6] = (((k7[5].toInt() and 0x3F) shl 2) or ((k7[6].toInt() and 0xFF) ushr 6)).toByte()
        k[7] = ((k7[6].toInt() and 0x7F) shl 1).toByte()
        for (i in 0 until 8) {
            var b = k[i].toInt() and 0xFE
            var ones = Integer.bitCount(b)
            if (ones % 2 == 0) b = b or 1
            k[i] = b.toByte()
        }
        return k
    }

    // Single DES via 3DES with K1=K2=K3 (works on every JCA provider).
    private fun desEcb(k7: ByteArray, data: ByteArray): ByteArray {
        val k8 = desKey(k7)
        val c = Cipher.getInstance("DESede/ECB/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(k8 + k8 + k8, "DESede"))
        return c.doFinal(data)
    }

    fun ntPasswordHash(password: String): ByteArray = Md4.digest(password.toByteArray(Charsets.UTF_16LE))

    fun challengeHash(peerChallenge: ByteArray, authChallenge: ByteArray, user: String): ByteArray =
        Crypto.hash("SHA-1", peerChallenge, authChallenge, user.toByteArray(Charsets.UTF_8)).copyOf(8)

    fun ntResponse(challenge8: ByteArray, pwHash: ByteArray): ByteArray {
        val z = pwHash.copyOf(21)
        return desEcb(z.copyOfRange(0, 7), challenge8) + desEcb(z.copyOfRange(7, 14), challenge8) +
            desEcb(z.copyOfRange(14, 21), challenge8)
    }

    fun generateNtResponse(authChallenge: ByteArray, peerChallenge: ByteArray, user: String, password: String): ByteArray =
        ntResponse(challengeHash(peerChallenge, authChallenge, user), ntPasswordHash(password))

    private val MAGIC1 = "Magic server to client signing constant".toByteArray(Charsets.US_ASCII)
    private val MAGIC2 = "Pad to make it do more than one iteration".toByteArray(Charsets.US_ASCII)

    fun authenticatorResponse(password: String, ntResp: ByteArray, peerChallenge: ByteArray, authChallenge: ByteArray, user: String): String {
        val pwHashHash = Md4.digest(ntPasswordHash(password))
        val digest = Crypto.hash("SHA-1", pwHashHash, ntResp, MAGIC1)
        val ch = challengeHash(peerChallenge, authChallenge, user)
        val resp = Crypto.hash("SHA-1", digest, ch, MAGIC2)
        return "S=" + resp.hex().uppercase()
    }
}
