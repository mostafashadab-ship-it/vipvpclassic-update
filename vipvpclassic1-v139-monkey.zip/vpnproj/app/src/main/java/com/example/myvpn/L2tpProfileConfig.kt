package com.example.myvpn

/**
 * User-provided L2TP/IPSec profile defaults.
 *
 * The username and password are deliberately NOT hard-coded. The app must
 * collect them from the user at runtime and pass the same credentials to
 * whichever protocol the user selects.
 *
 * The tunnel itself lives in the l2tp package and L2tpVpnService.
 */
object L2tpProfileConfig {
    const val IPSEC_PSK: String = "123456"

    val defaultServers: List<String> = listOf(
        "L2tp.gsmxr.net",
        "L3tp.gsmxr.net",
        "L4tp.gsmxr.net",
        "L6tp.gsmxr.net",
        "Sstp2.gsmxr.net"
    )

    data class Credentials(
        val username: String,
        val password: String
    )
}
