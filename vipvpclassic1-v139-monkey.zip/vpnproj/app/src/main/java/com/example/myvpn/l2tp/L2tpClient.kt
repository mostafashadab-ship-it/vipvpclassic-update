package com.example.myvpn.l2tp

import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit

/**
 * One complete L2TP/IPsec connection: IKEv1 + ESP (NAT-T) + L2TP + PPP. Contains no Android classes so it
 * can be tested on a normal JVM. Blocking: [run] returns when the connection ends.
 */
class L2tpClient(
    private val host: String,
    private val user: String,
    private val pass: String,
    private val psk: ByteArray,
    private val mk: (Int) -> DatagramSocket,
    private val log: (String) -> Unit,
    private val ev: Events,
    private val authOnly: Boolean = false,   // true: stop as soon as the server accepted/refused the login
    private val quick: Boolean = false       // true: give up on a silent server after ~1.2 s
) {
    interface Events {
        fun onUp(ip: ByteArray, dns: List<ByteArray>, mtu: Int)
        fun onIpPacket(p: ByteArray)
    }

    private class Link(val t: Transport, val ike: Ike, val esp: EspSa, val life: Int) {
        val created = System.currentTimeMillis()
        @Volatile var alive = true
    }

    @Volatile private var stop = false
    @Volatile private var current: Link? = null
    private val links = CopyOnWriteArrayList<Link>()
    private lateinit var ppp: L2tpPpp
    @Volatile var error: String? = null
    @Volatile var established = false
    @Volatile var authOk = false

    fun stop() { stop = true }

    fun sendIp(p: ByteArray) {
        if (::ppp.isInitialized) {
            try { ppp.sendIp(p) } catch (_: Exception) {}
        }
    }

    private fun sendRaw(payload: ByteArray) {
        val l = current ?: return
        val pkt = l.esp.seal(Udp.build(1701, 1701, payload))
        try { l.t.send4500(pkt) } catch (_: Exception) {}
    }

    private fun negotiate(server: InetAddress, quickFirst: Boolean = false): Link {
        val t = Transport(server, mk)
        try {
            val ike = Ike(t, psk, log, quickFirst)
            val r = ike.negotiate()
            return Link(t, ike, r.esp, r.lifeSec)
        } catch (e: Throwable) {
            t.close()
            throw e
        }
    }

    private fun startRx(l: Link) {
        links.add(l)
        val th = Thread {
            while (l.alive && !stop) {
                val p = try { l.t.q.poll(500, TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { break } ?: continue
                try { handle(l, p) } catch (e: Exception) { log("rx: " + e.javaClass.simpleName + " " + e.message) }
            }
        }
        th.isDaemon = true
        th.name = "ipsec-rx"
        th.start()
    }

    private fun handle(l: Link, p: Pkt) {
        if (p.port != 4500) return
        val d = p.data
        if (d.size == 1 && d[0] == 0xFF.toByte()) return
        if (d.size >= 4 && be32(d, 0) == 0L) {
            val reply = try { l.ike.onInformational(d.copyOfRange(4, d.size)) } catch (e: IkeException) {
                if (l === current) ppp.fail(e.message ?: "IPsec closed")
                null
            }
            if (reply != null) try { l.t.send4500(reply) } catch (_: Exception) {}
            return
        }
        val inner = l.esp.open(d) ?: return
        if (inner.size < 8) return
        if (be16(inner, 0) != 1701 || be16(inner, 2) != 1701) return
        ppp.onPacket(inner.copyOfRange(8, inner.size))
    }

    fun run() {
        try {
            val server = com.example.myvpn.Dns.resolve4(host)
                ?: throw IkeException("cannot resolve $host")
            log("resolved $host -> ${server.hostAddress}")
            val first = negotiate(server, quick)
            current = first
            ppp = L2tpPpp(user, pass, { sendRaw(it) }, { ev.onIpPacket(it) }, {
                established = true
                ev.onUp(ppp.ourIp, listOf(ppp.dns1, ppp.dns2).filter { d -> d.any { it != 0.toByte() } }, ppp.mtu)
            }, log)
            startRx(first)
            ppp.start()

            var lastKeep = System.currentTimeMillis()
            var rekeyFailedAt = 0L
            while (!stop) {
                Thread.sleep(250)
                ppp.tick()
                ppp.failure?.let { error = it; return }
                if (authOnly && ppp.authOk) { authOk = true; return }
                val now = System.currentTimeMillis()
                val cur = current!!
                if (now - lastKeep > 20_000) {
                    lastKeep = now
                    try { cur.t.s4500.send(java.net.DatagramPacket(byteArrayOf(0xFF.toByte()), 1, server, 4500)) } catch (_: Exception) {}
                }
                // Re-negotiate IPsec well before the SA lifetime ends; the L2TP/PPP session keeps running.
                val age = now - cur.created
                if (established && age > cur.life * 750L && now - rekeyFailedAt > 30_000) {
                    log("rekey IPsec")
                    try {
                        val nl = negotiate(server)
                        current = nl
                        startRx(nl)
                        val old = cur
                        val closer = Thread {
                            try { Thread.sleep(30_000) } catch (_: InterruptedException) {}
                            old.alive = false; old.t.close(); links.remove(old)
                        }
                        closer.isDaemon = true; closer.start()
                    } catch (e: Exception) {
                        log("rekey failed: " + e.message)
                        rekeyFailedAt = System.currentTimeMillis()
                    }
                }
            }
        } catch (e: Throwable) {
            error = e.message ?: e.javaClass.simpleName
            log("ERROR: " + e.javaClass.simpleName + ": " + e.message)
        } finally {
            try { if (::ppp.isInitialized && established) ppp.close() } catch (_: Exception) {}
            for (l in links) { l.alive = false; l.t.close() }
            links.clear()
        }
    }
}
