package com.example.myvpn

import android.content.Context
import android.content.SharedPreferences
import android.net.Network
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

// Finds the IPv4 address of a server even when the phone's own DNS (for example on mobile data) fails.
// Uses: system DNS, DNS-over-HTTPS to public resolvers (by IP, needs no DNS), and the last address that worked.
object Dns {
    private var prefs: SharedPreferences? = null
    private val ipv4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")
    private val DOH = listOf(
        "https://1.1.1.1/dns-query?type=A&name=",
        "https://8.8.8.8/resolve?type=A&name=",
        "https://1.0.0.1/dns-query?type=A&name="
    )

    fun init(c: Context) {
        prefs = c.applicationContext.getSharedPreferences("dns_last", Context.MODE_PRIVATE)
    }

    // Starts the system DNS and the public DNS-over-HTTPS resolvers at the same time and takes the first answer
    // (at most 7 s). If nothing answers, the last address that worked is used. log = optional text log.
    fun resolve4(host: String, net: Network? = null, log: ((String) -> Unit)? = null): Inet4Address? {
        if (ipv4.matches(host)) return InetAddress.getByName(host) as? Inet4Address
        val result = AtomicReference<Inet4Address?>(null)
        val source = AtomicReference<String?>(null)
        val pending = AtomicInteger(1 + DOH.size)
        fun finish(name: String, ip: Inet4Address?) {
            if (ip != null && result.compareAndSet(null, ip)) source.set(name)
            pending.decrementAndGet()
        }
        val t0 = System.currentTimeMillis()
        thread(isDaemon = true) { finish("system", system(host, net)) }
        DOH.forEachIndexed { i, u -> thread(isDaemon = true) { finish("doh" + (i + 1), doh(u, host, net)) } }
        while (result.get() == null && pending.get() > 0 && System.currentTimeMillis() - t0 < 7000) {
            Thread.sleep(40)
        }
        val ms = System.currentTimeMillis() - t0
        result.get()?.let {
            remember(host, it)
            log?.invoke("DNS $host -> ${it.hostAddress} via ${source.get()} in ${ms}ms")
            return it
        }
        val l = last(host)
        log?.invoke(
            "DNS $host FAILED in ${ms}ms; " +
                (if (l != null) "using last known ${l.hostAddress}" else "no saved address")
        )
        return l
    }

    private fun system(host: String, net: Network?): Inet4Address? = try {
        (if (net != null) net.getAllByName(host) else InetAddress.getAllByName(host))
            .firstOrNull { it is Inet4Address } as? Inet4Address
    } catch (_: Throwable) {
        null
    }

    private fun doh(base: String, host: String, net: Network?): Inet4Address? = try {
        val url = URL(base + URLEncoder.encode(host, "UTF-8"))
        val con = (if (net != null) net.openConnection(url) else url.openConnection()) as HttpURLConnection
        con.connectTimeout = 4000
        con.readTimeout = 4000
        con.setRequestProperty("accept", "application/dns-json")
        try {
            if (con.responseCode != 200) {
                null
            } else {
                val arr = JSONObject(con.inputStream.bufferedReader().use { it.readText() }).optJSONArray("Answer")
                var r: Inet4Address? = null
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val d = o.optString("data")
                        if (o.optInt("type") == 1 && ipv4.matches(d)) {
                            r = InetAddress.getByName(d) as? Inet4Address
                            break
                        }
                    }
                }
                r
            }
        } finally {
            con.disconnect()
        }
    } catch (_: Throwable) {
        null
    }

    private fun remember(host: String, ip: Inet4Address) {
        try { prefs?.edit()?.putString(host.lowercase(), ip.hostAddress)?.apply() } catch (_: Throwable) {}
    }

    private fun last(host: String): Inet4Address? = try {
        prefs?.getString(host.lowercase(), null)?.takeIf { ipv4.matches(it) }
            ?.let { InetAddress.getByName(it) as? Inet4Address }
    } catch (_: Throwable) {
        null
    }
}
