package com.example.myvpn

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

// In-app update: reads update.json from your server, downloads the new APK and hands it to the system installer.
// The new APK must be signed with the same key (app/vipvpclassic.keystore) and have a higher versionCode.
object Updater {
    // >>> CHANGE THIS to the https address where you upload update.json (see README_FA.md) <<<
    const val UPDATE_URL = "https://raw.githubusercontent.com/mostafashadab-ship-it/vipvpclassic-update/main/update.json"

    // Second address tried when the first one is blocked / unreachable (same file, other CDN).
    const val UPDATE_URL_FALLBACK = "https://cdn.jsdelivr.net/gh/mostafashadab-ship-it/vipvpclassic-update@main/update.json"

    const val ACTION_RESULT = "com.example.myvpn.INSTALL_RESULT"

    class Info(val code: Int, val name: String, val apk: String, val notes: String, val sha256: String)

    // Throws on any network / format error. Tries the main address (with a cache-busting query, because
    // raw.githubusercontent.com keeps files in its cache for a few minutes), then the fallback address.
    fun fetch(fa: Boolean): Info {
        var last: Throwable = IOException("no address")
        for (u in listOf(UPDATE_URL + "?t=" + System.currentTimeMillis(), UPDATE_URL_FALLBACK)) {
            try { return fetchFrom(u, fa) } catch (e: Throwable) { last = e }
        }
        throw last
    }

    private fun fetchFrom(url: String, fa: Boolean): Info {
        val con = URL(url).openConnection() as HttpURLConnection
        con.connectTimeout = 8_000
        con.readTimeout = 8_000
        con.useCaches = false
        con.setRequestProperty("Cache-Control", "no-cache")
        try {
            if (con.responseCode != 200) throw IOException("HTTP " + con.responseCode)
            val j = JSONObject(con.inputStream.bufferedReader().use { it.readText() })
            val notes = if (fa) j.optString("notesFa", j.optString("notes", "")) else j.optString("notes", "")
            val apk = j.getString("apkUrl")
            if (!apk.startsWith("https://")) throw IOException("apkUrl must be https")
            return Info(j.getInt("versionCode"), j.optString("versionName", ""), apk, notes, j.optString("sha256", "").trim())
        } finally {
            con.disconnect()
        }
    }

    // Downloads the APK; returns its SHA-256. onProgress gets 0..100 (only when the server tells the size).
    fun download(url: String, dest: File, onProgress: (Int) -> Unit): String {
        val con = URL(url).openConnection() as HttpURLConnection
        con.connectTimeout = 15_000
        con.readTimeout = 30_000
        try {
            if (con.responseCode != 200) throw IOException("HTTP " + con.responseCode)
            val total = con.contentLengthLong
            val md = MessageDigest.getInstance("SHA-256")
            var done = 0L
            var last = -1
            con.inputStream.use { ins ->
                dest.outputStream().use { out ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        md.update(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = (done * 100 / total).toInt()
                            if (p != last) { last = p; onProgress(p) }
                        }
                    }
                }
            }
            return md.digest().joinToString("") { "%02x".format(it) }
        } finally {
            con.disconnect()
        }
    }

    // Gives the APK to the system installer (the user confirms once).
    fun install(ctx: Context, apk: File) {
        val pi = ctx.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        params.setAppPackageName(ctx.packageName)
        val id = pi.createSession(params)
        pi.openSession(id).use { s ->
            apk.inputStream().use { ins ->
                s.openWrite("update.apk", 0, apk.length()).use { out ->
                    ins.copyTo(out)
                    s.fsync(out)
                }
            }
            val pend = PendingIntent.getBroadcast(
                ctx, id,
                Intent(ctx, UpdateReceiver::class.java).setAction(ACTION_RESULT).setPackage(ctx.packageName),
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            s.commit(pend.intentSender)
        }
    }
}

// Receives the installer result: opens the system confirm screen, or shows the error.
class UpdateReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = if (Build.VERSION.SDK_INT >= 33) {
                    i.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                } else {
                    i.getParcelableExtra(Intent.EXTRA_INTENT)
                }
                if (confirm != null) {
                    confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try { c.startActivity(confirm) } catch (_: Throwable) {}
                }
            }
            PackageInstaller.STATUS_SUCCESS -> {}
            else -> {
                val msg = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
                Toast.makeText(c, (if (Lang.isFa(c)) "نصب بروزرسانی ناموفق بود: " else "Update install failed: ") + msg, Toast.LENGTH_LONG).show()
            }
        }
    }
}
