plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    // One fixed signing key for every build, so each new APK installs as an update over the old one
    // (GitHub makes a new random debug key on every run, which blocks updates).
    signingConfigs {
        create("fixed") {
            storeFile = file("vipvpclassic.keystore")
            storePassword = "vipvpclassic1"
            keyAlias = "vipvpclassic"
            keyPassword = "vipvpclassic1"
        }
    }

    namespace = "com.example.myvpn"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.myvpn"
        minSdk = 29
        targetSdk = 34
        versionCode = 196
        versionName = "196.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
}
