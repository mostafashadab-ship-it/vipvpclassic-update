package com.example.myvpn

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/**
 * v135: the quiet "tap to open the app" notification is REMOVED (nothing is shown in the notification shade while the
 * VPN is off). Only the clean-up of the old notification is left, so it disappears after updating.
 */
object PinNotice {
    private const val ID = 3
    private const val CH = "app_pin"

    /** v135: this notification is gone for good: posting only clears the one an older version left behind. */
    fun post(c: Context) {
        cancel(c)
    }

    fun cancel(c: Context) {
        try {
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID)
        } catch (_: Throwable) {
        }
    }
}

/** After the app is installed over an older version (update) or the phone restarts: show the notification again. */
class PinReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val a = i.action
        if (a == Intent.ACTION_MY_PACKAGE_REPLACED || a == Intent.ACTION_BOOT_COMPLETED) PinNotice.post(c)
    }
}
