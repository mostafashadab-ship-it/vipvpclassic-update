package com.example.myvpn

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.net.Uri
import android.net.VpnManager
import android.net.VpnService
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.example.myvpn.l2tp.Ike
import com.example.myvpn.cisco.CiscoClient
import kotlin.concurrent.thread

class MainActivity : Activity() {

    companion object {
        val DEFAULT_HOSTS = listOf(
            "ikfr1.gsmxr.net",
            "ikswd1.gsmxr.net",
            "iknl1.gsmxr.net",
            "iktr1.gsmxr.net"
        )
        const val MIN_ROWS = 5
        const val DEFAULTS_VERSION = 2
    }

    private class Row(val box: LinearLayout, val host: EditText, val ping: TextView, val go: Button, val flag: TextView? = null)
    // Fixed (built-in) L2TP server row.
    private class L2Row(val box: LinearLayout, val host: EditText, val ping: TextView, val go: Button, var cisco: Boolean = false, val flag: TextView? = null)

    private lateinit var prefs: SharedPreferences
    // Any to avoid loading VpnManager class on Android 10
    private var vpnManager: Any? = null
    private lateinit var statusText: TextView
    private lateinit var flagView: TextView
    private lateinit var detailView: TextView
    private lateinit var serversBox: LinearLayout
    private val rows = ArrayList<Row>()
    private val l2Rows = ArrayList<L2Row>()
    private lateinit var l2Box: LinearLayout
    @Volatile private var l2Pinging = false
    private var afterConsent: (() -> Unit)? = null
    private var fa = false
    private var uiReady = false
    // Little monkey that plays on the main screen while the VPN is not connected.
    private var monkey: MonkeyView? = null
    private var settingsBoxView: View? = null   // gear icon (the monkey swings from it)
    private var hideBarView: View? = null       // "hide servers" bar: the monkey's floor is its TOP edge (the red line)
    private var mainScroll: ScrollView? = null
    // Update button blinks while a newer version is available on the server.
    private var updBoxView: View? = null
    private var updBlink: android.animation.ObjectAnimator? = null
    private var updIconView: View? = null
    private var updHoorayView: View? = null
    private var updToggling = false
    // While an update is available the button alternates: its normal icon, then "update is here, hooray!".
    private val updToggle = object : Runnable {
        var showText = false
        override fun run() {
            if (!updateAvailable) { stopUpdateBlink(); return }
            showText = !showText
            updIconView?.visibility = if (showText) View.INVISIBLE else View.VISIBLE
            updHoorayView?.visibility = if (showText) View.VISIBLE else View.INVISIBLE
            handler.postDelayed(this, 1200)
        }
    }
    @Volatile private var updateAvailable = false
    @Volatile private var updCheckFailed = false   // last silent check could not reach the server: retry later
    @Volatile private var updChecking = false
    @Volatile private var pinging = false
    private lateinit var ikBtn: Button   // IKEv2 (Android 14+)
    private lateinit var l2Btn: Button   // L2TP (Android 10+)
    private val handler = Handler(Looper.getMainLooper())
    private var pingTick = 0
    private var lastPingMs = 0L   // 0 = ping the servers right away on the next tick
    private val pingTask = object : Runnable {
        override fun run() {
            // Every ping sends real IKE packets that leave half-open sessions on the servers. Doing that for
            // every server every 10 s can make a server stop answering, so pings run once a minute (and
            // never while a connection is being made); the status text still refreshes every 10 s.
            pingTick++
            val busy = (prefs.getString("state", "") ?: "").let { it.startsWith("Connecting") || it.startsWith("Testing") }
            // Time based (not a tick counter): the first round runs at once after login / opening the app,
            // then at most once a minute.
            val nowMs = android.os.SystemClock.elapsedRealtime()
            if (!busy && nowMs - lastPingMs >= 55_000) {
                lastPingMs = nowMs
                runPings()
                runL2tpPings()
            }
            if (updCheckFailed && !updChecking && pingTick % 3 == 0) silentUpdateCheck()
            updateStatus()
            handler.postDelayed(this, 10_000)
        }
    }

    // Map hostname patterns → (flag emoji, English name, Persian name)
    private fun countryOf(host: String): Triple<String, String, String> {
        val h = host.lowercase()
        // Built-in L2TP servers: l2tp / l3tp / l4tp ... .gsmxr.net
        // Country of an L2TP server's exit, found by the L2TP service after the first successful connection.
        val code = prefs.getString("l2c_$h", null)
        if (code != null && code.length == 2 && code.all { it in 'A'..'Z' }) {
            val flag = String(Character.toChars(0x1F1E6 + (code[0] - 'A'))) + String(Character.toChars(0x1F1E6 + (code[1] - 'A')))
            val loc = java.util.Locale("", code)
            val en = loc.getDisplayCountry(java.util.Locale.ENGLISH).ifEmpty { code }
            val faName = loc.getDisplayCountry(java.util.Locale("fa")).ifEmpty { en }
            return Triple(flag, en, faName)
        }
        // Not known yet: lock icon with the server number (l2tp / l4tp / sstp2 ...).
        Regex("^(l|sstp)(\\d+)(tp)?\\.").find(h)?.let { m ->
            val n = m.groupValues[2]
            val label = if (m.groupValues[1] == "sstp") "L2TP S$n" else "L2TP $n"
            return Triple("\uD83D\uDD12", label, label)
        }
        return when {
            h.contains("ikfr") || h.contains(".fr") || h.contains("france") ->
                Triple("🇫🇷", "France", "فرانسه")
            h.contains("ikswd") || h.contains("sweden") || h.contains(".se") || h.contains("stockholm") ->
                Triple("🇸🇪", "Sweden", "سوئد")
            h.contains("iknl") || h.contains("netherlands") || h.contains(".nl") || h.contains("holland") || h.contains("amsterdam") ->
                Triple("🇳🇱", "Netherlands", "هلند")
            h.contains("iktr") || h.contains("turkey") || h.contains(".tr") || h.contains("istanbul") ->
                Triple("🇹🇷", "Turkey", "ترکیه")
            h.contains("germany") || h.contains(".de") || h.contains("berlin") || h.contains("ikde") ->
                Triple("🇩🇪", "Germany", "آلمان")
            h.contains("usa") || h.contains(".us") || h.contains("america") || h.contains("newyork") || h.contains("ikus") ->
                Triple("🇺🇸", "United States", "آمریکا")
            h.contains("uk") || h.contains(".gb") || h.contains("london") || h.contains("britain") || h.contains("ikgb") ->
                Triple("🇬🇧", "United Kingdom", "انگلستان")
            h.contains("canada") || h.contains(".ca") || h.contains("toronto") ->
                Triple("🇨🇦", "Canada", "کانادا")
            h.contains("japan") || h.contains(".jp") || h.contains("tokyo") ->
                Triple("🇯🇵", "Japan", "ژاپن")
            h.contains("singapore") || h.contains(".sg") ->
                Triple("🇸🇬", "Singapore", "سنگاپور")
            else -> Triple("🌐", "Server", "سرور")
        }
    }

    // Fully opaque country flag shown in the server card (bottom-left, under the host name).
    private fun makeFlagView() = TextView(this).apply {
        textSize = 20f
        alpha = 1f
        // Stretched sideways (wider flag); the extra right padding makes room for the stretch.
        scaleX = 1.45f
        pivotX = 0f
        setPadding(dp(4), 0, dp(24), 0)
    }

    private fun refreshFlag(tv: TextView?, host: String) {
        tv ?: return
        val h = host.trim()
        val f = if (h.isEmpty()) "" else countryOf(h).first
        tv.text = if (f == "\uD83C\uDF10" || f == "\uD83D\uDD12") "" else f
    }

    private fun isActive(): Boolean {
        val s = prefs.getString("state", "Disconnected") ?: ""
        return s.startsWith("Connecting") || s.startsWith("Testing") || s.startsWith("Connected")
    }

    // Which protocol the current / last connection uses: "ikev2" or "l2tp".
    private fun mode(): String = prefs.getString("mode", "ikev2") ?: "ikev2"

    // If the service is not running, a saved "Connecting/Connected" state is stale: clear it
    // and remove any notification that was left behind.
    private fun clearStale() {
        if (!ConnService.running && !L2tpVpnService.running) {
            if (isActive()) {
                prefs.edit().putString("state", "Disconnected").apply()
            }
            try {
                (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(1)
            } catch (_: Exception) {
            }
        }
    }

    private fun startPinging() {
        handler.removeCallbacks(pingTask)
        handler.post(pingTask)
    }

    // Updates the status text, flag and the one connect/disconnect button.
    // "Hooray, connected!" banner in the top bar: shown for 8 seconds when a connection comes up.
    private var celebView: TextView? = null
    private var celebPulse: android.animation.ObjectAnimator? = null
    private var wasConnected: Boolean? = null
    private val hideCeleb = Runnable {
        val v = celebView ?: return@Runnable
        celebPulse?.cancel()
        v.animate().cancel()
        v.animate().alpha(0f).setDuration(400).withEndAction { v.visibility = View.GONE }.start()
    }

    // Different cheerful messages, one picked at random each time (never the same one twice in a row).
    private val celebMsgs = listOf(
        "Hooray, connected! 🎉\nGo enjoy the internet, filters are history 😎" to "🎉 هوررا، وصل شد!\nبرو تو اینترنت عشق و حال کن 😎",
        "Liftoff! 🚀\nFree internet, go explore 🔥" to "🚀 پرواز کردیم!\nاینترنت آزاده، برو بتاز 🔥",
        "Connected! 🥳\nPut the filter aside, the world is yours 🌍" to "🥳 وصل شدیییی!\nدنیا مال توئه 🌍",
        "Internet without borders ✨\nGo and have fun 😍" to "✨ اینترنت بدون مرز!\nبرو حالشو ببر 😍",
        "VPN is on, enjoy! 🕺\nOpen whatever you like 🔓" to "🕺 فیلترشکن فعاله، حال کن!\nهرچی دلت می‌خواد باز کن 🔓",
        "💃 Connected and free\nThe internet is waiting for you 🌈" to "💃 وصلی و آزاد\nاینترنت منتظرته 🌈",
        "Well done, you are in! 🎊\nSit back and enjoy 😜" to "🎊 آفرین، وصل شدی!\nبشین و لذت ببر 😜",
        "You are connected!\nGrab a tea and browse ☕" to "وصل شدی\nیه چایی بریز تو اینترنت بگرد ☕",
        "Locks are broken! 🔓\nFree internet at your service 🎈" to "🔓 قفل‌ها شکست!\nاینترنت آزاد در خدمت شما 🎈",
        "Yay, you are online! 🦄\nEverything is open, go wander 🌟" to "🦄 آنلاین شدی!\nهمه‌چی بازه، برو بگرد 🌟"
    )
    private var lastCelebMsg = -1

    private fun celebrate() {
        val v = celebView ?: return
        var i = celebMsgs.indices.random()
        if (celebMsgs.size > 1 && i == lastCelebMsg) i = (i + 1) % celebMsgs.size
        lastCelebMsg = i
        v.text = t(celebMsgs[i].first, celebMsgs[i].second)
        handler.removeCallbacks(hideCeleb)
        celebPulse?.cancel()
        v.animate().cancel()
        v.visibility = View.VISIBLE
        v.alpha = 0f
        v.scaleX = 0.4f
        v.scaleY = 0.4f
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(500)
            .setInterpolator(android.view.animation.OvershootInterpolator(2.5f)).start()
        // Happy little pulse while it is visible.
        celebPulse = android.animation.ObjectAnimator.ofPropertyValuesHolder(
            v,
            android.animation.PropertyValuesHolder.ofFloat("scaleX", 1f, 1.08f),
            android.animation.PropertyValuesHolder.ofFloat("scaleY", 1f, 1.08f)
        ).apply {
            duration = 420
            startDelay = 550
            repeatMode = android.animation.ValueAnimator.REVERSE
            repeatCount = 17
            start()
        }
        handler.postDelayed(hideCeleb, 8000)
    }

    private fun updateStatus() {
        if (!uiReady) return
        statusText.text = showState()
        val s = prefs.getString("state", "Disconnected") ?: ""
        // Server-list flags follow the saved countries at once (a new exit country arrives by broadcast),
        // not only at the next ping round.
        try {
            for (r in rows) refreshFlag(r.flag, r.host.text.toString())
            for (r in l2Rows) refreshFlag(r.flag, r.host.text.toString())
        } catch (_: Throwable) {
        }
        // "Disconnected", "Connecting" and "Connected" are not written above the button any more:
        // the connect button itself shows them (flag + country inside the circle). Other messages
        // (testing servers, failures...) still appear above it.
        statusText.visibility =
            if (s == "Disconnected" || s.startsWith("Connecting") || s.startsWith("Connected")) View.GONE else View.VISIBLE
        val expired = !isActive() && isLoginFailure() && accountExpired()
        val d = if (isActive()) "" else if (expired) t("Your subscription has ended", "اشتراک شما تمام شده است") else detailMessage()
        detailView.text = d
        detailView.textSize = if (expired) 26f else 13f
        detailView.setTextColor(if (expired) 0xFFFF5252.toInt() else 0xFFFFCC80.toInt())
        detailView.setTypeface(null, if (expired) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        detailView.visibility = if (d.isEmpty()) View.GONE else View.VISIBLE
        if (!isActive() && isLoginFailure() && !expiryChecking) refreshExpiry()

        // Celebrate when a connection comes up while the app is open (not when the app starts already connected).
        val nowConnected = s.startsWith("Connected")
        val prevConnected = wasConnected
        wasConnected = nowConnected
        // The monkey plays until the VPN is connected, then he stays and celebrates (v132).
        // The cheerful message is the banner in the middle of the top bar (shown even when the monkey is hidden).
        if (nowConnected) { if (prevConnected == null) monkey?.stayAway() else monkey?.celebrate() } else monkey?.appear()
        if (prevConnected == false && nowConnected) celebrate()
        else if (!nowConnected && celebView?.visibility == View.VISIBLE) {
            handler.removeCallbacks(hideCeleb)
            hideCeleb.run()
        }

        // The big country flag now lives inside the connect button (see styleProtoBtn).
        val host = activeHost()
        flagView.text = ""
        flagView.visibility = View.GONE
        connFlag = if (host != null && (s.startsWith("Connected") || s.startsWith("Connecting"))) countryOf(host).first else ""

        val on = isActive()
        val m = mode()
        if (Build.VERSION.SDK_INT >= 34) {
            // One auto button: IKEv2 servers first, then Cisco / L2TP.
            // Once a server is picked the circle names the protocol that was really used.
            val proto = if (host != null && (s.startsWith("Connected") || s.startsWith("Connecting")))
                protoNameOf(host) else t("IKEv2, Cisco & L2TP", "IKEv2 و Cisco و L2TP")
            styleProtoBtn(ikBtn, proto, on, false, s)
        } else {
            styleProtoBtn(ikBtn, "IKEv2", on && m == "ikev2", (on && m != "ikev2") || Build.VERSION.SDK_INT < 34, s)
            styleProtoBtn(l2Btn, t("Cisco & L2TP", "Cisco و L2TP"), on && m == "l2tp", on && m != "l2tp", s)
        }

        // Color of each server's own Connect button.
        val active = activeHost()
        val connected = s.startsWith("Connected: ")
        for (r in rows) {
            val me = r.host.text.toString().trim()
            val mode = when {
                m == "ikev2" && active != null && me == active -> if (connected) 2 else 1
                isPending(me, s) -> 1
                else -> 0
            }
            styleServerBtn(r.go, mode)
        }
        for (r in l2Rows) {
            val me = r.host.text.toString().trim()
            val mode = when {
                m == "l2tp" && active != null && me == active -> if (connected) 2 else 1
                isPending(me, s) -> 1
                else -> 0
            }
            styleServerBtn(r.go, mode)
        }
    }

    // Which protocol a server runs: IKEv2, Cisco (AnyConnect) or L2TP.
    private fun protoNameOf(host: String): String {
        if (mode() == "ikev2") return "IKEv2"
        val me = host.trim()
        val saved = (prefs.getString("l2hosts", "") ?: "").split("\n")
        val isCisco = saved.any { L2tpVpnService.isCisco(it) && L2tpVpnService.plainOf(it).equals(me, true) }
        return if (isCisco) "Cisco" else "L2TP"
    }

    private var connFlag = ""   // flag of the server we are connected / connecting to ("" = none)

    // One of the two big round buttons.
    // mine = this protocol is the one connected/connecting; dim = another protocol is active (or unsupported).
    private fun styleProtoBtn(b: Button, proto: String, mine: Boolean, dim: Boolean, s: String) {
        val (action, color) = when {
            mine && s.startsWith("Connected") -> Pair("\u2714 " + t("Disconnect", "قطع اتصال"), 0xFF2E7D32.toInt())
            mine -> Pair(t("Connecting...\n(tap to cancel)", "در حال اتصال...\n(لمس برای لغو)"), 0xFFEF6C00.toInt())
            else -> Pair(t("Auto Connect", "اتصال خودکار"), 0xFF1565C0.toInt())
        }
        if (mine && connFlag.isNotEmpty() && (s.startsWith("Connected") || s.startsWith("Connecting"))) {
            // Inside the circle: big flag, "Connected · Country", then the protocol and the action.
            val sb = android.text.SpannableStringBuilder()
            sb.append(connFlag)
            sb.setSpan(android.text.style.RelativeSizeSpan(2.4f), 0, sb.length, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append("\n")
            if (s.startsWith("Connected")) sb.append(showState()).append("\n")
            val st = sb.length
            sb.append(proto)
            sb.setSpan(android.text.style.RelativeSizeSpan(0.85f), st, sb.length, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append("\n").append(action)
            b.text = sb
        } else {
            b.text = proto + "\n" + action
        }
        b.alpha = if (dim) 0.55f else 1f
        b.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            if (mine && s.startsWith("Connected")) setStroke(dp(6), 0xFF69F0AE.toInt())  // bright green ring = connected
            else setStroke(dp(4), 0x66FFFFFF)
        }
    }

    // True when the last failure was a refused login (wrong password or expired account).
    private fun isLoginFailure(): Boolean {
        val d = prefs.getString("detail", "") ?: ""
        val l = d.lowercase()
        return d.startsWith("l2tpauth:") || l.contains("login refused") || l.contains("login failed")
    }

    // True when the site said the account has no days left (last known value).
    private fun accountExpired(): Boolean {
        val user = prefs.getString("user", "") ?: ""
        val days = AccountInfo.cachedDays(this, user)
        return days != null && days <= 0
    }

    private var expiryChecking = false
    private var expiryCheckedFor = ""

    // Asks the site once per failure for the current days left, then redraws the status.
    private fun refreshExpiry() {
        val user = prefs.getString("user", "") ?: ""
        val pass = prefs.getString("pass", "") ?: ""
        if (user.isEmpty() || pass.isEmpty()) return
        val key = (prefs.getString("state", "") ?: "") + "|" + (prefs.getString("detail", "") ?: "")
        if (key == expiryCheckedFor) return
        expiryCheckedFor = key
        expiryChecking = true
        thread(name = "expiry-check", isDaemon = true) {
            try { AccountInfo.fetch(this, user, pass) } catch (_: Throwable) {}
            runOnUiThread {
                expiryChecking = false
                if (!isFinishing) updateStatus()
            }
        }
    }

    // Explains why the last connection failed or dropped.
    private fun detailMessage(): String {
        val d = prefs.getString("detail", "") ?: ""
        return when {
            d.startsWith("noanswer:") -> t(
                "The server did not answer in ${ConnService.SERVER_WAIT_MS / 1000} seconds. Your network may be blocking it (common on WiFi) — try mobile data or another WiFi.",
                "سرور در ${ConnService.SERVER_WAIT_MS / 1000} ثانیه جواب نداد. ممکن است این شبکه (مخصوصاً وای‌فای) جلویش را گرفته باشد؛ با نت گوشی یا وای‌فای دیگر امتحان کن."
            )
            d.startsWith("dropped:") -> {
                val sec = d.removePrefix("dropped:")
                t("Connection dropped after $sec s.", "اتصال بعد از $sec ثانیه قطع شد.")
            }
            d.startsWith("quota:") -> t(
                "All servers failed or the connection kept dropping. Your service days or data volume may have run out — contact support.",
                "همه سرورها جواب ندادند یا اتصال پیاپی قطع شد؛ ممکن است روز یا حجم سرویس شما تمام شده باشد. با پشتیبانی تماس بگیرید."
            )
            d.startsWith("l2tpmax:") -> t(
                "The server has not yet noticed that your previous connection was closed. Please try to connect again in one minute.",
                "سرور هنوز تشخیص نداده که اتصال قبلی خود را قطع کردید. یک دقیقه دیگه کانکت بشید."
            )
            d.startsWith("l2tpauth:") -> t(
                "The server refused the login. Check your User ID / password — your service may also have expired.",
                "سرور ورود را قبول نکرد. نام کاربری و رمز را بررسی کن؛ ممکن است سرویس شما تمام شده باشد."
            )
            d.startsWith("l2tpfail:") -> explainError(d.removePrefix("l2tpfail:"))
            d.startsWith("nonet:") -> t(
                "The phone has no working internet. Connect to mobile data or WiFi first.",
                "اینترنت گوشی وصل نیست. اول نت گوشی یا وای‌فای را وصل کن."
            )
            d.startsWith("l2tpnodata:") -> t(
                "Logged in, but no data passes through the servers. Try another network (mobile data / other WiFi).",
                "ورود انجام شد ولی هیچ داده‌ای از سرورها رد نمی‌شود. شبکهٔ دیگری (نت گوشی / وای‌فای دیگر) را امتحان کن."
            )
            d.startsWith("err:") -> explainError(d.removePrefix("err:"))
            else -> if (d.isEmpty()) "" else explainError(d)
        }
    }

    // Turns a technical error text into a short, simple sentence (the raw text stays in the connection log).
    private fun explainError(raw: String): String {
        val e = raw.lowercase()
        fun has(vararg k: String) = k.any { e.contains(it) }
        return when {
            has("max-login") -> t(
                "The server has not yet noticed that your previous connection was closed. Please try to connect again in one minute.",
                "سرور هنوز تشخیص نداده که اتصال قبلی خود را قطع کردید. یک دقیقه دیگه کانکت بشید."
            )
            has("login refused", "login failed") -> t(
                "The server did not accept your User ID / password. Check them (upper/lower case matters) — your service may also have expired.",
                "سرور نام کاربری یا رمز را قبول نکرد. دوباره چک کن (به حروف بزرگ و کوچک دقت کن)؛ ممکن است سرویس شما تمام شده باشد."
            )
            has("no data") -> t(
                "Connected to the server, but no internet passes through it. Try another network (mobile data / other WiFi).",
                "به سرور وصل شد ولی اینترنتی از آن رد نمی‌شود. با نت گوشی یا وای‌فای دیگر امتحان کن."
            )
            has("does not answer", "server silent", "no tunnel answer", "lcp timeout", "ipcp timeout", "timeout", "timed out", "no answer") -> t(
                "The server did not answer. Your network may be blocking the connection — try mobile data or another WiFi, or try again later.",
                "سرور جواب نداد. ممکن است این شبکه جلوی اتصال را گرفته باشد؛ با نت گوشی یا وای‌فای دیگر امتحان کن، یا چند دقیقه دیگر دوباره تلاش کن."
            )
            has("connection lost", "tunnel closed", "tunnel read", "send failed", "bad record header", "socketexception", "connection reset", "broken pipe", "unknownhost", "unreachable", "econn") -> t(
                "The connection was cut. Check that your phone's internet works, then connect again.",
                "ارتباط قطع شد. مطمئن شو اینترنت گوشی وصل است و دوباره وصل شو."
            )
            has("server closed the tunnel", "server ended") -> t(
                "The server closed your connection. Wait a minute and connect again; if it keeps happening, your service may have expired or the server is busy.",
                "سرور اتصال تو را بست. یک دقیقه صبر کن و دوباره وصل شو؛ اگر تکرار شد ممکن است سرویس تمام شده باشد یا سرور شلوغ باشد."
            )
            has("no address", "did not assign", "bad address") -> t(
                "The server has no free address for you right now. Try again in a minute or use another server.",
                "سرور الان آدرس خالی به تو نمی‌دهد. یک دقیقه بعد دوباره امتحان کن یا سرور دیگری را بزن."
            )
            has("tunnel auth rejected") -> t(
                "The password was accepted, but the server did not open the connection (it may be busy). Tap connect again.",
                "رمز درست بود ولی سرور اتصال را باز نکرد (ممکن است شلوغ باشد). دوباره وصل شو."
            )
            has("tunnel refused", "unexpected answer", "no session token", "unsupported login form") -> t(
                "The server gave an unexpected answer. It may be busy or down — try again later or use another server.",
                "سرور جواب غیرعادی داد. ممکن است شلوغ یا خاموش باشد؛ بعداً دوباره امتحان کن یا سرور دیگری را بزن."
            )
            has("securityexception", "permission") -> t(
                "Android did not allow the VPN. Open the app, tap Connect and accept the VPN permission.",
                "اندروید اجازهٔ VPN را نداد. برنامه را باز کن، Connect بزن و مجوز VPN را تأیید کن."
            )
            else -> t(
                "Something went wrong while connecting. Try again; if it keeps happening, send the connection report to support.",
                "هنگام اتصال مشکلی پیش آمد. دوباره امتحان کن؛ اگر تکرار شد گزارش اتصال را برای پشتیبانی بفرست."
            )
        }
    }

    // The server we are connecting/connected to right now (null if none).
    private fun activeHost(): String? {
        val s = prefs.getString("state", "Disconnected") ?: ""
        return when {
            s.startsWith("Connecting: ") -> s.removePrefix("Connecting: ").trim()
            s.startsWith("Connected: ") -> s.removePrefix("Connected: ").trim()
            else -> null
        }
    }

    // mode: 0 = idle (slate), 1 = connecting (orange), 2 = connected (green)
    // Rounded button with a soft top-to-bottom gradient, a small icon, a ripple and a light shadow
    // (same look as the pencil / trash icon buttons).
    private fun styleServerBtn(b: Button, mode: Int) {
        val (label, colors) = when (mode) {
            2 -> Pair(t("Connected", "متصل"), intArrayOf(0xFF43A047.toInt(), 0xFF2E7D32.toInt()))
            1 -> Pair(t("Connecting…", "در حال اتصال…"), intArrayOf(0xFFFFA726.toInt(), 0xFFEF6C00.toInt()))
            else -> Pair(t("Manual connect", "اتصال دستی"), intArrayOf(0xFF78909C.toInt(), 0xFF546E7A.toInt()))
        }
        b.text = label
        b.setTextColor(0xFFFFFFFF.toInt())
        b.textSize = 12f
        b.isAllCaps = false
        b.setTypeface(b.typeface, android.graphics.Typeface.BOLD)
        b.setPadding(dp(12), 0, dp(12), 0)
        b.compoundDrawablePadding = dp(4)
        val icon = when (mode) {
            2 -> R.drawable.ic_check
            0 -> R.drawable.ic_bolt
            else -> 0
        }
        if (icon != 0) {
            val d = resources.getDrawable(icon, theme)
            d.setBounds(0, 0, dp(16), dp(16))
            b.setCompoundDrawablesRelative(d, null, null, null)
        } else {
            b.setCompoundDrawablesRelative(null, null, null, null)
        }
        b.stateListAnimator = null
        b.elevation = dp(2).toFloat()
        val shape = {
            GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors).apply { cornerRadius = dp(10).toFloat() }
        }
        val mask = GradientDrawable().apply { setColor(0xFFFFFFFF.toInt()); cornerRadius = dp(10).toFloat() }
        b.background = android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(0x88FFFFFF.toInt()), shape(), mask
        )
    }

    // The row the user just tapped: shown as "Connecting…" at once (the service needs a moment before the
    // state names a host), with a small press animation and a vibration tick.
    private var manualPending: String? = null
    private var manualPendingAt = 0L

    private fun pressFeedback(b: View, host: String) {
        manualPending = host
        manualPendingAt = System.currentTimeMillis()
        try { b.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP) } catch (_: Throwable) {}
        b.animate().cancel()
        b.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).withEndAction {
            b.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
        updateStatus()
    }

    private fun isPending(me: String, s: String): Boolean {
        if (me.isEmpty() || manualPending != me) return false
        if (s.startsWith("Connected")) { manualPending = null; return false }
        if (System.currentTimeMillis() - manualPendingAt < 3000) return true
        // After the first moments only the server the service is really working on counts.
        if (activeHost() == me) return true
        manualPending = null
        return false
    }

    private fun t(en: String, faText: String) = if (fa) faText else en

    // Display-friendly state: when Connected, show only country name (no server hostname).
    private fun showState(): String {
        val s = prefs.getString("state", "Disconnected") ?: "Disconnected"
        if (s.startsWith("Connected: ")) {
            val host = s.removePrefix("Connected: ").trim()
            val (_, en, faName) = countryOf(host)
            return if (fa) "متصل شد · $faName" else "Connected · $en"
        }
        if (s.startsWith("Connecting: ")) {
            val host = s.removePrefix("Connecting: ").trim()
            val (_, en, faName) = countryOf(host)
            return if (fa) "در حال اتصال · $faName" else "Connecting · $en"
        }
        return Lang.state(this, s)
    }

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            updateStatus()
        }
    }

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("servers", MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 30) {
            vpnManager = getSystemService(Context.VPN_MANAGEMENT_SERVICE)
        }
        migrate()
        ensureDefaults()
        clearStale()
        if (Lang.isSet(this)) {
            startApp()
        } else {
            setContentView(ImageView(this).apply {
                setImageResource(R.drawable.bg)
                scaleType = ImageView.ScaleType.CENTER_CROP
            })
            AlertDialog.Builder(this)
                .setTitle("Choose language / زبان را انتخاب کنید")
                .setCancelable(false)
                .setItems(arrayOf("English", "فارسی")) { _, which ->
                    Lang.set(this, if (which == 1) "fa" else "en")
                    startApp()
                }
                .show()
        }
        showLastCrash()
    }

    // If the app crashed last time, show the reason so it can be copied and reported.
    private fun showLastCrash() {
        val f = java.io.File(filesDir, "crash.txt")
        if (!f.exists()) return
        val txt = try { f.readText() } catch (_: Throwable) { return }
        try { java.io.File(filesDir, "crash_last.txt").writeText(txt); f.delete() } catch (_: Throwable) {}
        val tv = TextView(this).apply {
            text = txt
            textSize = 11f
            setTextIsSelectable(true)
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        AlertDialog.Builder(this)
            .setTitle("Last crash / آخرین کرش")
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Copy / کپی") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("crash", txt))
            }
            .setNegativeButton("Close / بستن", null)
            .show()
    }

    private fun startApp() {
        fa = Lang.isFa(this)
        if (prefs.getBoolean("logged_in", false)) showMain() else showLogin()
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        PinNotice.post(this)   // quiet "tap to open" notification that stays in the status bar
        askBatteryExemption()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        // the notification permission was just granted: show the "tap to open" notification now
        PinNotice.post(this)
    }

    private fun showMain() {
        lastPingMs = 0L   // fresh server list (e.g. just after login): ping it immediately
        buildUi()
        uiReady = true
        updateStatus()
        startPinging()
        silentUpdateCheck()
    }

    private fun showLogin() {
        uiReady = false
        handler.removeCallbacks(pingTask)
        buildLogin()
    }

    // First run only: fill in the default servers (the user can edit or delete them).
    private fun ensureDefaults() {
        if (!prefs.getBoolean("defaults_done", false)) {
            val e = prefs.edit().putBoolean("defaults_done", true)
            if (ConnService.loadHosts(prefs).isEmpty()) {
                e.putString("hosts", DEFAULT_HOSTS.joinToString("\n"))
            }
            e.apply()
        }
        // Raise DEFAULTS_VERSION when the built-in IKEv2 list changes: built-in servers the user deleted come
        // back once (servers the user added himself are kept, after the built-in ones).
        if (prefs.getInt("hosts_ver", 0) < DEFAULTS_VERSION) {
            val cur = ConnService.loadHosts(prefs)
            val merged = DEFAULT_HOSTS + cur.filter { c -> DEFAULT_HOSTS.none { it.equals(c, true) } }
            prefs.edit().putString("hosts", merged.joinToString("\n")).putInt("hosts_ver", DEFAULTS_VERSION).apply()
        }
    }

    // Older versions saved 4 separate servers with their own user/pass.
    private fun migrate() {
        if (prefs.contains("hosts")) return
        val old = (0 until 4)
            .map { prefs.getString("host$it", "")?.trim().orEmpty() }
            .filter { it.isNotEmpty() }
        prefs.edit()
            .putString("hosts", old.joinToString("\n"))
            .putString("user", prefs.getString("user0", "") ?: "")
            .putString("pass", prefs.getString("pass0", "") ?: "")
            .apply()
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter(ConnService.ACTION_STATE)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(stateReceiver, f)
        }
        clearStale()
        if (uiReady) {
            updateStatus()
            startPinging()
            applyUpdateBlink()
            silentUpdateCheck()
            monkey?.resume()
        }
    }

    override fun onStop() {
        handler.removeCallbacks(pingTask)
        monkey?.pause()
        stopUpdateBlink()
        try {
            unregisterReceiver(stateReceiver)
        } catch (_: Exception) {
        }
        super.onStop()
    }

    // Views the monkey may bounce on (and wrestle on): the visible connect button. He only ever stands on its TOP EDGE
    // (the strip above it, see avoidProvider in showScreen), so the button itself stays free to tap.
    private fun monkeyTargets(): List<View> = listOfNotNull(
        if (::ikBtn.isInitialized && (ikBtn.parent as? View)?.visibility == View.VISIBLE) ikBtn else null,
        if (::l2Btn.isInitialized && (l2Btn.parent as? View)?.visibility == View.VISIBLE) l2Btn else null
    )

    // ---------- UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(0xFFFFFFFF.toInt())
        setPadding(0, dp(8), 0, 0)
    }

    private fun field(hint: String, value: String, secret: Boolean = false): EditText =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xAAFFFFFF.toInt())
            setSingleLine()
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

    private fun coloredButton(caption: String, color: Int) = Button(this).apply {
        text = caption
        setTextColor(0xFFFFFFFF.toInt())
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        textSize = 16f
        background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(10).toFloat()
        }
    }

    // Puts the content on top of the background photo.
    private fun showScreen(content: View, withMonkey: Boolean = false, bgRes: Int = R.drawable.bg, dimColor: Int = 0x40000000) {
        val bg: View = if (bgRes == R.drawable.login_bg) {
            // Login uses a purpose-built premium gradient instead of the old photo artwork.
            View(this).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(0xFF071326.toInt(), 0xFF102B50.toInt(), 0xFF06101F.toInt())
                )
            }
        } else {
            ImageView(this).apply {
                setImageResource(bgRes)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
        }
        val dim = View(this).apply { setBackgroundColor(dimColor) }
        val scroll = ScrollView(this).apply {
            isFillViewport = (bgRes == R.drawable.login_bg)   // login: the version can sit at the bottom
            addView(content)
        }
        mainScroll = scroll
        val match = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        )
        val m = if (withMonkey && !prefs.getBoolean("hide_monkey", false)) MonkeyView(this) else null
        monkey = m
        setContentView(FrameLayout(this).apply {
            addView(bg, match)
            addView(dim, match)
            addView(scroll, match)
            if (m != null) addView(m, match)   // on top of everything, only reacts to touches on the monkey
        })
        if (m != null) {
            m.fa = fa
            m.targets = { monkeyTargets() }
            m.hangers = { listOfNotNull(settingsBoxView, updBoxView) }
            // the monkey lives in the page: when the page is scrolled he moves with it
            m.scrollProvider = { mainScroll?.scrollY ?: 0 }
            m.floorProvider = {
                val bar = hideBarView
                if (bar == null || !bar.isLaidOut) {
                    0f
                } else {
                    val loc = IntArray(2)
                    bar.getLocationOnScreen(loc)
                    val ml = IntArray(2)
                    m.getLocationOnScreen(ml)
                    // TOP edge of the bar (the red line) as if the page were not scrolled:
                    // the monkey never goes lower than this
                    (loc[1] - ml[1] + (mainScroll?.scrollY ?: 0) - dp(2)).toFloat()
                }
            }
            // v133: the green "connected" banner at the top: after connecting the monkey stands beside it
            m.bannerProvider = {
                val v = celebView
                if (v == null || v.visibility != View.VISIBLE || !v.isLaidOut || v.width <= 0 || v.alpha < 0.2f) {
                    null
                } else {
                    val loc = IntArray(2)
                    v.getLocationOnScreen(loc)
                    val ml = IntArray(2)
                    m.getLocationOnScreen(ml)
                    val sy = mainScroll?.scrollY ?: 0
                    val l = (loc[0] - ml[0]).toFloat()
                    val t = (loc[1] - ml[1] + sy).toFloat()
                    android.graphics.RectF(l, t, l + v.width * v.scaleX, t + v.height * v.scaleY)   // the banner pulses (scaled)
                }
            }
            // The big auto-connect button: the monkey never stands on it.
            m.avoidProvider = {
                val btn: View? = when {
                    ::ikBtn.isInitialized && (ikBtn.parent as? View)?.visibility == View.VISIBLE -> ikBtn
                    ::l2Btn.isInitialized && (l2Btn.parent as? View)?.visibility == View.VISIBLE -> l2Btn
                    else -> null
                }
                if (btn == null || !btn.isLaidOut || btn.width <= 0 || btn.height <= 0) {
                    null
                } else {
                    val loc = IntArray(2)
                    btn.getLocationOnScreen(loc)
                    val ml = IntArray(2)
                    m.getLocationOnScreen(ml)
                    val sy = mainScroll?.scrollY ?: 0
                    val l = (loc[0] - ml[0]).toFloat()
                    val t = (loc[1] - ml[1] + sy).toFloat()
                    android.graphics.RectF(l, t, l + btn.width, t + btn.height)
                }
            }
        }
    }

    // Animated GIF (res/raw/login_anim.gif) shown on the login screen, rounded corners.
    private fun gifView(): ImageView = object : ImageView(this) {
        override fun onMeasure(w: Int, h: Int) {  // wide box: 79% of the screen width, 46% high
            val sw = resources.displayMetrics.widthPixels
            super.onMeasure(
                MeasureSpec.makeMeasureSpec(sw * 79 / 100, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(sw * 46 / 100, MeasureSpec.EXACTLY)
            )
        }
    }.apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        clipToOutline = true
        outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(16).toFloat())
            }
        }
        try {
            val d = android.graphics.ImageDecoder.decodeDrawable(
                android.graphics.ImageDecoder.createSource(resources, R.raw.login_anim)
            )
            setImageDrawable(d)
            if (d is android.graphics.drawable.AnimatedImageDrawable) {
                d.repeatCount = android.graphics.drawable.AnimatedImageDrawable.REPEAT_INFINITE
                d.start()
            }
        } catch (_: Throwable) {
        }
    }

    // Heading of a server list: gold colour, bold, with a down arrow that points at the list below it.
    private fun collapsibleSection(root: LinearLayout, title: String, key: String, body: LinearLayout) {
        // The section headings were removed: only a small gap is kept; each server card carries its own protocol chip.
        root.addView(View(this), LinearLayout.LayoutParams(1, dp(10)))
        body.visibility = View.VISIBLE
        // IKEv2 needs Android 14+: on Android 13 and below its server list is not shown at all.
        if (key == "sec_ik_open" && Build.VERSION.SDK_INT < 34) body.visibility = View.GONE
        root.addView(body)
    }

    // Small rounded action button (Add server / Save).
    private fun actionBtn(caption: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        text = caption
        setTextColor(0xFFFFFFFF.toInt())
        textSize = 13f
        isAllCaps = false
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(10), dp(4), dp(10), dp(4))
        background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(10).toFloat()
        }
        setOnClickListener { onClick() }
    }

    // Two action buttons side by side, each half the width.
    private fun actionRow(a: Button, b: Button) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(4) })
        addView(b, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4) })
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(4)
            bottomMargin = dp(4)
        }
    }

    // Clickable link that opens in the browser / Telegram.
    private fun linkView(caption: String, url: String): TextView = TextView(this).apply {
        text = caption
        textSize = 16f
        setTextColor(0xFF1E88E5.toInt())
        paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
        textDirection = View.TEXT_DIRECTION_LTR
        gravity = Gravity.START
        setPadding(0, dp(6), 0, dp(6))
        setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: Throwable) {
                toast(t("Could not open the link", "باز کردن لینک ممکن نشد"))
            }
        }
    }

    // "Version 35.0" line shown under the user name / password (login screen and settings).
    private fun versionView(): TextView = TextView(this).apply {
        val v = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Throwable) { "" }
        text = t("Version ", "نسخه ") + v
        textSize = 13f
        setTextColor(0xFFCCCCCC.toInt())
        gravity = Gravity.CENTER
        textDirection = View.TEXT_DIRECTION_LOCALE
    }

    // Removes invisible characters / outer spaces and turns Persian-Arabic digits into 0-9
    // (a Persian keyboard or the keyboard's auto-space is the most common reason a correct password "fails").
    private fun cleanCred(raw: String): String {
        val sb = StringBuilder()
        for (ch in raw) {
            when (ch) {
                in '\u200B'..'\u200F', in '\u202A'..'\u202E', in '\u2066'..'\u2069', '\uFEFF', '\u00A0' -> {}
                in '\u06F0'..'\u06F9' -> sb.append('0' + (ch - '\u06F0'))
                in '\u0660'..'\u0669' -> sb.append('0' + (ch - '\u0660'))
                else -> sb.append(ch)
            }
        }
        return sb.toString().trim()
    }

    // ---------- login screen ----------
    private fun buildLogin() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(30), dp(24), dp(28))
        }
        // Premium welcome header; the login background is now a clean custom gradient.
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(24))
            addView(TextView(context).apply {
                text = "✦"
                textSize = 42f
                gravity = Gravity.CENTER
                setTextColor(0xFF78D7FF.toInt())
                setShadowLayer(dp(18).toFloat(), 0f, 0f, 0xFF168BFF.toInt())
            })
            addView(TextView(context).apply {
                text = "VIP VPN"
                textSize = 30f
                letterSpacing = 0.12f
                gravity = Gravity.CENTER
                setTextColor(0xFFFFFFFF.toInt())
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setShadowLayer(dp(12).toFloat(), 0f, dp(2).toFloat(), 0xFF167BFF.toInt())
            })
            addView(TextView(context).apply {
                text = t("PRIVATE  •  FAST  •  SECURE", "خصوصی  •  پرسرعت  •  امن")
                textSize = 11f
                letterSpacing = 0.14f
                gravity = Gravity.CENTER
                setTextColor(0xFF9FCBFA.toInt())
                setPadding(0, dp(5), 0, 0)
            })
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(TextView(this).apply {
            text = t("Welcome back", "خوش اومدی")
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = t("Sign in to enjoy a free and open internet", "برای دسترسی به اینترنت آزاد وارد حساب خودت شو")
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(0xFFB8D5F5.toInt())
            setPadding(0, dp(6), 0, dp(18))
        })
        val u = field(t("User ID", "نام کاربری"), "").apply {
            textDirection = View.TEXT_DIRECTION_LTR
            gravity = Gravity.START
            background = null
        }
        val pw = field(t("Password", "رمز عبور"), "", true).apply {
            textDirection = View.TEXT_DIRECTION_LTR
            gravity = Gravity.START
            background = null
        }
        // User name + password inside one glowing blue card.
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            elevation = dp(10).toFloat()
            background = GradientDrawable().apply {
                setColor(0xE6091830.toInt())
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), 0x667ACBFF)
            }
        }
        fun iconRow(icon: Int, input: EditText, tail: View? = null) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            addView(ImageView(context).apply { setImageResource(icon) },
                LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginEnd = dp(12) })
            addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
            if (tail != null) addView(tail, LinearLayout.LayoutParams(dp(30), dp(30)))
        }
        // Whatever is typed here is remembered (also when the check fails or the app is closed), so the
        // User ID / password never has to be typed again; a new one typed later replaces the old one.
        u.setText(prefs.getString("login_draft_user", null) ?: prefs.getString("user", "") ?: "")
        pw.setText(prefs.getString("login_draft_pass", null) ?: prefs.getString("pass", "") ?: "")
        val draftWatcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(c: CharSequence?, a: Int, b: Int, d: Int) {}
            override fun onTextChanged(c: CharSequence?, a: Int, b: Int, d: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) {
                prefs.edit()
                    .putString("login_draft_user", u.text.toString())
                    .putString("login_draft_pass", pw.text.toString())
                    .apply()
            }
        }
        u.addTextChangedListener(draftWatcher)
        pw.addTextChangedListener(draftWatcher)
        val eye = ImageView(this).apply { setImageResource(R.drawable.ic_eye_off); setColorFilter(0xFFC9DAF5.toInt()) }
        card.addView(iconRow(R.drawable.ic_user, u))
        card.addView(View(this).apply { setBackgroundColor(0x557ACBFF) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply {
                topMargin = dp(2)
                bottomMargin = dp(2)
            })
        card.addView(iconRow(R.drawable.ic_lock, pw, eye))
        root.addView(card, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) })
        // Show-password box, so a typo can be seen before pressing Login.
        val showPw = android.widget.CheckBox(this).apply {
            text = t("Show password", "نمایش رمز عبور")
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            buttonTintList = android.content.res.ColorStateList.valueOf(0xFF2D7CFF.toInt())
            setOnCheckedChangeListener { _, on ->
                val sel = pw.selectionEnd
                pw.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
                    (if (on) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_TEXT_VARIATION_PASSWORD)
                pw.setSelection(sel.coerceAtLeast(0))
                eye.setImageResource(if (on) R.drawable.ic_eye else R.drawable.ic_eye_off)
            }
            isChecked = true // password is shown by default
        }
        eye.setOnClickListener { showPw.isChecked = !showPw.isChecked }
        // v189: the checkbox row is not shown any more (the eye icon is enough); the box stays only as the eye's state holder
        // No keyboard suggestions / auto-capitalisation / auto-space on the two fields.
        u.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        pw.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        val go = coloredButton(t("Login", "ورود"), 0xFF2E7D32.toInt()).apply {
            textSize = 18f
            elevation = dp(8).toFloat()
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF27B6FF.toInt(), 0xFF1768E8.toInt())).apply {
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), 0xFF79D8FF.toInt())
            }
            compoundDrawablePadding = dp(10)
            setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_login, 0, 0, 0)
            setPadding(dp(32), dp(8), dp(32), dp(8))
        }
        fun saveAndEnter(user: String, pass: String) {
            prefs.edit()
                .putString("user", user)
                .putString("pass", pass)
                .putString("login_draft_user", user)
                .putString("login_draft_pass", pass)
                .putBoolean("logged_in", true)
                .apply()
            // After login the user enters the app; no automatic connection - the user taps connect.
            showMain()
        }
        go.setOnClickListener {
            val user = cleanCred(u.text.toString())
            val pass = cleanCred(pw.text.toString())
            if (user.isEmpty() || pass.isEmpty()) {
                toast(t("Enter User ID and Password", "نام کاربری و رمز عبور را وارد کن"))
            } else {
                // Ask the real server whether this User ID / password is valid before letting the user in.
                go.isEnabled = false
                val oldText = go.text
                go.text = t("Checking...", "در حال بررسی...")
                // The site checks the account (same request as the old MyVPN app); no VPN server is tried here.
                thread(name = "login-check", isDaemon = true) {
                    val r = AccountInfo.fetch(this, user, pass)
                    runOnUiThread {
                        go.isEnabled = true
                        go.text = oldText
                        when {
                            r.days != null -> saveAndEnter(user, pass)
                            AccountInfo.isDeviceLimit(r.error) -> AlertDialog.Builder(this)
                                .setTitle(t("Account in use", "اکانت در حال استفاده است"))
                                .setMessage(AccountInfo.friendlyError(r.error, fa))
                                .setPositiveButton(t("OK", "باشه"), null)
                                .show()
                            r.answered -> AlertDialog.Builder(this)
                                .setTitle(t("Wrong User ID or password", "نام کاربری یا رمز اشتباه است"))
                                .setMessage(
                                    t(
                                        "The server did not accept this User ID / password (or the account has expired).",
                                        "سرور این نام کاربری و رمز را قبول نکرد (یا سرویس تمام شده)."
                                    ) + (if (r.error.isNotEmpty()) "\n\n" + r.error else "")
                                )
                                .setPositiveButton(t("OK", "باشه"), null)
                                .show()
                            else -> AlertDialog.Builder(this)
                                .setTitle(t("Login failed", "ورود انجام نشد"))
                                .setMessage(t(
                                    "User ID or password is wrong — pay attention to upper/lower case. Or change your internet: try mobile data or another WiFi.",
                                    "نام کاربری یا رمز عبور اشتباه هست، به حروف بزرگ و کوچیک دقت کنید. یا اینترنت رو عوض کنید، با نت گوشی یا وایفای دیگه امتحان کنید."
                                ))
                                .setPositiveButton(t("Try again", "تلاش دوباره")) { _, _ -> go.performClick() }
                                .setNegativeButton(t("Close", "بستن"), null)
                                .show()
                        }
                    }
                }
            }
        }
        root.addView(go, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) })
        // Protocol names only.
        val protocols = listOf("IKEv2", "L2TP", "Cisco")
        val protocolNames = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        for (label in protocols) {
            protocolNames.addView(TextView(this).apply {
                text = label
                textSize = 16f
                gravity = Gravity.CENTER
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(dp(8), dp(4), dp(8), dp(4))
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(protocolNames, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(18) })
        // v190: a short line under the protocol names
        root.addView(TextView(this).apply {
            text = t("Auto connect with just one tap to the best server", "اتصال خودکار فقط با یک کلیک به بهترین سرور")
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(0xFF9CC9F5.toInt())
            setPadding(dp(8), dp(2), dp(8), dp(2))
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) })

        // The version number sits at the very bottom of the login screen.
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(versionView(), LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) })
        if (fa) root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        showScreen(root, false, R.drawable.login_bg, 0x00000000)
    }

    // ---------- settings (globe icon) ----------
    // Shows the last crash + last connection error so it can be copied and sent.
    private fun showErrorLog() {
        val crash = try {
            java.io.File(filesDir, "crash_last.txt").takeIf { it.exists() }?.readText()
        } catch (_: Throwable) { null }
        val sb = StringBuilder()
        sb.append("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) ${Build.MANUFACTURER} ${Build.MODEL}\n")
        val appVer = try {
            packageManager.getPackageInfo(packageName, 0).versionCode
        } catch (_: Throwable) { -1 }
        sb.append("App: ").append(appVer).append("\n")
        sb.append("state: ").append(prefs.getString("state", "")).append("\n")
        sb.append("detail: ").append(prefs.getString("detail", "")).append("\n")
        sb.append("quickDrops: ").append(prefs.getInt("quick_drops", 0)).append("\n\n")
        sb.append(if (crash.isNullOrEmpty()) "No crash recorded.\n" else "LAST CRASH:\n$crash")
        sb.append("\n\nCONNECTION LOG / گزارش اتصال:\n")
        val connLog = ConnLog.read(this)
        sb.append(if (connLog.isBlank()) "(empty / خالی)\n" else connLog)
        val txt = sb.toString()
        val tv = TextView(this).apply {
            text = txt
            textSize = 11f
            setTextIsSelectable(true)
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        AlertDialog.Builder(this)
            .setTitle(t("Error log", "گزارش خطا"))
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton(t("Copy", "کپی")) { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("log", txt))
                toast(t("Copied", "کپی شد"))
            }
            .setNeutralButton(t("Clear", "پاک کردن")) { _, _ ->
                try { java.io.File(filesDir, "crash_last.txt").delete() } catch (_: Throwable) {}
                ConnLog.clear(this)
                prefs.edit().putString("detail", "").putInt("quick_drops", 0).apply()
            }
            .setNegativeButton(t("Close", "بستن"), null)
            .show()
    }

    // ---------- in-app update ----------
    // Quietly asks the server if a newer version exists; if so the Update button blinks.
    private fun silentUpdateCheck() {
        // Show the blink at once from the last answer we got (works even when GitHub is not reachable now).
        val cur = try { packageManager.getPackageInfo(packageName, 0).versionCode } catch (_: Throwable) { 0 }
        if (prefs.getInt("upd_seen_code", 0) > cur) { updateAvailable = true; if (uiReady) applyUpdateBlink() }
        Updater.cleanOld(this, cur)
        if (updChecking) return
        updChecking = true
        thread {
            try {
                val info = try { Updater.fetch(fa) } catch (_: Throwable) { null }
                if (info == null) { updCheckFailed = true; return@thread }
                updCheckFailed = false
                prefs.edit().putInt("upd_seen_code", info.code).apply()
                updateAvailable = info.code > cur
                runOnUiThread { if (uiReady) applyUpdateBlink() }
            } finally {
                updChecking = false
            }
        }
    }

    private fun stopUpdateBlink() {
        handler.removeCallbacks(updToggle)
        updToggling = false
        updToggle.showText = false
        updIconView?.visibility = View.VISIBLE
        updHoorayView?.visibility = View.INVISIBLE
        updBoxView?.alpha = 1f
    }

    private fun applyUpdateBlink() {
        if (updBoxView == null) return
        if (!updateAvailable) { stopUpdateBlink(); return }
        if (updToggling) return
        updToggling = true
        handler.post(updToggle)
    }

    private fun checkUpdate() {
        toast(t("Checking for update...", "در حال بررسی بروزرسانی..."))
        thread {
            val info = try { Updater.fetch(fa) } catch (_: Throwable) { null }
            val cur = try { packageManager.getPackageInfo(packageName, 0).versionCode } catch (_: Throwable) { 0 }
            runOnUiThread {
                when {
                    info == null -> toast(t("Could not check for update. Check your internet.", "بررسی بروزرسانی ممکن نشد. اینترنت را چک کن."))
                    info.code <= cur -> { updateAvailable = false; prefs.edit().putInt("upd_seen_code", info.code).apply(); stopUpdateBlink(); toast(t("You already have the latest version.", "آخرین نسخه را داری.")) }
                    else -> askUpdate(info)
                }
            }
        }
    }

    private fun askUpdate(info: Updater.Info) {
        AlertDialog.Builder(this)
            .setTitle(t("New version available", "نسخه جدید موجود است"))
            .setMessage(t("Version ", "نسخه ") + info.name + (if (info.notes.isNotBlank()) "\n\n" + info.notes else ""))
            .setPositiveButton(t("Update", "بروزرسانی")) { _, _ -> startDownload(info) }
            .setNegativeButton(t("Later", "بعداً"), null)
            .show()
    }

    private fun startDownload(info: Updater.Info) {
        // Already downloaded earlier (and not installed yet)? Install that file, no new download.
        val kept = Updater.cachedApk(this, info.code)
        if (kept.exists() && packageManager.canRequestPackageInstalls()) {
            thread {
                val ok = Updater.isCachedValid(this, kept, info)
                runOnUiThread {
                    if (ok) {
                        toast(t("Update was already downloaded — installing it.", "بروزرسانی قبلاً دانلود شده بود؛ همان نصب می‌شود."))
                        try { Updater.install(this, kept) } catch (e: Throwable) {
                            toast(t("Could not start install: ", "شروع نصب ممکن نشد: ") + (e.message ?: ""))
                        }
                    } else {
                        kept.delete()
                        downloadAndInstall(info)
                    }
                }
            }
            return
        }
        downloadAndInstall(info)
    }

    private fun downloadAndInstall(info: Updater.Info) {
        if (!packageManager.canRequestPackageInstalls()) {
            toast(t("Allow this app to install apps, then tap Update again.", "اجازه نصب برنامه را برای این برنامه روشن کن، بعد دوباره بروزرسانی را بزن."))
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            } catch (_: Throwable) {
            }
            return
        }
        val bar = android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            isIndeterminate = true
        }
        val holder = FrameLayout(this).apply {
            setPadding(dp(24), dp(16), dp(24), dp(8))
            addView(bar)
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle(t("Downloading update...", "در حال دانلود بروزرسانی..."))
            .setView(holder)
            .setCancelable(false)
            .show()
        thread {
            try {
                // Download to a .part file; only a complete, checked file gets its final name and is kept.
                val part = java.io.File(filesDir, "update_${info.code}.apk.part")
                val f = Updater.cachedApk(this, info.code)
                val sha = Updater.download(info.apk, part) { p ->
                    runOnUiThread { bar.isIndeterminate = false; bar.progress = p }
                }
                if (info.sha256.isNotEmpty() && !info.sha256.equals(sha, ignoreCase = true)) {
                    part.delete()
                    throw java.io.IOException("checksum mismatch")
                }
                f.delete()
                if (!part.renameTo(f)) { part.delete(); throw java.io.IOException("could not save file") }
                runOnUiThread {
                    try { dlg.dismiss() } catch (_: Throwable) {}
                    try { Updater.install(this, f) } catch (e: Throwable) {
                        toast(t("Could not start install: ", "شروع نصب ممکن نشد: ") + (e.message ?: ""))
                    }
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    try { dlg.dismiss() } catch (_: Throwable) {}
                    toast(t("Download failed", "دانلود ناموفق بود") + (e.message?.let { ": $it" } ?: ""))
                }
            }
        }
    }

    private fun showSettings() {
        val user = prefs.getString("user", "") ?: ""
        var dlg: AlertDialog? = null
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
            if (fa) layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun copyUser() {
            try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("user", user))
                toast(t("User ID copied", "نام کاربری کپی شد"))
            } catch (_: Throwable) {
            }
        }
        // Order is set by hand (the dialog ignores layoutDirection): Persian = name on the right, copy icon on the left.
        val userRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL or (if (fa) Gravity.RIGHT else Gravity.LEFT)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val userText = TextView(this).apply {
            text = t("User ID: ", "نام کاربری: ") + user
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            textDirection = View.TEXT_DIRECTION_LOCALE
            gravity = if (fa) Gravity.RIGHT else Gravity.LEFT
            setPadding(0, dp(8), 0, dp(4))
            setOnClickListener { copyUser() }
        }
        // Copy icon: tap it (or the name) to copy the user name.
        val copyIcon = TextView(this).apply {
            text = "\uD83D\uDCCB"
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(4), dp(12), dp(4))
            setOnClickListener { copyUser() }
        }
        if (fa) {
            userRow.addView(copyIcon, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            userRow.addView(userText, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        } else {
            userRow.addView(userText, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            userRow.addView(copyIcon, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        box.addView(userRow)
        // Days left on the account (from the site API). Shows the last known value at once, then refreshes it.
        val daysView = TextView(this).apply {
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            textDirection = View.TEXT_DIRECTION_LOCALE
            setPadding(0, 0, 0, dp(4))
        }
        fun showDays(d: Int?, loading: Boolean) {
            val label = t("Days left: ", "روز باقی‌مانده: ")
            daysView.text = if (d != null && d <= 0) t("Subscription ended", "پایان اشتراک")
                else label + (d?.toString() ?: if (loading) "…" else "—")
            daysView.setTextColor(when {
                d == null -> 0xFF616161.toInt()
                d <= 0 -> 0xFFC62828.toInt()
                d <= 7 -> 0xFFEF6C00.toInt()
                else -> 0xFF2E7D32.toInt()
            })
        }
        val daysNote = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFFEF6C00.toInt())
            textDirection = View.TEXT_DIRECTION_LOCALE
            visibility = View.GONE
            setPadding(0, 0, 0, dp(4))
        }
        // Remaining traffic (text exactly as the site sends it).
        val trafficView = TextView(this).apply {
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(0xFF2E7D32.toInt())
            textDirection = View.TEXT_DIRECTION_LOCALE
            setPadding(0, 0, 0, dp(4))
            visibility = View.GONE
        }
        fun showTraffic(tr: String) {
            if (tr.isEmpty()) { trafficView.visibility = View.GONE; return }
            // The site sends a bare number of megabytes (e.g. "500"); texts that already have a unit stay as they are.
            val mb = tr.trim().toDoubleOrNull()
            val shown = when {
                mb == null -> tr
                mb >= 1024 -> String.format(java.util.Locale.US, "%.2f GB", mb / 1024)
                else -> (if (mb == Math.floor(mb)) mb.toLong().toString() else String.format(java.util.Locale.US, "%.1f", mb)) + " MB"
            }
            trafficView.text = t("Data left: ", "حجم باقی‌مانده: ") + shown
            trafficView.visibility = View.VISIBLE
        }
        showDays(AccountInfo.cachedDays(this, user), true)
        showTraffic(AccountInfo.cachedTraffic(this, user))
        box.addView(daysView)
        box.addView(trafficView)
        box.addView(daysNote)
        val acctPass = prefs.getString("pass", "") ?: ""
        if (user.isNotEmpty() && acctPass.isNotEmpty()) {
            thread(name = "acct-days", isDaemon = true) {
                val r = AccountInfo.fetch(this, user, acctPass)
                runOnUiThread {
                    if (dlg?.isShowing == true) {
                        showDays(r.days ?: AccountInfo.cachedDays(this, user), false)
                        if (r.days != null) showTraffic(r.remainTraffic)
                        if (r.days == null && r.error.isNotEmpty()) {
                            daysNote.text = AccountInfo.friendlyError(r.error, fa)
                            daysNote.visibility = View.VISIBLE
                        }
                    }
                }
            }
        } else {
            showDays(null, false)
        }
        box.addView(versionView().apply {
            gravity = Gravity.START
            setPadding(0, 0, 0, dp(16))
        })
        box.addView(TextView(this).apply {
            text = "Language / زبان"
            textSize = 14f
        })
        val langRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun langBtn(name: String, code: String) = Button(this).apply {
            text = name
            setOnClickListener {
                dlg?.dismiss()
                saveAll()
                Lang.set(this@MainActivity, code)
                recreate()
            }
        }
        langRow.addView(langBtn("English", "en"), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        langRow.addView(langBtn("فارسی", "fa"), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(langRow)
        // Hide the monkey completely (the cheerful message after connecting still shows at the top).
        val hideMonkey = android.widget.CheckBox(this).apply {
            text = t("Hide the monkey", "مخفی شدن میمون")
            textSize = 15f
            setTextColor(0xFF1B5E20.toInt())
            isChecked = prefs.getBoolean("hide_monkey", false)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("hide_monkey", on).apply()
                dlg?.dismiss()
                saveAll()
                recreate()
            }
        }
        // green frame around the option
        val hideFrame = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(4))
            background = GradientDrawable().apply {
                setColor(0xFFE8F5E9.toInt())
                setStroke(dp(2), 0xFF2E7D32.toInt())
                cornerRadius = dp(12).toFloat()
            }
            addView(hideMonkey, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            setOnClickListener { hideMonkey.toggle() }
        }
        box.addView(hideFrame, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) })
        val errBtn = coloredButton(t("Error log (copy)", "گزارش خطا (کپی)"), 0xFF616161.toInt())
        errBtn.setOnClickListener {
            dlg?.dismiss()
            showErrorLog()
        }
        box.addView(errBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) })
        val out = coloredButton(t("Log out", "خروج از حساب"), 0xFFC62828.toInt())
        out.setOnClickListener {
            dlg?.dismiss()
            saveAll()
            disconnect()
            prefs.edit().remove("user").remove("pass").putBoolean("logged_in", false).apply()
            showLogin()
        }
        box.addView(out, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })
        dlg = AlertDialog.Builder(this)
            .setTitle(t("Settings", "تنظیمات"))
            .setView(box)
            .setNegativeButton(t("Close", "بستن"), null)
            .create()
        dlg?.show()
    }

    private fun buildUi() {
        rows.clear()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        val header = FrameLayout(this)
        header.layoutDirection = View.LAYOUT_DIRECTION_LTR  // always the top-right corner, in both languages
        fun cap(txt: String) = TextView(this).apply {
            text = txt
            textSize = 11f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            maxLines = 1
        }
        // Update button (download-arrow icon + caption).
        val updIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_update)
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0xFF1565C0.toInt())
            }
        }
        val updBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            contentDescription = t("Check for update", "بروزرسانی برنامه")
            val hooray = TextView(this@MainActivity).apply {
                text = t("Update is here!\nHooray 🎉", "آپدیت اومد\nهوراا 🎉")
                textSize = 10f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(0xFFFFFFFF.toInt())
                gravity = Gravity.CENTER
                setPadding(dp(2), dp(2), dp(2), dp(2))
                visibility = View.INVISIBLE
                background = GradientDrawable().apply {
                    setColor(0xFF2E7D32.toInt())
                    cornerRadius = dp(12).toFloat()
                }
            }
            val slot = FrameLayout(this@MainActivity)
            slot.addView(hooray, FrameLayout.LayoutParams(dp(72), dp(40), Gravity.CENTER))
            slot.addView(updIcon, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER))
            updIconView = updIcon
            updHoorayView = hooray
            addView(slot, LinearLayout.LayoutParams(dp(72), dp(40)))
            addView(cap(t("Update", "بروزرسانی")))
            setOnClickListener { checkUpdate() }
        }
        stopUpdateBlink()
        updBoxView = updBox
        // Settings button: same bold filled-circle style and colour as the Update button (gear icon).
        val setIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_settings)
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0xFF1565C0.toInt())
            }
        }
        val setBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            contentDescription = t("Settings", "تنظیمات")
            addView(setIcon, LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(cap(t("Settings", "تنظیمات")))
            setOnClickListener { showSettings() }
        }
        // Settings at the top-left corner, Update at the top-right corner.
        settingsBoxView = setBox
        header.addView(setBox, FrameLayout.LayoutParams(
            dp(72), FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.TOP
        ))
        header.addView(updBox, FrameLayout.LayoutParams(
            dp(72), FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.TOP
        ))
        // Celebration banner between the two corner buttons (hidden until a connection comes up).
        val celeb = TextView(this).apply {
            text = t("Hooray, connected! \uD83C\uDF89\nGo enjoy the internet, filters are history \uD83D\uDE0E",
                "\uD83C\uDF89 هوررا، وصل شد!\nبرو تو اینترنت عشق و حال کن \uD83D\uDE0E")
            textSize = 10.5f   // v134: a bit smaller, so the monkey fits beside it without covering settings / update
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(5), dp(6), dp(5))
            visibility = View.GONE
            background = GradientDrawable().apply {
                setColor(0xFF2E7D32.toInt())
                setStroke(dp(2), 0xFF69F0AE.toInt())
                cornerRadius = dp(14).toFloat()
            }
        }
        celebView = celeb
        header.addView(celeb, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL
        ).apply {
            marginStart = dp(96)
            marginEnd = dp(96)
        })
        root.addView(header)
        applyUpdateBlink()

        // Large country flag shown only when connected / connecting.
        flagView = TextView(this).apply {
            textSize = 56f
            gravity = Gravity.CENTER
            visibility = View.GONE
            setPadding(0, dp(4), 0, 0)
        }
        root.addView(flagView)

        statusText = TextView(this).apply {
            text = showState()
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(statusText)
        detailView = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFFFFCC80.toInt())
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        root.addView(detailView)
        fun protoBtn(proto: String) = Button(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            textSize = 14f
            isAllCaps = false
            gravity = Gravity.CENTER
            minWidth = 0
            minHeight = 0
            minimumWidth = 0
            minimumHeight = 0
            setPadding(dp(6), dp(6), dp(6), dp(6))
            setOnClickListener { onProtoClick(proto) }
        }
        ikBtn = protoBtn("ikev2")
        l2Btn = protoBtn("l2tp")
        fun protoColumn(btn: Button) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            // Android 14+: one bigger round button with the longer label.
            val size = if (Build.VERSION.SDK_INT >= 34 && btn === ikBtn) 175 else 140
            addView(btn, LinearLayout.LayoutParams(dp(size), dp(size)))
        }
        // Left = IKEv2, right = L2TP (same order in English and Persian).
        val protoRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        protoRow.addView(protoColumn(ikBtn),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        protoRow.addView(protoColumn(l2Btn),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        // On Android 13 and below the IKEv2 button is hidden completely (L2TP stays, centred).
        if (Build.VERSION.SDK_INT < 34) (ikBtn.parent as? View)?.visibility = View.GONE
        // On Android 14+ only ONE auto button is shown (IKEv2 -> Cisco -> L2TP); the L2TP button is hidden.
        else (l2Btn.parent as? View)?.visibility = View.GONE
        root.addView(protoRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(16)
            bottomMargin = dp(8)
        })

        // One button hides / shows both server lists. Servers are shown by default.
        val serversWrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val hideBtn = Button(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
            isAllCaps = false
            minHeight = 0
            minimumHeight = 0
            compoundDrawablePadding = dp(8)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                setColor(0x66000000)
                setStroke(dp(1), 0xAAFFFFFF.toInt())
                cornerRadius = dp(12).toFloat()
            }
        }
        fun applyHidden(hidden: Boolean) {
            serversWrap.visibility = if (hidden) View.GONE else View.VISIBLE
            hideBtn.text = if (hidden) t("Servers hidden — tap to show", "سرورها مخفی شدند — برای باز کردن بزنید")
                           else t("Hide servers", "مخفی شدن سرورها")
            // hidden -> crossed-out eye, visible -> open eye
            hideBtn.setCompoundDrawablesRelativeWithIntrinsicBounds(
                if (hidden) R.drawable.ic_eye_off else R.drawable.ic_eye, 0, 0, 0
            )
        }
        var serversHidden = prefs.getBoolean("servers_hidden", false)
        applyHidden(serversHidden)
        hideBtn.setOnClickListener {
            serversHidden = !serversHidden
            prefs.edit().putBoolean("servers_hidden", serversHidden).apply()
            applyHidden(serversHidden)
        }
        hideBarView = hideBtn
        root.addView(hideBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(24) })
        root.addView(serversWrap)

        val ikBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        collapsibleSection(serversWrap, t("IKEv2 servers", "سرورهای IKEv2"), "sec_ik_open", ikBody)
        serversBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ikBody.addView(serversBox)
        val saved = ConnService.loadHosts(prefs)
        saved.forEach { addRow(it) }

        // Built-in L2TP servers (fixed list, same card look as the IKEv2 servers).
        val l2Body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        collapsibleSection(serversWrap, t("Cisco & L2TP servers", "سرورهای Cisco و L2TP"), "sec_l2_open", l2Body)
        l2Box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        l2Body.addView(l2Box)
        l2Rows.clear()
        val l2Saved = L2tpServerPresets.load(prefs)
        l2Saved.forEach { addL2Row(it) }
        repeat(maxOf(0, 2 - l2Saved.size)) { addL2Row("") }
        // Two separate "add" buttons (an L2TP server / a Cisco server), then Save on its own line.
        l2Body.addView(actionRow(
            actionBtn(t("+ Add L2TP server", "+ افزودن سرور L2TP"), 0xFF1565C0.toInt()) { addL2Row("") },
            actionBtn(t("+ Add Cisco server", "+ افزودن سرور Cisco"), 0xFF1565C0.toInt()) { addL2Row(L2tpVpnService.CISCO_PREFIX) }
        ))
        if (Build.VERSION.SDK_INT >= 34) {
            l2Body.addView(actionBtn(t("+ Add IKEv2 server", "+ افزودن سرور IKEv2"), 0xFF1565C0.toInt()) { addRow("") },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)).apply { topMargin = dp(4) })
        }
        l2Body.addView(actionBtn(t("Save", "ذخیره"), 0xFF2E7D32.toInt()) { saveAll(); toast(t("Saved", "ذخیره شد")); runPings(); runL2tpPings() },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)).apply {
                topMargin = dp(4)
                bottomMargin = dp(4)
            })

        // Animated GIF at the very bottom, under all servers.
        root.addView(gifView(), LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(24)
            bottomMargin = dp(24)
        })

        if (fa) root.layoutDirection = View.LAYOUT_DIRECTION_RTL

        showScreen(root, true)
    }

    // Pencil button next to the trash button. A saved server address is locked; the pencil unlocks it,
    // and the same button (now a check mark) locks it again, saves and re-pings. Empty (new) rows start unlocked.
    // Small rounded icon button (vector icon on a coloured rounded square) used for pencil / check / trash.
    private fun iconButton(icon: Int, color: Int, desc: String): ImageButton = ImageButton(this).apply {
        setImageResource(icon)
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        contentDescription = desc
        setPadding(dp(8), dp(8), dp(8), dp(8))
        background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(10).toFloat()
        }
        elevation = dp(2).toFloat()
        layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginStart = dp(6) }
    }

    private fun trashButton(): ImageButton = iconButton(R.drawable.ic_trash, 0xFFD32F2F.toInt(), t("Delete", "حذف"))

    private fun editButton(h: EditText, onDone: () -> Unit): ImageButton {
        val editColor = 0xFF1E88E5.toInt()   // blue pencil
        val okColor = 0xFF2E7D32.toInt()     // green check
        val b = iconButton(R.drawable.ic_edit, editColor, t("Edit", "ویرایش"))
        fun showPencil() {
            b.setImageResource(R.drawable.ic_edit)
            (b.background as GradientDrawable).setColor(editColor)
            b.contentDescription = t("Edit", "ویرایش")
        }
        fun showCheck() {
            b.setImageResource(R.drawable.ic_check)
            (b.background as GradientDrawable).setColor(okColor)
            b.contentDescription = t("Save", "ذخیره")
        }
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        fun unlock() {
            h.isEnabled = true
            showCheck()
            h.requestFocus()
            h.setSelection(h.text.length)
            imm.showSoftInput(h, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        }
        fun lock() {
            h.isEnabled = false
            h.clearFocus()
            showPencil()
            imm.hideSoftInputFromWindow(h.windowToken, 0)
        }
        // A pencil unlocks a saved (locked) address; the same button, now a green check, saves and locks it again.
        // Empty (new) rows start unlocked.
        if (h.text.toString().trim().isEmpty()) {
            h.isEnabled = true
            showCheck()
        } else {
            h.isEnabled = false
            showPencil()
        }
        b.setOnClickListener {
            if (h.isEnabled) {
                if (h.text.toString().trim().isEmpty()) return@setOnClickListener
                lock()
                onDone()
            } else {
                unlock()
            }
        }
        return b
    }

    private fun addRow(host: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val h = field(t("Server IP or hostname", "آی‌پی یا آدرس سرور"), host).apply {
            textDirection = View.TEXT_DIRECTION_LTR
            gravity = Gravity.START
            textSize = 15f
            minHeight = 0
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        line.addView(h, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val go = Button(this).apply {
            text = t("Manual connect", "اتصال دستی")
            textSize = 12f
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(8), dp(4), dp(8), dp(4))
            minWidth = 0
            minimumWidth = 0
            setOnClickListener {
                val me = h.text.toString().trim()
                if (me.isNotEmpty() && mode() == "ikev2" && me == activeHost()) {
                    disconnect()
                } else {
                    saveAll()
                    pressFeedback(this, me)
                    startProto("ikev2", me)
                }
            }
        }
        val del = trashButton()
        line.addView(go, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(36)))
        line.addView(editButton(h) { saveAll(); runPings() })
        line.addView(del)
        val pv = TextView(this).apply {
            text = t("Ping: -", "پینگ: -")
            textSize = 12f
            setTextColor(0xFFCCCCCC.toInt())
        }
        // Purple protocol chip (Cisco is blue, L2TP is grey).
        val chip = TextView(this).apply {
            text = "IKEv2"
            textSize = 11f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(10), dp(3), dp(10), dp(3))
            background = GradientDrawable().apply {
                setColor(0xFF7B1FA2.toInt())
                cornerRadius = dp(10).toFloat()
            }
        }
        val pingLine = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val flagTv = makeFlagView()
        refreshFlag(flagTv, h.text.toString())
        pingLine.addView(flagTv)
        pingLine.addView(pv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        pingLine.addView(chip)
        box.addView(line)
        box.addView(pingLine)
        val row = Row(box, h, pv, go, flagTv)
        rows.add(row)
        serversBox.addView(box)
        // Each server sits in its own rounded card.
        box.background = GradientDrawable().apply {
            setColor(0x73000000)
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), 0x66FFFFFF)
        }
        box.setPadding(dp(8), dp(8), dp(8), dp(8))
        (box.layoutParams as ViewGroup.MarginLayoutParams).bottomMargin = dp(6)
        styleServerBtn(go, 0)
        if (uiReady) updateStatus()
        del.setOnClickListener {
            val name = h.text.toString().trim()
            AlertDialog.Builder(this)
                .setTitle(t("Delete server", "حذف سرور"))
                .setMessage(t("Delete this server?", "این سرور پاک شود؟") + (if (name.isNotEmpty()) "\n" + name else ""))
                .setPositiveButton(t("Yes, delete", "بله، پاک کن")) { _, _ ->
                    rows.remove(row)
                    serversBox.removeView(box)
                    saveAll()
                }
                .setNegativeButton(t("No", "خیر"), null)
                .show()
        }
    }

    private fun addL2Row(stored: String) {
        val isC = L2tpVpnService.isCisco(stored)
        val host = L2tpVpnService.plainOf(stored)
        lateinit var self: L2Row
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val h = field(t("Server IP or hostname", "آی‌پی یا آدرس سرور"), host).apply {
            textDirection = View.TEXT_DIRECTION_LTR
            gravity = Gravity.START
            textSize = 15f
            minHeight = 0
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        line.addView(h, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val go = Button(this).apply {
            textSize = 12f
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(8), dp(4), dp(8), dp(4))
            minWidth = 0
            minimumWidth = 0
            setOnClickListener {
                val me = h.text.toString().trim()
                if (me.isEmpty()) return@setOnClickListener
                if (isActive() && mode() == "l2tp" && me == activeHost()) {
                    disconnect()
                } else {
                    saveAll()
                    pressFeedback(this, me)
                    startProto("l2tp", (if (self.cisco) L2tpVpnService.CISCO_PREFIX else "") + me)
                }
            }
        }
        val del = trashButton()
        line.addView(go, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(36)))
        line.addView(editButton(h) { saveAll(); runL2tpPings() })
        line.addView(del)
        val pv = TextView(this).apply {
            text = t("Ping: -", "پینگ: -")
            textSize = 12f
            setTextColor(0xFFCCCCCC.toInt())
        }
        // Protocol chip: tap to switch this server between L2TP and Cisco (AnyConnect).
        val chip = TextView(this).apply {
            textSize = 11f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(10), dp(3), dp(10), dp(3))
        }
        fun styleChip() {
            chip.text = if (self.cisco) "Cisco" else "L2TP"
            chip.background = GradientDrawable().apply {
                setColor(if (self.cisco) 0xFF1565C0.toInt() else 0xFF455A64.toInt())
                cornerRadius = dp(10).toFloat()
            }
        }
        val pingLine = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val flagTv = makeFlagView()
        refreshFlag(flagTv, h.text.toString())
        pingLine.addView(flagTv)
        pingLine.addView(pv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        pingLine.addView(chip)
        box.addView(line)
        box.addView(pingLine)
        val row = L2Row(box, h, pv, go, isC, flagTv)
        self = row
        styleChip()
        chip.setOnClickListener {
            self.cisco = !self.cisco
            styleChip()
            saveAll()
            runL2tpPings()
            toast(if (self.cisco) t("Cisco (AnyConnect, TCP 443)", "Cisco (AnyConnect، پورت TCP 443)") else t("L2TP/IPsec", "L2TP/IPsec"))
        }
        l2Rows.add(row)
        l2Box.addView(box)
        box.background = GradientDrawable().apply {
            setColor(0x73000000)
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), 0x66FFFFFF)
        }
        box.setPadding(dp(8), dp(8), dp(8), dp(8))
        (box.layoutParams as ViewGroup.MarginLayoutParams).bottomMargin = dp(6)
        styleServerBtn(go, 0)
        if (uiReady) updateStatus()
        del.setOnClickListener {
            val name = h.text.toString().trim()
            AlertDialog.Builder(this)
                .setTitle(t("Delete server", "حذف سرور"))
                .setMessage(t("Delete this server?", "این سرور پاک شود؟") + (if (name.isNotEmpty()) "\n" + name else ""))
                .setPositiveButton(t("Yes, delete", "بله، پاک کن")) { _, _ ->
                    l2Rows.remove(row)
                    l2Box.removeView(box)
                    saveAll()
                }
                .setNegativeButton(t("No", "خیر"), null)
                .show()
        }
    }

    // The real (non-VPN) network. Used for pings while a VPN is on, so the numbers show the distance to the
    // server and the probes do not travel through the tunnel (that is why L2TP pings failed during IKEv2).
    private fun underlyingNetwork(): android.net.Network? = try {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        cm.allNetworks.filter { n ->
            val nc = cm.getNetworkCapabilities(n)
            nc != null && nc.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                !nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN) &&
                nc.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_SUSPENDED)
        }.maxByOrNull { n ->
            val nc = cm.getNetworkCapabilities(n)!!
            (if (nc.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)) 2 else 0) +
                (if (nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)) 1 else 0)
        }
    } catch (_: Throwable) { null }

    // L2TP servers do not answer on TCP 443/80, so their ping is the time of the first real IKE answer
    // (UDP 500). While a VPN is on, the probe is bound to the real network so it does not use the tunnel.
    private fun runL2tpPings() {
        if (l2Pinging || l2Rows.isEmpty()) return
        l2Pinging = true
        val net = if (isActive()) underlyingNetwork() else null
        val snapshot = l2Rows.toList()
        val names = snapshot.map { it.host.text.toString().trim() }
        val kinds = snapshot.map { it.cisco }
        val res = LongArray(snapshot.size) { -2 } // -2 = not finished yet
        val dash = listOf("Ping: -", "پینگ: -")
        for (i in snapshot.indices) {
            if (names[i].isEmpty()) snapshot[i].ping.text = t("Ping: -", "پینگ: -")
            else if (snapshot[i].ping.text.toString() in dash) snapshot[i].ping.text = t("Ping: testing...", "پینگ: در حال تست...")
        }
        thread {
            try {
                snapshot.mapIndexed { i, r ->
                    thread {
                        val ip = try {
                            if (names[i].isEmpty()) null
                            else Dns.resolve4(names[i], net)
                        } catch (_: Throwable) {
                            null
                        }
                        res[i] = if (names[i].isEmpty()) -3L else if (ip == null) -4L
                        else if (kinds[i]) CiscoClient.probe(ip, { sk -> try { net?.bindSocket(sk) } catch (_: Throwable) {} }, 2500)
                        else Ike.probe(ip, { p ->
                            val sock = java.net.DatagramSocket(p)
                            try { net?.bindSocket(sock) } catch (_: Throwable) {}
                            sock
                        }, 1500)
                        runOnUiThread { renderL2Pings(snapshot, res) }
                    }
                }.forEach { it.join() }
            } finally {
                l2Pinging = false
            }
        }
    }

    private fun renderL2Pings(snapshot: List<L2Row>, res: LongArray) {
        val best = res.indices.filter { res[it] >= 0 }.minByOrNull { res[it] }
        for (i in snapshot.indices) {
            val r = res[i]
            refreshFlag(snapshot[i].flag, snapshot[i].host.text.toString())
            if (r == -2L) continue
            snapshot[i].ping.text = when {
                r == -3L -> t("Ping: -", "پینگ: -")
                r == -4L -> t("Ping: address not found", "پینگ: آدرس پیدا نشد")
                r < 0 -> t("Ping: no response", "پینگ: بدون پاسخ")
                i == best -> t("Ping: $r ms  ★ Best", "پینگ: $r میلی‌ثانیه  ★ بهترین")
                else -> t("Ping: $r ms", "پینگ: $r میلی‌ثانیه")
            }
        }
    }

    private fun currentHosts(): List<String> =
        rows.map { it.host.text.toString().trim() }.filter { it.isNotEmpty() }

    private fun saveAll() {
        prefs.edit()
            .putString("hosts", currentHosts().joinToString("\n"))
            .apply { if (::l2Box.isInitialized) putString("l2hosts", l2Rows.map { (if (it.cisco) L2tpVpnService.CISCO_PREFIX else "") + it.host.text.toString().trim() }.filter { it.substringAfter(":").trim().isNotEmpty() }.joinToString("\n")) }
            // Keep previously saved MTU (default 1280 for better WiFi compatibility)
            .putString("mtu", prefs.getString("mtu", "1280") ?: "1280")
            .apply()
    }

    // ---------- permissions ----------
    private fun askBatteryExemption() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:$packageName"))
                )
            } catch (_: Exception) {
            }
        }
    }

    // ---------- protocol buttons ----------
    private fun onProtoClick(proto: String) {
        if (isActive() && (Build.VERSION.SDK_INT >= 34 || mode() == proto)) {
            disconnect()
        } else {
            saveAll()
            manualPending = null // an earlier manual tap must not keep a row orange during Auto
            startProto(proto, null)
        }
    }

    // Starts [proto] ("ikev2" / "l2tp"). only = one server chosen by the user, null = best server.
    // If another connection is up (or an L2TP server is being changed) it is stopped first.
    private fun startProto(proto: String, only: String?) {
        if (proto == "ikev2" && Build.VERSION.SDK_INT < 34) {
            toast(t("IKEv2 requires Android 14 or higher. Use the L2TP button.", "IKEv2 به اندروید ۱۴ یا بالاتر نیاز دارد. از دکمه L2TP استفاده کن."))
            return
        }
        val launch = {
            if (proto == "l2tp") connectL2tp(only)
            else if (only == null && Build.VERSION.SDK_INT >= 34) connectAuto()
            else connect(only)
        }
        if (isActive() && (mode() != proto || proto == "l2tp")) {
            disconnect(keepPending = true)
            handler.postDelayed({ launch() }, 800)
        } else {
            launch()
        }
    }

    // L2TP/IPsec runs inside the app and uses a normal Android VpnService (works on Android 10+).
    private fun connectL2tp(only: String?) {
        val user = prefs.getString("user", "") ?: ""
        val pass = prefs.getString("pass", "") ?: ""
        if (user.isEmpty() || pass.isEmpty()) {
            toast(t("Enter User ID and Password", "نام کاربری و رمز عبور را وارد کن"))
            return
        }
        try {
            val consent = VpnService.prepare(this)
            val go = { sendL2tp(only) }
            if (consent == null) {
                go()
            } else {
                afterConsent = go
                startActivityForResult(consent, 101)
            }
        } catch (e: Throwable) {
            val msg = e.javaClass.simpleName + ": " + (e.message ?: "unknown")
            prefs.edit().putString("state", "Error: $msg").putString("detail", msg).apply()
            toast(t("Error: ", "خطا: ") + msg)
            updateStatus()
        }
    }

    private fun sendL2tp(only: String?) {
        // Show progress at once; the service replaces this with the real state.
        prefs.edit().putString("mode", "l2tp").putString("state", "Testing servers...").putString("detail", "").apply()
        updateStatus()
        val i = Intent(this, L2tpVpnService::class.java).setAction(L2tpVpnService.ACTION_CONNECT)
        if (only != null) i.putExtra(L2tpVpnService.EXTRA_HOST, only)
        try {
            startForegroundService(i)
        } catch (e: Throwable) {
            try {
                startService(i)
            } catch (e2: Throwable) {
                prefs.edit().putString("state", "Disconnected").apply()
                updateStatus()
                toast(t("Error: ", "خطا: ") + (e2.message ?: e.message))
            }
        }
    }

    // Android 14+ auto button. The Cisco / L2TP fallback needs the normal VPN permission too, so ask for it first.
    private fun connectAuto() {
        val consent = try { VpnService.prepare(this) } catch (_: Throwable) { null }
        if (consent == null) {
            connect(null)
        } else {
            afterConsent = { connect(null) }
            try {
                startActivityForResult(consent, 101)
            } catch (_: Throwable) {
                afterConsent = null
                connect(null)
            }
        }
    }

    // ---------- connect (IKEv2) ----------
    // only = a server picked by the user. null = best server.
    // The VPN permission dialog must be shown from an Activity.
    private fun connect(only: String?) {
        if (Build.VERSION.SDK_INT < 34) {
            toast(t("IKEv2 requires Android 14 or higher. Use the L2TP button.", "IKEv2 به اندروید ۱۴ یا بالاتر نیاز دارد. از دکمه L2TP استفاده کن."))
            return
        }
        prefs.edit().putString("mode", "ikev2").apply()
        val target = only ?: currentHosts().firstOrNull()
        if (target.isNullOrEmpty()) {
            toast(t("Add at least one server", "حداقل یک سرور اضافه کن"))
            return
        }
        val user = prefs.getString("user", "") ?: ""
        val pass = prefs.getString("pass", "") ?: ""
        if (user.isEmpty() || pass.isEmpty()) {
            toast(t("Enter User ID and Password", "نام کاربری و رمز عبور را وارد کن"))
            return
        }
        try {
            val mtu = prefs.getString("mtu", "1280")?.toIntOrNull() ?: 1280
            val profile = ConnService.buildProfile(target, user, pass, "", mtu)
            val mgr = vpnManager as? VpnManager
            if (mgr == null) {
                toast(t("This VPN requires Android 11 or higher", "این VPN به اندروید ۱۱ یا بالاتر نیاز دارد"))
                return
            }
            val consent = try {
                mgr.provisionVpnProfile(profile)
            } catch (e: SecurityException) {
                toast(t("Error: ", "خطا: ") + "VPN permission / SecurityException: " + e.message)
                return
            } catch (e: IllegalStateException) {
                toast(t("Error: ", "خطا: ") + "IllegalState: " + e.message)
                return
            }
            val go = { sendConnect(only) }
            if (consent == null) {
                go()
            } else {
                afterConsent = go
                try {
                    startActivityForResult(consent, 100)
                } catch (e: Exception) {
                    toast(t("Error: ", "خطا: ") + "consent UI: " + e.message)
                }
            }
        } catch (e: Throwable) {
            val msg = e.javaClass.simpleName + ": " + (e.message ?: "unknown")
            prefs.edit().putString("state", "Error: $msg").putString("detail", msg).apply()
            toast(t("Error: ", "خطا: ") + msg)
            updateStatus()
        }
    }

    private fun sendConnect(only: String?) {
        val i = Intent(this, ConnService::class.java).setAction(ConnService.ACTION_CONNECT)
        if (only != null) i.putExtra(ConnService.EXTRA_HOST, only)
        else if (Build.VERSION.SDK_INT >= 34) i.putExtra(ConnService.EXTRA_FALLBACK, true)
        try {
            startForegroundService(i)
        } catch (e: Throwable) {
            try {
                startService(i)
            } catch (e2: Throwable) {
                toast(t("Error: ", "خطا: ") + (e2.message ?: e.message))
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val next = afterConsent
        afterConsent = null // cleared first: the next step may ask for another permission
        if ((requestCode == 100 || requestCode == 101) && resultCode == RESULT_OK) next?.invoke()
    }

    // Runs every 10 seconds (and as soon as the app opens). Each server's ping is shown
    // the moment it is ready; the best one gets a star.
    private fun runPings() {
        if (pinging) return
        if (Build.VERSION.SDK_INT < 34) return  // IKEv2 list is hidden on Android 13 and below
        pinging = true
        val net = if (isActive()) underlyingNetwork() else null
        val snapshot = rows.toList()
        val hosts = snapshot.map { it.host.text.toString().trim() }
        val res = LongArray(hosts.size) { -2 } // -2 = not finished yet
        val dash = listOf("Ping: -", "پینگ: -")
        for (i in snapshot.indices) {
            val cur = snapshot[i].ping.text.toString()
            if (hosts[i].isEmpty()) {
                snapshot[i].ping.text = t("Ping: -", "پینگ: -")
            } else if (cur in dash) {
                snapshot[i].ping.text = t("Ping: testing...", "پینگ: در حال تست...")
            }
        }
        thread {
            try {
                hosts.mapIndexed { i, h ->
                    thread {
                        res[i] = if (h.isEmpty()) -3 else ConnService.tcpPing(h, net)
                        runOnUiThread { renderPings(snapshot, hosts, res) }
                    }
                }.forEach { it.join() }
            } finally {
                pinging = false
            }
        }
    }

    private fun renderPings(snapshot: List<Row>, hosts: List<String>, res: LongArray) {
        val best = res.indices.filter { res[it] >= 0 }.minByOrNull { res[it] }
        for (i in snapshot.indices) {
            val r = res[i]
            refreshFlag(snapshot[i].flag, snapshot[i].host.text.toString())
            if (r == -2L) continue // still testing: keep the old text
            snapshot[i].ping.text = when {
                hosts[i].isEmpty() -> t("Ping: -", "پینگ: -")
                r < 0 -> t("Ping: no response", "پینگ: بدون پاسخ")
                i == best -> t("Ping: $r ms  ★ Best", "پینگ: $r میلی‌ثانیه  ★ بهترین")
                else -> t("Ping: $r ms", "پینگ: $r میلی‌ثانیه")
            }
        }
    }

    private fun disconnect(keepPending: Boolean = false) {
        if (!keepPending) manualPending = null // user turned it off: no row may stay orange
        if (Build.VERSION.SDK_INT >= 30 && mode() != "l2tp") {
            try {
                (vpnManager as? VpnManager)?.stopProvisionedVpnProfile()
            } catch (_: Exception) {
            }
        }
        stopService(Intent(this, ConnService::class.java))
        L2tpVpnService.requestStop(this)
        prefs.edit().putString("state", "Disconnected").putString("detail", "").apply()
        updateStatus()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
