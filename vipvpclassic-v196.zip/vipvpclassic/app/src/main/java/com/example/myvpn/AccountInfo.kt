package com.example.myvpn

import android.content.Context
import android.os.Build
import android.provider.Settings
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Remaining days of the account, taken from the same site API the old MyVPN app uses:
 *   POST <base>/index.php?APIKEY=...&ACTION=AUTH   body: user=..&pass=..&os=android&device=..
 * The answer is JSON; the number of days left is the field "remain_days".
 * https is tried first, then plain http (the old app only used http://api.gsmvx.com).
 * Every attempt is written to the Error log (Settings > Error log) so a failure can be diagnosed.
 */
object AccountInfo {
    private const val API_KEY = "0c8ac86b-7712-4cd1-94bc-a7c6b12df4c7"
    private val BASES = listOf("https://api.gsmvx.com", "http://api.gsmvx.com")

    /**
     * days = null when the server did not send a number; error = short reason text (may be empty).
     * answered = the server really replied with JSON (false = network problem / not reachable).
     */
    class Info(
        val days: Int?, val expDate: String, val error: String,
        val answered: Boolean = false, val remainTraffic: String = "", val totalTraffic: String = ""
    )

    fun isDeviceLimit(error: String) = error.contains("DEVICE_LIMIT", ignoreCase = true)

    /** Text shown to the user for a server error code (DEVICE_LIMIT_REACHED = account already used elsewhere). */
    fun friendlyError(error: String, fa: Boolean): String =
        if (isDeviceLimit(error))
            (if (fa) "این اکانت در برنامه دیگری مثل MyVPN متصل شده است"
             else "This account is connected in another app such as MyVPN")
        else error

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("account", Context.MODE_PRIVATE)

    /** Last days value fetched successfully for this user (null = never). */
    fun cachedDays(ctx: Context, user: String): Int? =
        prefs(ctx).let { if (it.getString("cache_user", null) == user && it.contains("days")) it.getInt("days", 0) else null }

    /** Last remaining-traffic text fetched successfully for this user ("" = none). */
    fun cachedTraffic(ctx: Context, user: String): String =
        prefs(ctx).let { if (it.getString("cache_user", null) == user) it.getString("remain_traffic", "") ?: "" else "" }

    private fun deviceKey(ctx: Context): String {
        val id = try { Settings.Secure.getString(ctx.contentResolver, "android_id") ?: "" } catch (_: Throwable) { "" }
        return id + "_" + Build.MANUFACTURER + "-" + Build.MODEL
    }

    // Never throws: a failure is returned as Info(days = null, error = reason). Call from a background thread.
    fun fetch(ctx: Context, user: String, pass: String): Info {
        val body = "user=" + URLEncoder.encode(user, "UTF-8") +
            "&pass=" + URLEncoder.encode(pass, "UTF-8") +
            "&os=" + URLEncoder.encode("android", "UTF-8") +
            "&device=" + URLEncoder.encode(deviceKey(ctx), "UTF-8")
        val notes = ArrayList<String>()
        var best: Info? = null
        for (base in BASES) {
            val tag = base.substringBefore("://")
            try {
                val info = post("$base/index.php?APIKEY=$API_KEY&ACTION=AUTH", body) { ConnLog.log(ctx, "days $tag: $it") }
                if (info.days != null) {
                    prefs(ctx).edit().putString("cache_user", user).putInt("days", info.days)
                        .putString("remain_traffic", info.remainTraffic).apply()
                    return info
                }
                if (best == null) best = info
                notes.add("$tag: " + info.error.ifEmpty { "no remain_days" })
            } catch (e: Throwable) {
                val m = (e.message ?: e.javaClass.simpleName).take(80)
                ConnLog.log(ctx, "days $tag failed: $m")
                notes.add("$tag: $m")
            }
        }
        return best ?: Info(null, "", notes.joinToString(" | "))
    }

    private fun post(url: String, body: String, log: (String) -> Unit): Info {
        var target = url
        var hops = 0
        while (true) {
            val con = URL(target).openConnection() as HttpURLConnection
            con.connectTimeout = 8_000
            con.readTimeout = 10_000
            con.requestMethod = "POST"
            con.doOutput = true
            con.useCaches = false
            con.instanceFollowRedirects = false
            con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            con.setRequestProperty("Accept", "*/*")
            con.setRequestProperty("User-Agent", "Ktor client")
            try {
                con.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = con.responseCode
                if (code in 301..308 && code != 304 && hops < 3) {
                    val loc = con.getHeaderField("Location") ?: throw IOException("HTTP $code, no Location")
                    target = URL(URL(target), loc).toString()
                    hops++
                    log("redirect $code")
                    continue
                }
                val text = (if (code in 200..299) con.inputStream else con.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: ""
                log("HTTP $code, " + text.replace("\n", " ").take(160))
                val a = text.indexOf('{')
                val b = text.lastIndexOf('}')
                if (a < 0 || b <= a) throw IOException("HTTP $code, not JSON")
                val j = JSONObject(text.substring(a, b + 1))
                var days: Int? = null
                for (k in listOf("remain_days", "remainDays", "days")) {
                    val raw = j.opt(k)
                    days = when (raw) {
                        is Number -> raw.toInt()
                        is String -> Regex("-?\\d+").find(raw)?.value?.toIntOrNull()
                        else -> null
                    }
                    if (days != null) break
                }
                fun str(k: String): String = j.optString(k, "").trim().let { if (it == "null") "" else it }
                val err = str("ERRORTEXT").ifEmpty { str("STATUS") }
                return Info(days, str("exp_date"), err, true, str("remain_traffic"), str("total_traffic"))
            } finally {
                con.disconnect()
            }
        }
    }
}
