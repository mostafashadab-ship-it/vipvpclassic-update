package com.example.myvpn

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.sqrt
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

// Everything the monkey does runs at this fraction of real time (1 = the old, faster pace).
private const val TIME_SCALE = 0.63f   // v185: +5% faster than 0.60

/**
 * A little cartoon monkey that lives on top of the main screen while the VPN is NOT connected.
 * It wanders around, plays with the real buttons, kicks a ball, chases a butterfly, eats a banana,
 * dances, sleeps, swings from the top edge, peeks from the screen edge ... and picks a new random
 * thing every few seconds so it never gets boring. The user can tap it (it laughs) or drag it around.
 * When the VPN connects it waves goodbye and disappears with a little poof (the cheerful message
 * itself is the banner at the top of the screen, see MainActivity).
 *
 * v122: a new, classier look (a cool guy: gradient fur, swept quiff, red bow tie, sneakers), a lot more
 * things to say (flip offers, "I'm smart", "don't touch me, I'm sensitive"...), sometimes a rival monkey
 * drops in and the two wrestle on a button, a touch makes him pout and then dance, and tapping him
 * too fast makes him "die" (halo + ghost) before he pops back to life.
 *
 * The monkey never goes below [floorProvider] (the red line: top edge of the "hide servers" bar) and never
 * stands on the big connect button ([avoidProvider]): it walks on the strip above the button and in the free
 * columns on its left and right side, and goes round the top of the button when it wants to cross.
 *
 * The view covers the whole screen but only reacts to touches ON the monkey, everything else
 * passes through to the views underneath.
 */
class MonkeyView(context: Context) : View(context) {

    /** Language of the speech bubbles. */
    var fa: Boolean = true

    /** Real on-screen views the monkey may sit on and bounce on. */
    var targets: (() -> List<View>)? = null

    /** Views the monkey can hang from and swing on (the settings / update icons). */
    var hangers: (() -> List<View>)? = null

    /** Bottom of the play area in this view's coordinates (the monkey never goes below it). <= 0 means "whole screen". */
    var floorProvider: (() -> Float)? = null
    private var floorY = 0f

    /** The big connect button, in this view's coordinates (page not scrolled). The monkey never goes on it. null = nothing to avoid. */
    var avoidProvider: (() -> RectF?)? = null

    /** How far the page is scrolled (px). The monkey lives IN the page: everything is drawn shifted by this. */
    var scrollProvider: (() -> Int)? = null
    private fun scrollNow(): Float = try { (scrollProvider?.invoke() ?: 0).toFloat() } catch (_: Throwable) { 0f }

    /** Top of the "red zone" (feet position): the monkey walks only between this line and the floor line. */
    private var gTop = 0f
    private var avoidCache: RectF? = null

    private val d = resources.displayMetrics.density
    private val sc = d * 0.58f   // 1 local unit -> pixels (the monkey is about 63 dp tall)

    private enum class Act {
        ENTER, WALK, RUN, JUMP, CARTWHEEL, SCRATCH, EAT, DANCE, SLEEP, WAVE,
        SWING, BALL, BUTTERFLY, SIT, PEEK, CROSS, GOODBYE, DRAG, DROP, LAUGH,
        // ten extra tricks
        BACKFLIP, FLEX, MOONWALK, KUNGFU, JACKS, SPIN, SNEEZE, SNEAK, MEDITATE, HEADSPIN,
        // a rival monkey drops in and they wrestle, touch reactions, the "I'm a genius" pose
        BRAWL, TOUCHED, WOOZY, DIE, GENIUS,
        // he boxes the big connect button like a punching bag
        PUNCH,
        // v133: after connecting he stands beside the green banner and points at it
        SHOW,
        // v132: thrown by the finger, flies around and bounces off the walls / floor / the button
        THROWN
    }

    private class Pt(
        var x: Float, var y: Float, var vx: Float, var vy: Float,
        var life: Float, val max: Float, val txt: String, val size: Float
    )

    // ---------------- colours / skins ----------------
    /** Fur colours + pre-built gradients (local monkey coordinates, so they follow every pose). */
    private class Skin(
        val brown: Int, val dark: Int, val tan: Int, val light: Int, val tanDark: Int,
        val tie: Int, val tieDark: Int
    ) {
        val head: Shader = RadialGradient(
            -9f, -98f, 38f, intArrayOf(light, brown, dark), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        val body: Shader = RadialGradient(
            -6f, -58f, 36f, intArrayOf(light, brown, dark), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        val belly: Shader = RadialGradient(
            -2f, -52f, 22f, intArrayOf(0xFFFFF6E6.toInt(), tan, tanDark), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        val face: Shader = RadialGradient(
            -2f, -88f, 22f, intArrayOf(0xFFFFF8EC.toInt(), tan, tanDark), floatArrayOf(0f, 0.62f, 1f), Shader.TileMode.CLAMP
        )
    }

    // the hero: chocolate fur, red bow tie
    private val hero = Skin(
        0xFF8E5C37.toInt(), 0xFF5A361F.toInt(), 0xFFF9DEB8.toInt(), 0xFFC48A5A.toInt(),
        0xFFE7BC88.toInt(), 0xFFD32F2F.toInt(), 0xFF8E1B1B.toInt()
    )
    // the rival: golden fur, blue bow tie
    private val rival = Skin(
        0xFFC98A3C.toInt(), 0xFF8A551B.toInt(), 0xFFFFF0D2.toInt(), 0xFFEDB96B.toInt(),
        0xFFEBCB9A.toInt(), 0xFF1E88E5.toInt(), 0xFF0D47A1.toInt()
    )
    private var skin = hero
    private val cBrown: Int get() = skin.brown
    private val cDark: Int get() = skin.dark
    private val cTan: Int get() = skin.tan
    private val cInk = 0xFF2B1B14.toInt()

    // ---------------- paints ----------------
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val txtP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val path = Path()
    private val rc = RectF()

    // ---------------- overall state ----------------
    private var showing = false
    private var running = false
    private var pendingEnter = false
    private var lastT = 0L
    private var vw = 0f
    private var vh = 0f

    private var act = Act.ENTER
    private var sub = 0
    private var t = 0f
    private var subT = 0f
    private val recent = ArrayList<Act>()
    private var justLanded = false
    private var kicked = false

    // position of the feet (centre), height above the ground
    private var mx = 0f
    private var my = 0f
    private var hop = 0f
    private var hopV = 0f
    private var hopG = 1800f * d
    private var lift = 0f
    private var vx = 0f
    private var vy = 0f
    private var airMove = false
    private var facing = 1
    private var tx = 0f
    private var ty = 0f

    // pose (reset every frame, the current action fills it in)
    private var footA = 0f
    private var footB = 0f
    private var liftA = 0f
    private var liftB = 0f
    private var armA1 = 6f
    private var armA2 = 6f
    private var armLen2 = 26f
    private var tilt = 0f
    private var squash = 1f
    private var squashK = 0f
    private var mouth = 0f
    private var eyes = 0          // 0 open, 1 happy, 2 closed, 3 surprised
    private var lookX = 0f
    private var bob = 0f
    private var pivotY = -45f
    private var item = 0          // 1 = banana in the right hand
    private var eaten = 0f
    private var drawScale = 1f
    private var legPh = 0f
    private var tailT = 0f
    private var handX = 0f
    private var handY = 0f
    private var spinX = 1f          // 1 = facing the side, 0 = seen from the front/back (fake 3D spin)
    private var shades = false      // sunglasses
    private var aura = 0f           // golden glow (meditation)
    private var mwDir = 1           // moonwalk travel direction
    private var angry = false       // angry brows + frown

    // touch reactions: taps in quick succession are counted (too many = he "dies")
    private var tapCount = 0
    private var lastTapMs = 0L

    // trampoline show-off flips
    private var sitHopN = 0
    private var sitFlip = false
    private var sitFlightT = 0.5f
    private var sitHopStart = 0f

    /** Everything drawMonkey() needs for one monkey: used for the rival and for the hero while they wrestle. */
    private class Mk {
        var x = 0f; var y = 0f; var lift = 0f; var facing = 1
        var footA = 0f; var footB = 0f; var liftA = 0f; var liftB = 0f
        var armA1 = 6f; var armA2 = 6f; var armLen2 = 26f
        var tilt = 0f; var squash = 1f; var mouth = 0f; var eyes = 0; var bob = 0f
        var pivotY = -45f; var angry = false; var lookX = 0f; var spinX = 1f
        fun reset() {
            lift = 0f; footA = 0f; footB = 0f; liftA = 0f; liftB = 0f
            armA1 = 6f; armA2 = 6f; armLen2 = 26f
            tilt = 0f; squash = 1f; mouth = 0f; eyes = 0; bob = 0f
            pivotY = -45f; angry = false; lookX = 0f; spinX = 1f
        }
    }
    private val ma = Mk()      // the hero while the brawl script drives him
    private val mb = Mk()      // the rival
    private val sv = Mk()      // scratch copy used while drawing the rival
    private var buddyOn = false
    private var brView: View? = null
    private var brX = 0f
    private var brY = 0f
    private var brHalf = 30f
    private var brSpread = 30f   // half the distance between the two wrestlers when they start
    private var brSide = -1        // the side the rival comes from: -1 left, 1 right
    private var brWinner = 0       // 0 = hero wins, 1 = rival wins
    private var brLine = 0
    private var rivalStartX = 0f
    private var brCloud = 0f
    private var brTheta = 0f
    private var brCx = 0f
    private var brCy = 0f
    private var bub2: String? = null
    private var bub2T = 0f
    private var bub2Dur = 2f

    // forbidden zone: the connect button (+ the monkey's half width) and everything below its top edge
    private var wall: RectF? = null
    private val tmp = FloatArray(2)
    private var lb0 = 0f
    private var lb1 = 1f
    private var pendingWait = 0f

    private var blinkIn = 2f
    private var blinkOn = 0f

    // speech
    private var bubbleText: String? = null
    private var bubbleT = 0f
    private var bubbleDur = 2.4f
    // Dialogue may queue only inside the current action; begin() clears it on every transition.
    private val speechQueue = ArrayDeque<Pair<String, Float>>()
    // Idle chatter lives only inside the calm walk along the red line (see the WALK branch of step()):
    // he walks, stops where he is, says one line, then walks on to the end of the line and turns back.
    private var walkChatT = 3f      // seconds of walking left before the next line
    private var talkT = 0f          // > 0 while he stands still and says a line
    private var walkLegs = 0        // how many times in a row he has already turned round at an end of the line

    // particles
    private val pts = ArrayList<Pt>()
    private var noteT = 0f
    private var zT = 0f

    // flip in a jump, swing / sit data
    private var flip = false
    private var swHx = 0f
    private var swView: View? = null
    private val swList = ArrayList<View>()   // the corner buttons (settings / update) he hangs from, in order
    private var swIdx = 0
    private var pullK = -1
    private var swMode = 0   // v186: 0 = middle bar then connect button (no shake), 1 = Settings / Update icons then connect button (shakes)
    private var crossRight = true
    private var swY0 = 0f
    private var swX0 = 0f
    private var dropX = 0f

    // punching bag (the big connect button swings while he boxes it)
    private var bagView: View? = null
    private var bagA = 0f          // swing angle in degrees
    private var bagW = 0f          // angular speed
    private var punchSide = 0      // 0 = he stands left of the button, 1 = right of it
    private var punchK = -1
    private var bfCool = 0f
    private var hangY = 0f
    private var dropY = 0f
    private var fallV = 0f
    private var sitView: View? = null
    private var pendingSit: View? = null
    private var sitOx = 0f
    private var sitHopT = 0f
    private var peekLeft = true
    private var peekY = 0f
    private var hideX = 0f
    private var shownX = 0f
    private var cwDir = 1
    private var cwDist = 0f

    // ball
    private var ballOn = false
    private var bx = 0f
    private var by = 0f
    private var bz = 0f
    private var bvx = 0f
    private var bvy = 0f
    private var bvz = 0f
    private var kicks = 0
    private var ballFlying = false   // the kicked ball flies over the connect button
    private var ballSkyShot = false  // final shot exits the top of the screen and never falls back
    private var ballDir = 1
    private var juggled = false     // v135: he juggles the ball once (keepy-uppy) before he shoots
    private var juggleN = 0

    // butterfly
    private var bfOn = false
    private var bfLeaving = false
    private var bfx = 0f
    private var bfy = 0f
    private var bcx = 0f
    private var bcy = 0f
    private var bfVx = 0f
    private var bfVy = 0f
    private var bt = 0f
    private var bfNext = 1.5f
    private var bfFast = 0f        // > 0: the butterfly darts away quickly (he just tried to grab it)
    private var bfDodgeT = -1f     // > 0: he jumped, the butterfly dodges when this runs out
    private var bfMiss = 0
    private var hopT = 1.4f
    private var bfCaught = false   // v132: the butterfly landed between his raised hands

    // v132: sliding down the big round button after the swing, party mode after connecting, being thrown
    private var slideCx = 0f
    private var slideCy = 0f
    private var slideR = 1f
    private var slideSide = 1
    private var slideTh = 0f
    private var slideThV = 0f
    private var slideLandX = 0f
    private var slideT = 0f
    private var party = false
    private var tvx = 0f
    private var tvy = 0f
    private var tAng = 0f
    private var tSpin = 0f
    private var banRot = 0f
    private var lastMoveMs = 0L
    private var lastMoveX = 0f
    private var lastMoveY = 0f
    private var fingVx = 0f
    private var fingVy = 0f
    private var eatK = -1
    /** v133: the green connected banner of the top bar, in page coordinates (null while it is hidden). */
    var bannerProvider: (() -> RectF?)? = null
    private var showX = 0f
    private var showY = 0f
    private var showFace = 1
    private var showHave = false
    private var byeScale = 1f

    // touch
    private var dragging = false
    private var moved = false
    private var downX = 0f
    private var downY = 0f
    private var grabDx = 0f
    private var grabDy = 0f

    // ---------------- speech lines ----------------
    // Idle chatter said while he walks along the red line (nothing else uses this deck).
    private val walkChatDeck by lazy { Deck(listOf(
        "کی فیلترشکن رو روشن می‌کنی؟ 🐵" to "When are you turning the VPN on? 🐵",
        "هنوز وصل نشدی؟ 👀" to "Still not connected? 👀",
        "من بهترین میمون دنیام! 🏆" to "I'm the best monkey in the world! 🏆",
        "امروز حسابی سرحالم! ✨" to "I'm full of energy today! ✨",
        "چه دنیای قشنگیه! 🌟" to "What a lovely world! 🌟",
        "حوصلم سر رفت، فیلترشکن رو روشن کن! 😩" to "I'm bored, turn the VPN on! 😩",
        "من اینجا منتظرتم تا وصل بشی! ⏳" to "I'm waiting here until you connect! ⏳",
        "داری بهم نگاه می‌کنی؟ 😎" to "Are you watching me? 😎",
        "یه کم قدم بزنم، پاهام خشک شد! 🚶" to "Let me stretch my legs a bit! 🚶"
    )) }
    // on the trampoline (the connect button): not only "trampoline"
    private val jumpLines = listOf(
        "ببین چقدر فرزم! 🚀" to "Look how agile I am! 🚀",
        "من یه پسر ورزشکارم 💪" to "I'm a sporty guy 💪",
        "دوباره بپرم؟ 😄" to "Jump again? 😄",
        "تو هم بیا بپر! 🕺" to "Come and jump with me! 🕺",
        "من بهترین میمون دنیام! 🏆" to "I'm the best monkey in the world! 🏆"
    )
    private val flipLines = listOf(
        "پشتک! 🤸 خوشت اومد؟" to "Flip! 🤸 Did you like it?",
        "ببین، پشتک می‌زنم برات! 🤸" to "Watch, a flip just for you! 🤸",
        "یه پشتک حسابی! 😎" to "A proper flip! 😎"
    )
    private val smartLines = listOf(
        "حل شد: ۲+۲=۴ ✅" to "Solved: 2+2=4 ✅",
        "من یه میمون نابغه‌ام 🧠✨" to "I'm a genius monkey 🧠✨"
    )
    // touch: first he is offended, then he dances anyway
    private val touchedLines = listOf(
        "به من دست نزن! من حساسم 😤" to "Don't touch me! I'm sensitive 😤",
        "آی! من خیلی حساسم! 🥺" to "Ouch! I'm very sensitive! 🥺",
        "هی، دست نزن! من حساسم! 😣" to "Hey, hands off! I'm sensitive! 😣"
    )
    private val danceLines = listOf(
        "حالا که دست زدی... برقصم برات! 💃" to "Fine, since you touched me... I'll dance for you! 💃",
        "بذار برات برقصم 🎶" to "Let me dance for you 🎶",
        "ببین چه رقصی بلدم! 🕺" to "Look at these moves! 🕺"
    )
    private val warnLines = listOf(
        "یواش‌تر! دارم حالم بد می‌شه 😵" to "Slow down! I'm getting dizzy 😵",
        "نزن دیگه! دارم می‌میرم! 😰" to "Stop! I'm dying! 😰",
        "تند نزن ها! ⚠️" to "Don't tap so fast! ⚠️"
    )
    private val dieLines = listOf(
        "خداحافظ دنیای بی‌وفا... 💀" to "Goodbye cruel world... 💀",
        "گفتم تند نزن... آخخخ 💀" to "I told you not to tap so fast... argh 💀"
    )
    private val reviveLines = listOf(
        "هاااا؟ زنده شدم! 😮 دیگه تند بهم دست نزن!" to "Huh? I'm alive! 😮 Don't tap me so fast again!",
        "شوخی کردم، گول خوردی! 😜" to "Just kidding, you fell for it! 😜"
    )
    // wrestling: every line comes from a shuffled "deck", so each fight sounds different
    // (a line never repeats until the whole deck has been used, and never twice in a row).
    private class Deck<T>(private val items: List<T>) {
        private val q = ArrayList<T>()
        private var last: T? = null
        fun next(): T {
            if (q.isEmpty()) {
                val l = items.shuffled().toMutableList()
                if (l.size > 1 && l[0] == last) l.add(l.removeAt(0))
                q.addAll(l)
            }
            val v = q.removeAt(0)
            last = v
            return v
        }
    }

    private val dkWarm = Deck(listOf(
        "برم گرم کنم! 💪" to "Time to warm up! 💪",
        "یه کم بدنسازی کنم! 🏋️" to "A little workout first! 🏋️",
        "باید آماده باشم! 🔥" to "I have to be ready! 🔥",
        "دارم برای مبارزه آماده می‌شم! 🥊" to "Getting ready for a fight! 🥊",
        "عضله‌هام کشیده شدن، یه کم نرمش! 🤸" to "Stretching these muscles! 🤸"
    ))
    // taunts when they fight on a button
    private val dkTauntHero = Deck(listOf(
        "این دکمه مال منه! 😠" to "This button is mine! 😠",
        "از رو دکمه من برو کنار! 😡" to "Get off my button! 😡",
        "من اول اومدم، دکمه مال منه! 😤" to "I came first, the button is mine! 😤"
    ))
    private val dkTauntRival = Deck(listOf(
        "نخیر، مال منه! 😤" to "No way, it's mine! 😤",
        "تو برو کنار، من قوی‌ترم! 💪" to "You move, I'm stronger! 💪",
        "خودت گم شو! 🙄" to "You get lost! 🙄"
    ))
    // no button around (they fight on the floor): the taunts must not talk about a button
    private val dkTauntHeroFloor = Deck(listOf(
        "این‌جا مال منه! 😠" to "This spot is mine! 😠",
        "برو اون ور، این‌جا قلمرو منه! 🚫" to "Go away, this is my territory! 🚫",
        "من این‌جا زودتر اومدم! 😤" to "I was here first! 😤",
        "جات این‌جا نیست، گم شو! 😡" to "You don't belong here, scram! 😡",
        "این گوشه مال منه، بکش کنار! 👉" to "This corner is mine, move over! 👉",
        "اینجا قلمروی منه! 🦍" to "This is my turf! 🦍"
    ))
    private val dkTauntRivalFloor = Deck(listOf(
        "نخیر، مال منه! 😤" to "No way, it's mine! 😤",
        "تو برو کنار، من قوی‌ترم! 💪" to "You move, I'm stronger! 💪",
        "خودت گم شو! 🙄" to "You get lost! 🙄",
        "من اول بودم، تو بکش کنار! 😠" to "I was first, you step aside! 😠",
        "قلمرو تو نیست، مال هممونه! 😡" to "It's nobody's turf, it's for everyone! 😡",
        "بیا جلو ببینم چی داری! 🥊" to "Come on, show me what you've got! 🥊"
    ))
    private val dkStart = Deck(listOf(
        "بیا کشتی بگیریم! 🤼" to "Let's wrestle! 🤼",
        "امروز روز منه! 💪" to "Today is my day! 💪",
        "آماده‌ای ببازی؟ 😏" to "Ready to lose? 😏",
        "بیا ببینم چی داری! 🥊" to "Show me what you've got! 🥊",
        "خودتو آماده کن! 🔥" to "Brace yourself! 🔥",
        "یه حرکت نشونت بدم! 🤼" to "Let me show you a move! 🤼"
    ))
    private val dkFightHero = Deck(listOf(
        "من خیلی باهوشم، می‌برم! 🧠" to "I'm way smarter, I'll win! 🧠",
        "این یکی رو بگیر! 💥" to "Take this one! 💥",
        "تسلیم شو! 🏳️" to "Give up! 🏳️",
        "حرکت مخصوص منه! 🌀" to "My special move! 🌀",
        "ضعیفی تو، ضعیف! 😝" to "You're weak, weak! 😝",
        "با موز می‌زنمت‌ها! 🍌" to "I'll hit you with a banana! 🍌",
        "اووو اووو آآآ! 🦍" to "Ooh ooh aah aah! 🦍",
        "من قهرمان جنگلم! 👑" to "I'm the jungle champion! 👑",
        "نمی‌ذارم ببری! 😤" to "I won't let you win! 😤",
        "سه دور دیگه بریم! 🥊" to "Three more rounds! 🥊"
    ))
    private val dkFightRival = Deck(listOf(
        "آخ! دستمو کندی! 😖" to "Ouch! You'll break my arm! 😖",
        "ولم کن! 😤" to "Let go! 😤",
        "من قوی‌ترم! 💪" to "I'm stronger! 💪",
        "دمم! دمم رو نکش! 😫" to "My tail! Don't pull my tail! 😫",
        "یه روز انتقامم رو می‌گیرم! 😠" to "I'll get my revenge one day! 😠",
        "کمرم! آخ کمرم! 🤕" to "My back! Ouch, my back! 🤕",
        "تقلب نکن! 😡" to "No cheating! 😡",
        "هنوز تموم نشده! 🔥" to "It's not over yet! 🔥",
        "بذار نفس بکشم! 😩" to "Let me breathe! 😩",
        "این‌جا جای منه! 💢" to "This is my place! 💢"
    ))
    private val dkWin = Deck(listOf(
        "من بردم! 🏆" to "I won! 🏆",
        "بردم بردم! 🎉" to "I won, I won! 🎉",
        "من قهرمانم! 👑" to "I'm the champion! 👑",
        "ایول، آسون بود! 😎" to "Yeah, that was easy! 😎",
        "گفتم که می‌برم! 😏" to "Told you I'd win! 😏"
    ))
    private val dkLose = Deck(listOf(
        "اوووف... 😵" to "Ouch... 😵",
        "آخ کمرم... 🤕" to "Ouch, my back... 🤕",
        "دفعه‌ی بعد می‌برم... 😩" to "Next time I'll win... 😩",
        "سرم گیج می‌ره... 💫" to "My head is spinning... 💫",
        "خوب بود ولی... 😵" to "Not bad, but... 😵"
    ))
    private val dkPeaceA = Deck(listOf(
        "آشتی؟ 🤝" to "Friends? 🤝",
        "بیا دیگه قهر نباشیم 🤝" to "Let's not be mad anymore 🤝",
        "دستتو بده، آشتی! 😄" to "Give me your hand, peace! 😄",
        "خوب جنگیدی! 👏" to "You fought well! 👏"
    ))
    private val dkPeaceB = Deck(listOf(
        "باشه، آشتی! 😅" to "Okay, friends! 😅",
        "باشه، ولی دفعه‌ی بعد من می‌برم! 😤" to "Okay, but next time I win! 😤",
        "قبوله، دوست شدیم! 🤗" to "Deal, we're friends! 🤗",
        "باشه بابا، آشتی! 😌" to "Fine, fine, peace! 😌"
    ))
    private val dkBye = Deck(listOf(
        "بای بای! 👋" to "Bye bye! 👋",
        "فعلاً! تا دفعه‌ی بعد! 👋" to "See you next time! 👋",
        "خداحافظ رفیق! 🐒" to "Goodbye, buddy! 🐒",
        "دوباره بیا! 👋" to "Come again! 👋",
        "بدرود! ✌️" to "Farewell! ✌️"
    ))
    private val tickle = listOf(
        "هاهاها قلقلکم میاد! 😂" to "Hehe, that tickles! 😂",
        "ایییی! نکن! 🤭" to "Eeek! Stop! 🤭",
        "دوباره بزن! 😆" to "Do it again! 😆",
        "اوو اوو! خوشم اومد 💖" to "Ooh ooh! I like it 💖"
    )

    // ---------------- helpers ----------------
    private fun rnd(a: Float, b: Float) = a + Random.nextFloat() * (b - a)
    private fun minY() = 96f * d
    private fun maxY(): Float {
        val f = if (floorY > 0f) floorY else vh - 10f * d
        return max(f, minY() + 20f * d)
    }
    /** A point inside the play area: 0 = top, 1 = bottom. */
    private fun ay(f: Float) = gTop + (maxY() - gTop) * f
    private fun updateFloor() {
        val f = try { floorProvider?.invoke() } catch (_: Throwable) { null }
        floorY = if (f != null && f > 0f) min(f, vh - 10f * d) else 0f
        var r = try { avoidProvider?.invoke() } catch (_: Throwable) { null }
        // while he boxes the button it swings: keep the resting position so the forbidden zone does not wobble
        if ((act == Act.PUNCH || (act == Act.SWING && bagView != null)) && avoidCache != null) r = avoidCache
        else if (r != null) avoidCache = RectF(r)
        if (r == null || r.width() <= 0f || r.height() <= 0f) {
            wall = null
        } else {
            val hw = 36f * sc   // half the width of the monkey (arms included)
            val w = wall ?: RectF().also { wall = it }
            w.set(r.left - hw, max(r.top - 2f * d, minY()), r.right + hw, r.bottom + 8f * d)
        }
        // v150: anchor every autonomous action to the red baseline (top edge of hide-servers bar).
        // maxY() resolves to floorProvider's measured baseline; jump height is animated separately.
        gTop = maxY()
    }

    // ---------------- forbidden zone ----------------
    /** True when a monkey standing at (x, y) would be on the connect button. */
    private fun inWall(x: Float, y: Float): Boolean {
        val w = wall ?: return false
        return x > w.left && x < w.right && y > w.top && y < w.bottom
    }

    /** Moves a feet position out of the forbidden zone (to the nearest free spot); the result is left in [tmp]. */
    private fun push(px: Float, py: Float) {
        var x = px
        var y = py
        val w = wall
        if (w != null && x > w.left && x < w.right && y > w.top && y < w.bottom) {
            var best = y - w.top
            var bx = x
            var by = w.top
            if (w.left >= marginX() && x - w.left < best) {
                best = x - w.left
                bx = w.left
                by = y
            }
            if (w.right <= vw - marginX() && w.right - x < best) {
                bx = w.right
                by = y
            }
            x = bx
            y = by
        }
        tmp[0] = x
        tmp[1] = y
    }

    private fun clipT(p: Float, q: Float): Boolean {
        if (p == 0f) return q >= 0f
        val r = q / p
        if (p < 0f) {
            if (r > lb1) return false
            if (r > lb0) lb0 = r
        } else {
            if (r < lb0) return false
            if (r < lb1) lb1 = r
        }
        return true
    }

    /** Does the straight line (x0,y0)->(x1,y1) go through the forbidden zone? */
    private fun segHitsWall(x0: Float, y0: Float, x1: Float, y1: Float): Boolean {
        val w = wall ?: return false
        val dx = x1 - x0
        val dy = y1 - y0
        lb0 = 0f
        lb1 = 1f
        if (!clipT(-dx, x0 - (w.left + 0.5f))) return false
        if (!clipT(dx, (w.right - 0.5f) - x0)) return false
        if (!clipT(-dy, y0 - (w.top + 0.5f))) return false
        if (!clipT(dy, (w.bottom - 0.5f) - y0)) return false
        return lb0 < lb1 - 0.001f
    }

    /** How far the monkey may run sideways (dir = 1 right, -1 left) before the screen edge / the button. */
    private fun freeRun(dir: Int): Float {
        val w = wall
        var lim = if (dir > 0) vw - marginX() - mx else mx - marginX()
        if (w != null && my > w.top && my < w.bottom) {
            if (dir > 0 && mx <= w.left) lim = min(lim, w.left - mx)
            if (dir < 0 && mx >= w.right) lim = min(lim, mx - w.right)
        }
        return max(0f, lim)
    }

    /** Jump target for the JUMP action: free of the button and reachable without crossing it. */
    private fun fitJump() {
        var tries = 0
        while (tries < 12) {
            push(tx, ty)
            if (!segHitsWall(mx, my, tmp[0], tmp[1])) break
            tx = clampX(mx + rnd(-140f, 140f) * d)
            ty = clampY(my + rnd(-90f, 90f) * d)
            tries++
        }
        push(tx, ty)
        if (segHitsWall(mx, my, tmp[0], tmp[1])) {
            tmp[0] = mx
            tmp[1] = my
        }
        tx = tmp[0]
        ty = tmp[1]
    }

    /** side: +1 = right half of the screen, -1 = left half. Default: the half where the monkey is NOT, so he has to run across. */
    private fun pickButterflySpot(side: Int = if (mx < vw / 2f) 1 else -1) {
        var tries = 0
        val lo0 = if (side > 0) vw / 2f + 10f * d else marginX()
        val hi0 = if (side > 0) vw - marginX() else vw / 2f - 10f * d
        do {
            bcx = rnd(lo0, max(hi0, lo0 + 1f))
            // always clearly ABOVE his head, and never close to him: it keeps away from him
            // v135: low, close to the red line (just inside the reach of his jump)
            val hi = maxY() - 134f * sc - 10f * d
            val lo = hi - 26f * d
            bcy = rnd(lo, hi)
            tries++
        } while (abs(bcx - mx) < 130f * d && tries < 30)
    }
    private fun marginX() = min(28f * d, vw / 4f)
    private fun clampX(v: Float) = v.coerceIn(marginX(), max(vw - marginX(), marginX()))
    private fun clampY(v: Float) = v.coerceIn(gTop, maxY())

    /** x limited to the free column he is standing in (so he never has to walk over the button). */
    private fun colClampX(x: Float): Float {
        val w = wall ?: return clampX(x)
        if (my <= w.top || my >= w.bottom) return clampX(x)
        return when {
            mx <= w.left && w.left > marginX() + 2f * d -> x.coerceIn(marginX(), w.left)
            mx >= w.right && w.right < vw - marginX() - 2f * d -> x.coerceIn(w.right, vw - marginX())
            else -> clampX(x)
        }
    }

    private fun pickBagView(): View? {
        val list = (try { targets?.invoke() } catch (_: Throwable) { null }) ?: return null
        return list.firstOrNull { it.isShown && it.width > 0 && it.height > 0 }
    }

    private fun bagReset() {
        val v = bagView
        if (v != null) {
            try {
                v.rotation = 0f
                v.pivotX = v.width / 2f
                v.pivotY = v.height / 2f
            } catch (_: Throwable) {
            }
        }
        bagView = null
        bagA = 0f
        bagW = 0f
    }

    private fun updateBag(dt: Float) {
        val v = bagView ?: return
        // a heavy bag hanging from its top edge: spring + damping
        // v185: stiffer spring, more damping and a smaller maximum angle: the button wobbles much less
        bagW += (-130f * bagA - 2.8f * bagW) * dt
        bagA = (bagA + bagW * dt).coerceIn(-5f, 5f)
        try {
            v.pivotX = v.width / 2f
            v.pivotY = 0f
            v.rotation = bagA
        } catch (_: Throwable) {
        }
        if (act != Act.PUNCH && abs(bagA) < 0.2f && abs(bagW) < 3f) bagReset()
    }

    /** Which free column a ground position is in: 0 = left of the button, 1 = right of it, -1 = no button / on top of it. */
    private fun sideOf(x: Float): Int {
        val w = wall ?: return -1
        return when {
            x <= w.left -> 0
            x >= w.right -> 1
            else -> -1
        }
    }

    private fun say(text: String, dur: Float = 2.4f) {
        // Ordinary chatter may queue briefly, but action-critical lines use sayNow().
        if (party && (act == Act.SWING || ((act == Act.WALK || act == Act.RUN) && my < gTop - 6f * d))) return
        val d2 = readTime(text, dur)
        if (bubbleT > 0f) {
            if (speechQueue.size < 2 && speechQueue.lastOrNull()?.first != text) {
                speechQueue.addLast(Pair(text, d2))
            }
        } else {
            bubbleText = text
            bubbleDur = d2
            bubbleT = d2
        }
    }

    /** Immediately replaces stale speech when an important visual event actually happens. */
    private fun sayNow(text: String, dur: Float = 1.45f) {
        if (party && act == Act.SWING) return
        speechQueue.clear()
        val d2 = dur.coerceIn(1.1f, 1.65f)
        bubbleText = text
        bubbleDur = d2
        bubbleT = d2
    }

    /** Compact reading time: enough to read one line, without letting dialogue lag behind the animation. */
    private fun readTime(text: String, dur: Float): Float = max(dur, 1.35f + text.length * 0.035f).coerceIn(1.45f, 2.8f)

    private fun say(p: Pair<String, String>, dur: Float = 2.4f): Unit = say(if (fa) p.first else p.second, dur)

    private fun spawn(txt: String, x: Float, y: Float, vx: Float, vy: Float, life: Float, size: Float) {
        pts.add(Pt(x, y, vx, vy, life, life, txt, size))
    }

    private fun spawnPoof() {
        for (i in 0 until 7) {
            spawn(
                if (i % 2 == 0) "💨" else "✨",
                mx + rnd(-18f, 18f) * d, my - 40f * d + rnd(-18f, 18f) * d,
                rnd(-60f, 60f) * d, rnd(-70f, 20f) * d, 0.9f, rnd(14f, 22f) * d
            )
        }
    }

    private fun spawnHearts(n: Int) {
        for (i in 0 until n) {
            spawn(
                "💖", mx + rnd(-16f, 16f) * d, my - 70f * d,
                rnd(-25f, 25f) * d, rnd(-70f, -40f) * d, 1.3f, rnd(14f, 20f) * d
            )
        }
    }

    private fun setSub(n: Int) {
        sub = n
        subT = 0f
        kicked = false
    }

    /** Length of the way from (ax, ay) to the target, going over the top of the button if needed (MAX_VALUE = no way). */
    private fun wayLen(ax: Float, ay: Float, px: Float, py: Float): Float {
        val w = wall ?: return hypot(px - ax, py - ay)
        if (!segHitsWall(ax, ay, px, py)) return hypot(px - ax, py - ay)
        var best = Float.MAX_VALUE
        for (i in 0..1) {
            val cx = if (i == 0) w.left else w.right
            val cy = w.top
            if (!segHitsWall(ax, ay, cx, cy) && !segHitsWall(cx, cy, px, py)) {
                best = min(best, hypot(cx - ax, cy - ay) + hypot(px - cx, py - cy))
            }
        }
        return best
    }

    private fun moveToward(px0: Float, py0: Float, speed: Float, dt: Float): Boolean {
        // Slightly livelier travel without making the animation itself frantic.
        val tunedSpeed = speed * 1.10f
        // v135: playing ball / chasing the butterfly he runs straight across the connect button (no detour)
        val ghost = act == Act.BALL || act == Act.BUTTERFLY
        if (ghost) {
            tmp[0] = px0
            tmp[1] = py0
        } else push(px0, py0)
        val px = tmp[0]
        val py = tmp[1]
        var gx = px
        var gy = py
        val w = if (ghost) null else wall
        if (w != null && segHitsWall(mx, my, px, py)) {
            // the straight way is blocked by the connect button: go round over the top of it
            var best = Float.MAX_VALUE
            for (i in 0..1) {
                val cx = if (i == 0) w.left else w.right
                val cy = w.top
                if (hypot(cx - mx, cy - my) < 2f) continue
                if (segHitsWall(mx, my, cx, cy)) continue
                val rest = wayLen(cx, cy, px, py)
                if (rest == Float.MAX_VALUE) continue
                val total = hypot(cx - mx, cy - my) + rest
                if (total < best) {
                    best = total
                    gx = cx
                    gy = cy
                }
            }
        }
        val dx = gx - mx
        val dy = gy - my
        val dist = hypot(dx, dy)
        if (abs(dx) > 3f) facing = if (dx >= 0f) 1 else -1
        val stepLen = if (talkT > 0f && act == Act.WALK) 0f else tunedSpeed * dt
        if (dist <= stepLen) {
            mx = gx
            my = gy
            return gx == px && gy == py
        }
        mx += dx / dist * stepLen
        my += dy / dist * stepLen
        return false
    }

    /** Parabolic jump to a point: flight time [time] seconds, [peak] pixels high. */
    private fun launch(px: Float, py: Float, time: Float, peak: Float) {
        vx = (px - mx) / time
        vy = (py - my) / time
        hopG = 8f * peak / (time * time)
        hopV = hopG * time / 2f
        airMove = true
        if (abs(px - mx) > 3f) facing = if (px >= mx) 1 else -1
    }

    private fun cycle(dt: Float, rate: Float, amp: Float) {
        legPh += dt * rate
        val s = sin(legPh)
        val c = cos(legPh)
        footA = s * 12f * amp
        footB = -footA
        liftA = max(0f, c) * 6f * amp
        liftB = max(0f, -c) * 6f * amp
        armA1 = 5f + s * 32f * amp
        armA2 = 5f - s * 32f * amp
        bob = abs(s) * 3f * amp
    }

    private fun pickTarget(minDist: Float) {
        // v150: keep the whole sprite inside the screen, not just its centre.
        val edge = max(marginX(), 44f * d)
        var lo = edge
        var hi = max(edge + 1f, vw - edge)
        val w0 = wall
        if (w0 != null && my >= w0.top - 2f * d) {
            val leftHi = w0.left - 24f * d
            val rightLo = w0.right + 24f * d
            if (mx <= w0.left) hi = min(hi, leftHi)
            else if (mx >= w0.right) lo = max(lo, rightLo)
        }
        // If a narrow layout leaves too little room in this column, choose the
        // widest safe column rather than pushing a target onto the button edge.
        if (hi - lo < 32f * d) {
            val leftHi = if (w0 != null) w0.left - 24f * d else edge
            val rightLo = if (w0 != null) w0.right + 24f * d else vw - edge
            val leftWidth = leftHi - edge
            val rightWidth = vw - edge - rightLo
            if (leftWidth >= rightWidth && leftWidth >= 24f * d) {
                lo = edge; hi = leftHi
            } else if (rightWidth >= 24f * d) {
                lo = rightLo; hi = vw - edge
            } else {
                lo = edge; hi = vw - edge
            }
        }
        val turnGap = max(22f * d, minDist * 0.25f)
        val atLeft = mx <= lo + turnGap
        val atRight = mx >= hi - turnGap
        if ((patrolDir < 0 && atLeft) || (patrolDir > 0 && atRight)) patrolDir = -patrolDir
        var target = if (patrolDir > 0) hi else lo
        if (abs(target - mx) < 18f * d) {
            patrolDir = -patrolDir
            target = if (patrolDir > 0) hi else lo
        }
        tx = target.coerceIn(edge, max(edge, vw - edge))
        ty = maxY()
    }

    // ---------------- real views the monkey can play with ----------------
    /** The view's rectangle in the monkey's coordinates = page coordinates (as if the page were not scrolled). */
    private fun rectOf(v: View): RectF? {
        if (!v.isShown) return null
        if (v.width < 48f * d || v.height <= 0) return null
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        val ml = IntArray(2)
        getLocationOnScreen(ml)
        val l = (loc[0] - ml[0]).toFloat()
        val t = (loc[1] - ml[1]).toFloat() + scrollNow()
        return RectF(l, t, l + v.width, t + v.height)
    }

    private fun pickSitView(): View? {
        val list = (try { targets?.invoke() } catch (_: Throwable) { null }) ?: return null
        val ok = list.filter { v ->
            val r = rectOf(v)
            r != null && r.top > 92f * d && r.top < maxY() && !inWall(r.centerX(), r.top - 4f * d)
        }
        return if (ok.isEmpty()) null else ok.random()
    }

    private fun poke(v: View) {
        try {
            v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).withEndAction {
                v.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
            }.start()
        } catch (_: Throwable) {
        }
    }

    // ---------------- public API ----------------
    fun appear() {
        if (party) doneRound.clear()
        party = false
        if (showing && act == Act.GOODBYE) showing = false   // he was just leaving: he comes back in
        if (showing) {
            if (act == Act.SHOW) begin(Act.WALK)               // disconnected while he stood beside the banner: he plays again
            if (!running) startLoop()
            return
        }
        showing = true
        resetAll()
        updateFloor()
        if (vw > 0f) begin(Act.ENTER) else pendingEnter = true
        startLoop()
    }

    /**
     * v132: the VPN is connected: the monkey stays and celebrates (dancing, flips, confetti) instead of
     * vanishing. Safe to call again and again while connected.
     */
    fun celebrate() {
        if (party) return   // v135: once per connection (he leaves when the banner is gone and does not come back)
        party = true
        talkT = 0f
        doneRound.clear()
        if (!showing) {
            showing = true
            resetAll()
            updateFloor()
            if (vw > 0f) begin(Act.ENTER) else pendingEnter = true
            chain.clear()
            chain.add(Act.SHOW)
            startLoop()
        } else {
            // stop whatever he was doing and go up to the green banner
            ballOn = false
            bfOn = false
            bfCaught = false
            buddyOn = false
            swView = null
            bagReset()
            chain.clear()
            dragging = false
            bubbleT = 0f
            bub2T = 0f
            hopV = 0f
            lift = 0f
            airMove = false
            hopG = 1800f * d
            val fromY = my
            my = clampY(my)
            push(mx, my)
            mx = tmp[0]
            my = tmp[1]
            begin(Act.SHOW)
            hop = max(0f, my - fromY)
            if (!running) startLoop()
        }
        val em = arrayOf("🎉", "🎊", "✨", "⭐", "🎈")
        for (i in 0 until 16) {
            spawn(
                em[i % em.size], rnd(0.05f, 0.95f) * vw, rnd(minY(), max(minY() + 1f, my - 130f * d)),
                rnd(-30f, 30f) * d, rnd(60f, 140f) * d, 2.4f, rnd(16f, 24f) * d
            )
        }
    }

    /** v135: the app was opened while already connected: no monkey at all (and no celebration). */
    fun stayAway() {
        if (party) return
        party = true
        if (showing) {
            showing = false
            pendingEnter = false
            ballOn = false
            bfOn = false
            buddyOn = false
            bagReset()
            chain.clear()
            bubbleT = 0f
            bub2T = 0f
            dragging = false
            invalidate()
        }
    }

    /** The VPN is connected: the monkey is gone at once (only the banner at the top stays). */
    fun disappear() {
        party = false
        if (!showing) return
        showing = false
        pendingEnter = false
        ballOn = false
        bfOn = false
        buddyOn = false
        bagReset()
        chain.clear()
        bubbleText = null
        bubbleT = 0f
        bub2T = 0f
        dragging = false
        invalidate()
    }

    fun pause() {
        bagReset()
        running = false
        removeCallbacks(tick)
        if (showing && act == Act.GOODBYE) {
            showing = false
            invalidate()
        }
    }

    fun resume() {
        if (showing && !running) startLoop()
    }

    private fun resetAll() {
        drawScale = 1f
        hop = 0f
        hopV = 0f
        lift = 0f
        airMove = false
        squashK = 0f
        pts.clear()
        bubbleText = null
        bubbleT = 0f
        ballOn = false
        bfOn = false
        recent.clear()
        doneRound.clear()
        lastMove = null
        floorTrip = false
        pendingWait = 0f
        buddyOn = false
        brCloud = 0f
        bub2T = 0f
        tapCount = 0
        walkChatT = rnd(3f, 5f)
        talkT = 0f
        walkLegs = 0
        blinkIn = rnd(1.5f, 3.5f)
        blinkOn = 0f
        dragging = false
    }

    private fun startLoop() {
        if (running) return
        running = true
        lastT = SystemClock.uptimeMillis()
        postOnAnimation(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val now = SystemClock.uptimeMillis()
            val dt = ((now - lastT) / 1000f).coerceIn(0f, 0.05f)
            lastT = now
            if (vw > 0f && showing && pendingEnter) {
                // wait (at most a second) until the layout is done so we know where the connect button is
                updateFloor()
                pendingWait += dt
                if (wall != null || avoidProvider == null || pendingWait > 1f) {
                    pendingEnter = false
                    pendingWait = 0f
                    begin(Act.ENTER)
                }
            }
            if (vw > 0f && showing && !pendingEnter) step(dt * TIME_SCALE)
            invalidate()
            if (showing) postOnAnimation(this) else running = false
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        vw = w.toFloat()
        vh = h.toFloat()
        if (!pendingEnter && showing && act != Act.PEEK && act != Act.SWING && act != Act.CROSS) {
            updateFloor()
            mx = clampX(mx)
            my = clampY(my)
            push(mx, my)
            mx = tmp[0]
            my = tmp[1]
        }
    }

    override fun onDetachedFromWindow() {
        pause()
        super.onDetachedFromWindow()
    }

    // ---------------- action selection ----------------
    // Before a fight he warms up with a few tricks in the free column where the fight will take place,
    // and then, suddenly, the rival drops in.
    private val chain = ArrayList<Act>()
    private var brLeftCol: Boolean? = null

    // v135: "rounds": every move (ball, butterfly, banana, flips ...) is done ONCE; a move is never picked again
    // until ALL the other moves have been done. Only then does a new round start (never the same move twice in a row).
    private val doneRound = HashSet<Act>()
    private var lastMove: Act? = null

    // v135: after every move he comes back down to the red line (the floor) before the next move starts.
    private var floorTrip = false
    // Patrol direction is persistent: the monkey traverses the usable part of the red baseline, then turns back.
    private var patrolDir = if (Random.nextBoolean()) 1 else -1
    // Watchdog for ground walking when the animation runs but the sprite does not advance.
    private var walkStallT = 0f
    private var walkLastX = 0f
    private var enterFollowUpSpoken = false
    private fun atFloor(): Boolean = my >= maxY() - 5f * d

    /** Picks the next move (weighted random) among the ones NOT done yet in this round; null when there is none at all. */
    private fun takeMove(all: List<Pair<Act, Float>>): Act? {
        if (all.isEmpty()) return null
        // Sleeping is the closing act of a full round, never an abrupt interruption
        // between a game (football/butterfly) and its next action.
        var cands = all.filter { it.first !in doneRound &&
            (it.first != Act.SLEEP || all.filter { a -> a.first != Act.SLEEP }.all { a -> a.first in doneRound }) }
        if (cands.isEmpty()) {
            // everything was done once: a new round starts (but never with the move he just did)
            doneRound.clear()
            cands = all.filter { it.first != lastMove }
            if (cands.isEmpty()) cands = all
        }
        var total = 0f
        for (c in cands) total += c.second
        var r = Random.nextFloat() * total
        var pick = cands.last().first
        for (c in cands) {
            r -= c.second
            if (r <= 0f) {
                pick = c.first
                break
            }
        }
        doneRound.add(pick)
        lastMove = pick
        return pick
    }

    /** The free column (left or right of the connect button) as monkey-centre x range, or null when there is none. */
    private fun column(left: Boolean): FloatArray? {
        val w = wall ?: return null
        val lo = if (left) marginX() else w.right
        val hi = if (left) w.left else vw - marginX()
        return if (hi - lo >= 40f * d) floatArrayOf(lo, hi) else null
    }

    private fun startBrawlChain() {
        val l = column(true)
        val r = column(false)
        if (l == null && r == null) {
            // no free column on this screen: fight where he is (old behaviour)
            brLeftCol = null
            begin(Act.BRAWL)
            return
        }
        val left = if (l != null && r != null) {
            if (sideOf(mx) >= 0) sideOf(mx) == 0 else Random.nextBoolean()
        } else l != null
        brLeftCol = left
        val col = (if (left) l else r)!!
        chain.clear()
        // v134: no more kung-fu punches in the air: the only thing he ever hits is the connect button (the punching bag)
        val tricks = ArrayList(listOf(Act.FLEX, Act.SPIN, Act.CARTWHEEL, Act.JUMP))
        // v135: only tricks that were NOT done yet in this round (no move twice)
        val fresh = tricks.filter { it !in doneRound }.shuffled()
        val n = min(fresh.size, Random.nextInt(2, 4))
        for (i in 0 until n) {
            chain.add(fresh[i])
            doneRound.add(fresh[i])
        }
        chain.add(Act.BRAWL)
        // walk to the column first, then train there
        begin(Act.WALK)
        tx = (col[0] + col[1]) / 2f
        ty = maxY()   // exactly on the red line (he is pinned there): a target 3dp above it was never reached, so he waited ~9s
    }

    private fun go(a: Act) {
        if (a == Act.BRAWL) startBrawlChain() else begin(a)
    }

    /** While the VPN is connected he only does cheerful things (each one once per round, see [takeMove]). */
    private fun nextParty() {
        val cands = ArrayList<Pair<Act, Float>>()
        fun add(a: Act, wt: Float) {
            cands.add(Pair(a, wt))
        }
        add(Act.CARTWHEEL, 1.5f)
        add(Act.JUMP, 1.5f)
        add(Act.SPIN, 1.3f)
        add(Act.FLEX, 1.2f)
        add(Act.EAT, 1f)
        add(Act.WALK, 1f)
        go(takeMove(cands) ?: Act.WALK)
    }

    private fun next() {
        // v135: connected: he only points at the banner and leaves when it is gone (no more playing)
        if (party) {
            chain.clear()
            floorTrip = false
            val b = try { bannerProvider?.invoke() } catch (_: Throwable) { null }
            begin(if (b != null || act == Act.ENTER) Act.SHOW else Act.GOODBYE)
            return
        }
        // v135: every move ends on the red line: before the next move he comes down to the floor first
        if (!floorTrip && (my < maxY() - 120f * d || inWall(mx, my))) {
            var x = mx
            val w = wall
            if (w != null && x > w.left && x < w.right) {
                // standing on top of the connect button: he climbs down on the nearest free side
                val l = column(true)
                val r = column(false)
                x = when {
                    l != null && (r == null || x - w.left <= w.right - x) -> w.left
                    r != null -> w.right
                    else -> x
                }
            }
            val far = hypot(x - mx, maxY() - my) > 120f * d
            begin(if (far) Act.RUN else Act.WALK)
            tx = clampX(x)
            ty = maxY()
            floorTrip = true
            return
        }
        floorTrip = false
        if (chain.isNotEmpty()) {
            begin(chain.removeAt(0))
            return
        }
        if (party) {
            nextParty()
            return
        }
        val cands = ArrayList<Pair<Act, Float>>()
        fun add(a: Act, wt: Float) {
            cands.add(Pair(a, wt))
        }
        // v187: walking, running and scratching were removed from the random list
        add(Act.JUMP, 2f)
        add(Act.CARTWHEEL, 1.2f)
        add(Act.EAT, 1.6f)
        add(Act.SLEEP, 1.1f)
        add(Act.BALL, 2f)
        add(Act.BUTTERFLY, 1.6f)
        add(Act.SWING, 1.8f) // pull-up / hanging / swinging, then slide down the connect button
        add(Act.FLEX, 1.0f)
        add(Act.SPIN, 1.2f)
        add(Act.SNEEZE, 1.0f)
        // v150: explicitly schedule the real punching-bag animation; it was implemented
        // but had been omitted from this list, so the monkey could never box the button.
        add(Act.PUNCH, 5.0f)
        add(Act.BRAWL, 1.25f)        // two monkeys wrestle on the floor line, beside the connect button
        // (the edge-crossing move was removed: he walks to the end of the line and turns back)
        go(takeMove(cands) ?: Act.WALK)
    }

    private fun begin(a: Act) {
        if (act == Act.BALL && a != Act.BALL) ballOn = false
        if (act == Act.BUTTERFLY && a != Act.BUTTERFLY) { bfOn = false; bfCaught = false }
        if (act == Act.BRAWL && a != Act.BRAWL && buddyOn) {
            spawn("💨", mb.x, mb.y - 40f * d, 0f, -20f * d, 0.8f, 20f * d)
            buddyOn = false
        }
        if (a == Act.DRAG || a == Act.THROWN || a == Act.TOUCHED || a == Act.WOOZY || a == Act.DIE || a == Act.LAUGH) chain.clear()
        if (a != Act.BRAWL) {
            brCloud = 0f
            bub2T = 0f
        }
        talkT = 0f
        if (a != Act.WALK) walkLegs = 0
        // Do not let a previous action's bubble survive into the next animation.
        bubbleText = null
        bubbleT = 0f
        bubbleDur = 0f
        speechQueue.clear()
        if (act == Act.SHOW && a != Act.SHOW && a != Act.GOODBYE) drawScale = 1f
        if (a != Act.WALK && a != Act.RUN) floorTrip = false
        if (a == Act.ENTER) enterFollowUpSpoken = false
        act = a
        sub = 0
        t = 0f
        subT = 0f
        kicked = false
        eaten = 0f
        if (a != Act.JUMP && a != Act.SIT && a != Act.PEEK) airMove = false
        when (a) {
            Act.ENTER -> {
                mx = rnd(marginX(), max(vw - marginX(), marginX() + 1f))
                my = maxY()
                push(mx, my)
                mx = tmp[0]
                my = tmp[1]
                hop = my + 140f * d
                hopV = 0f
                hopG = 1600f * d
                facing = if (Random.nextBoolean()) 1 else -1
            }
            Act.WALK -> {
                walkStallT = 0f
                walkLastX = mx
                pickTarget(110f * d)
            }
            Act.RUN -> {
                walkStallT = 0f
                walkLastX = mx
                pickTarget(180f * d)
            }
            Act.JUMP -> {
                tx = clampX(mx + rnd(-140f, 140f) * d)
                ty = clampY(my + rnd(-90f, 90f) * d)
                if (hypot(tx - mx, ty - my) < 50f * d) tx = clampX(mx + (if (mx < vw / 2f) 90f else -90f) * d)
                fitJump()
            }
            Act.CARTWHEEL -> {
                cwDir = if (mx < vw / 2f) 1 else -1
                if (Random.nextInt(100) < 25) cwDir = -cwDir
                // never cartwheel into the connect button or off the screen
                cwDist = min(150f * d, freeRun(cwDir))
                if (cwDist < 70f * d) {
                    cwDir = -cwDir
                    cwDist = min(150f * d, freeRun(cwDir))
                }
                facing = cwDir
            }
            Act.EAT -> {
                eatK = -1
                say("موز! 🍌" to "A banana! 🍌", 1.3f)
            }
            Act.DANCE -> noteT = 0f   // v134: no speech bubble while he dances
            Act.SLEEP -> {
                zT = 0f
                say("خوابم میاد... 😴" to "So sleepy... 😴", 2f)
            }
            Act.WAVE -> say("سلام! 👋" to "Hello! 👋", 2.2f)
            Act.SWING -> {
                swView = null
                swList.clear()
                swIdx = 0
                // v186: two tricks, picked by chance:
                //  mode 0: leap up to the bar in the middle of the top strip (nothing to do with the corner icons),
                //          swing on it, then let go and drop to the floor.
                //  mode 1: grab Settings, leap to Update (or the other way round) with NO bar under the icons, then leap
                //          onto the connect button (it shakes), slide down.
                swMode = 0
                if (Random.nextBoolean()) {
                    try {
                        val hv = hangers?.invoke()?.filter { v ->
                            val r = rectOf(v)
                            r != null && r.bottom > 0f && r.top < 160f * d
                        } ?: emptyList()
                        swList.addAll(hv.shuffled())
                    } catch (_: Throwable) {
                    }
                    val first = swList.firstOrNull()
                    val fr = first?.let { rectOf(it) }
                    if (first != null && fr != null) {
                        swMode = 1
                        swView = first
                        swHx = fr.centerX()
                        hangY = fr.bottom - 4f * d + 86f * sc
                        sitHopT = 0f
                    } else {
                        swList.clear()
                    }
                }
                if (swMode == 0) {
                    var l = 60f * d
                    var rt = vw - 60f * d
                    try {
                        val hs = hangers?.invoke()?.mapNotNull { rectOf(it) } ?: emptyList()
                        val lh = hs.filter { it.centerX() < vw / 2f }.maxByOrNull { it.right }
                        val rh = hs.filter { it.centerX() >= vw / 2f }.minByOrNull { it.left }
                        if (lh != null) l = lh.right + 14f * d
                        if (rh != null) rt = rh.left - 14f * d
                    } catch (_: Throwable) {
                    }
                    swHx = (l + rt) / 2f   // exactly in the middle of the free strip at the top
                    hangY = 8f * d + 88f * sc
                    sitHopT = 0f
                    say("تاب‌بازی! 🎢" to "Swing time! 🎢", 1.6f)
                }
            }
            Act.CROSS -> {
                crossRight = if (mx > vw / 2f) Random.nextInt(100) < 75 else Random.nextInt(100) < 25
                // inside the red zone he leaves through the screen edge of HIS column (never through the button)
                val cw = wall
                if (cw != null && my > cw.top && sideOf(mx) >= 0) crossRight = sideOf(mx) == 1
                tx = if (crossRight) vw + 55f * sc else -55f * sc
                ty = clampY(my)
            }
            Act.BALL -> {
                ballOn = true
                ballFlying = false
                ballSkyShot = false
                // v134: the ball starts on the far side from the monkey, he runs across to it
                pickFarSpot(mx)
                bx = tmp[0]
                by = tmp[1]
                bz = 0f
                bvx = 0f
                bvy = 0f
                bvz = 230f * d
                kicks = 0
                juggled = false
                juggleN = 0
                say("توپ! ⚽" to "A ball! ⚽", 2f)
            }
            Act.BUTTERFLY -> {
                bfOn = true
                bfLeaving = false
                val fromLeft = mx >= vw / 2f   // it comes in from the side where he is NOT
                bfx = if (fromLeft) -20f * d else vw + 20f * d
                bfy = rnd(max(minY(), maxY() - 134f * sc - 40f * d), maxY() - 134f * sc - 8f * d)
                pickButterflySpot()
                bt = 0f
                bfNext = 1.6f
                hopT = 1.4f
                bfFast = 0f
                bfDodgeT = -1f
                bfMiss = 0
                bfCool = 0f
                bfCaught = false
                say("پروانه! 🦋" to "A butterfly! 🦋", 2f)
            }
            Act.SIT -> {
                val v = pendingSit ?: pickSitView()
                pendingSit = null
                if (v == null) {
                    begin(Act.WALK)
                    return
                }
                sitView = v
                val r = rectOf(v)
                sitOx = if (r != null) rnd(-0.3f, 0.3f) * r.width() else 0f
                sitHopT = 0f
                sitHopN = 0
                sitFlip = false
            }
            Act.PEEK -> {
                peekLeft = mx < vw / 2f
                peekY = clampY(rnd(ay(0.2f), ay(0.9f)))
                hideX = if (peekLeft) -34f * sc else vw + 34f * sc
                shownX = if (peekLeft) 12f * sc else vw - 12f * sc
            }
            Act.GOODBYE -> {
                byeScale = drawScale
                ballOn = false
                bfOn = false
                // silent: the cheerful message is the banner at the top, the monkey only waves
                bubbleT = 0f
                bub2T = 0f
                chain.clear()
            }
            Act.LAUGH -> {
                hopG = 1800f * d
                hopV = 280f * d
                say(tickle.random(), 1.8f)
                spawnHearts(3)
            }
            Act.FLEX -> {
                noteT = 0f
                say("عضلاتمو ببین! 💪" to "Check my muscles! 💪", 2.2f)
            }
            Act.MOONWALK -> {
                var dir = if (Random.nextBoolean()) 1 else -1
                var dist = min(rnd(110f, 190f) * d, freeRun(dir))
                if (dist < 70f * d) {
                    dir = -dir
                    dist = min(rnd(110f, 190f) * d, freeRun(dir))
                }
                mwDir = dir
                tx = mx + dir * dist
                noteT = 0f
            }
            Act.PUNCH -> {
                val w = wall
                val v = pickBagView()
                if (w == null || v == null) {
                    begin(Act.WALK)
                    return
                }
                bagReset()
                bagView = v
                punchSide = if (Random.nextBoolean()) 0 else 1
                punchK = -1
                // he stays ON the floor line, right under the button, and punches upwards at it
                val br = avoidCache
                val cxB = br?.centerX() ?: ((w.left + w.right) / 2f)
                val rB = if (br != null) min(br.width(), br.height()) / 2f else 60f * d
                // he stands beside the middle of the button's lower edge (a bit to the left or right) and punches up at it
                tx = cxB + (if (punchSide == 0) -0.45f else 0.45f) * rB
                ty = maxY()
                say("کیسه‌ی بوکس من! 🥊" to "My punching bag! 🥊", 2f)
            }
            Act.KUNGFU -> say("آماده‌ام! 🥋" to "Ready! 🥋", 1.2f)
            Act.JACKS -> {}
            Act.SPIN -> {
                noteT = 0f
                say("ووووش! 💫" to "Whirl! 💫", 1.5f)
            }
            Act.SNEEZE -> say("آآآ... 🤧" to "Aah... 🤧", 1.8f)
            Act.SNEAK -> {
                pickTarget(90f * d)
                noteT = 0.4f
            }
            Act.MEDITATE -> {
                zT = 0f
            }
            Act.BRAWL -> {
                pendingSit = null
                // they always wrestle on the floor line (the red line), in the free column beside the connect button
                brView = null
                val w = wall
                brSpread = 30f * d
                val lc = column(true)
                val rc2 = column(false)
                val wantLeft = brLeftCol
                brLeftCol = null
                val col = when {
                    wantLeft == true && lc != null -> lc
                    wantLeft == false && rc2 != null -> rc2
                    lc != null && rc2 != null -> if (Random.nextBoolean()) lc else rc2
                    else -> lc ?: rc2
                }
                if (w != null && col != null) {
                    brX = (col[0] + col[1]) / 2f
                    brHalf = min(28f * d, (col[1] - col[0]) / 2f)
                    brSpread = min(30f * d, (col[1] - col[0]) / 2f)
                } else {
                    brX = clampX(vw * 0.5f + rnd(-0.2f, 0.2f) * vw)
                    push(brX, maxY())
                    brX = tmp[0]
                    brHalf = 28f * d
                }
                brY = maxY() - 3f * d
                brSide = if (brX < vw / 2f) -1 else 1
                rivalStartX = if (brSide < 0) -50f * sc else vw + 50f * sc
                brWinner = Random.nextInt(2)
                brLine = 0
                brCloud = 0f
                buddyOn = false
                bub2T = 0f
                ballOn = false
                bfOn = false
            }
            Act.TOUCHED -> say(touchedLines.random(), 1.9f)
            Act.WOOZY -> {
                say(warnLines.random(), 1.6f)
                spawn("💫", mx, my - 118f * sc, 0f, -30f * d, 0.9f, 18f * d)
            }
            Act.DIE -> {
                ballOn = false
                bfOn = false
                hop = 0f
                hopV = 0f
                airMove = false
                zT = 0f
                say(dieLines.random(), 1.7f)
            }
            Act.GENIUS -> {
                noteT = 0f
                say(smartLines.random(), 2.8f)
            }
            Act.DROP -> {
                hop = 26f * d
                hopV = 0f
                hopG = 1800f * d
            }
            Act.DRAG -> {
                hop = 0f
                hopV = 0f
                airMove = false
                say("هوووی! منو بذار زمین! 😆" to "Hey! Put me down! 😆", 1.8f)
            }
            Act.SHOW -> {
                drawScale = 0.62f
                showHave = false
            }
            Act.THROWN -> {
                hop = 0f
                hopV = 0f
                lift = 0f
                airMove = false
                tAng = 0f
                tSpin = (tvx / d * 0.9f).coerceIn(-1000f, 1000f)
                say("ووووو! 🚀" to "Wheee! 🚀", 1.6f)
            }
            else -> {}
        }
        if (a != Act.GOODBYE && a != Act.DRAG && a != Act.DROP && a != Act.ENTER && a != Act.LAUGH &&
            a != Act.TOUCHED && a != Act.WOOZY && a != Act.DIE && a != Act.THROWN
        ) {
            recent.add(a)
            if (recent.size > 7) recent.removeAt(0)
        }
    }

    // ---------------- per-frame logic ----------------
    private fun step(dt: Float) {
        t += dt
        subT += dt
        tailT += dt

        // reset pose
        footA = 0f
        footB = 0f
        liftA = 0f
        liftB = 0f
        armA1 = 6f
        armA2 = 6f
        armLen2 = 26f
        tilt = 0f
        squash = 1f
        mouth = 0f
        eyes = 0
        lookX = 0f
        bob = 0f
        pivotY = -45f
        lift = 0f
        item = 0
        spinX = 1f
        shades = false
        aura = 0f
        angry = false

        updateFloor()
        if (act != Act.SWING && act != Act.GOODBYE) my = min(my, maxY())

        squashK = max(0f, squashK - dt * 4f)

        blinkIn -= dt
        if (blinkIn <= 0f) {
            blinkOn = 0.12f
            blinkIn = rnd(1.6f, 4.5f)
        }
        blinkOn -= dt

        // physics: ground velocity while in the air, then the hop
        if (airMove) {
            mx += vx * dt
            my += vy * dt
        }
        if (hop > 0f || hopV != 0f) {
            hopV -= hopG * dt
            hop += hopV * dt
            if (hop <= 0f) {
                val impact = -hopV
                hop = 0f
                hopV = 0f
                airMove = false
                vx = 0f
                vy = 0f
                if (impact > 90f * d) squashK = 1f
                justLanded = true
            }
        }
        updateBall(dt)
        updateButterfly(dt)
        updateBag(dt)

        when (act) {
            Act.ENTER -> actEnter()
            Act.WALK, Act.RUN -> {
                val run = act == Act.RUN
                // calm patrol only (not on the way down to the floor, not on the way to the brawl column)
                val calm = !run && !floorTrip && chain.isEmpty() && !party
                if (calm) {
                    if (talkT > 0f) {
                        talkT -= dt
                    } else {
                        walkChatT -= dt
                        // never start a line right at an end of the line: he first has to get there and turn
                        if (walkChatT <= 0f && bubbleT <= 0f && abs(tx - mx) > 70f * d) {
                            say(walkChatDeck.next(), 2.2f)
                            talkT = bubbleT   // 0 when the line was not shown: then he simply keeps walking
                            walkChatT = rnd(3.5f, 6f)
                        }
                    }
                }
                val talking = calm && talkT > 0f
                if (talking) t -= dt   // the stop to talk must not use up the walking time
                val beforeX = mx
                val arrived = moveToward(tx, ty, (if (run) 245f else 105f) * d, dt)
                val movedX = abs(mx - beforeX)
                if (talking) {
                    bob = abs(sin(subT * 3f)) * 1.5f   // standing and chatting: no stepping in place
                } else {
                    cycle(dt, if (run) 17f else 9f, if (run) 1.5f else 1f)
                }
                if (run) {
                    tilt = 9f
                    mouth = 0.3f
                }
                // Recover from a true stall: retarget inside the current safe column.
                if (!talking && !run && !arrived && abs(tx - mx) > 16f * d && movedX < 0.35f * d) {
                    walkStallT += dt
                } else {
                    walkStallT = 0f
                }
                if (!run && walkStallT >= 0.55f) {
                    val edge = max(marginX(), 44f * d)
                    var safeLo = edge
                    var safeHi = max(edge + 1f, vw - edge)
                    val obstacle = wall
                    if (obstacle != null && my >= obstacle.top - 2f * d) {
                        if (mx <= obstacle.left) safeHi = min(safeHi, obstacle.left - 28f * d)
                        else if (mx >= obstacle.right) safeLo = max(safeLo, obstacle.right + 28f * d)
                    }
                    if (safeHi - safeLo < 20f * d) {
                        safeLo = edge
                        safeHi = max(edge + 1f, vw - edge)
                    }
                    patrolDir = if (mx < (safeLo + safeHi) / 2f) 1 else -1
                    var newTarget = if (patrolDir > 0) safeHi else safeLo
                    if (abs(newTarget - mx) < 14f * d) {
                        patrolDir = -patrolDir
                        newTarget = if (patrolDir > 0) safeHi else safeLo
                    }
                    tx = newTarget.coerceIn(safeLo, safeHi)
                    ty = maxY()
                    val nudge = min(5f * d, abs(tx - mx))
                    val dir = if (tx >= mx) 1f else -1f
                    mx = (mx + dir * nudge).coerceIn(safeLo, safeHi)
                    facing = dir.toInt()
                    walkStallT = 0f
                }
                if (arrived || t > 9f) {
                    // pickTarget() reverses at a reached endpoint. Force a reversal only
                    // after timeout, when the target was not reached.
                    if (!run && !arrived) patrolDir = -patrolDir
                    if (calm && arrived && walkLegs < 2) {
                        // reached the end of the line: turn round and walk it back (pickTarget flips the direction)
                        walkLegs++
                        begin(Act.WALK)
                    } else {
                        next()
                    }
                }
                walkLastX = mx
            }
            Act.JUMP -> actJump()
            Act.CARTWHEEL -> actCartwheel(dt)
            Act.SCRATCH -> {
                armA2 = 168f + sin(subT * 13f) * 14f
                eyes = 1
                mouth = 0.2f
                tilt = sin(subT * 2.5f) * 4f
                squash *= 0.97f
                if (subT > 2.8f) next()
            }
            Act.EAT -> {
                // v132: the banana is clearly in his hand: first he shows it, then four bites
                item = 1
                val hold = 0.9f
                val per = 1.0f
                armA1 = 10f
                armLen2 = 26f
                eyes = 1
                if (subT < hold) {
                    armA2 = 95f + sin(subT * 6f) * 6f
                    banRot = 0f
                    eaten = 0f
                    mouth = 0.3f
                } else {
                    val k = ((subT - hold) / per).toInt()
                    val f = (subT - hold - k * per) / per
                    if (k < 4) {
                        if (k != eatK) {
                            eatK = k
                            kicked = false
                        }
                        if (f < 0.4f) {
                            val p = f / 0.4f
                            armA2 = 95f + 75f * p      // hand with the banana goes up to the mouth
                            banRot = -80f * p
                            mouth = 0.9f * p
                        } else {
                            val p = min(1f, (f - 0.4f) / 0.2f)
                            armA2 = 170f - 55f * p     // lowers it again while he chews
                            banRot = -80f * (1f - p)
                            mouth = abs(sin(subT * 16f)) * 0.6f
                            if (!kicked) {
                                kicked = true
                                spawn("🍌", mx + facing * 8f * d, my - 78f * sc, rnd(-20f, 20f) * d, -25f * d, 0.6f, 11f * d)
                                if (k == 0) say("ممم، چه خوشمزه! 🍌" to "Mmm, yummy! 🍌", 1.8f)
                            }
                        }
                        eaten = (k + (if (f >= 0.4f) 1f else 0f)) / 4f
                    } else {
                        eaten = 1f
                        banRot = 0f
                        if (eatK != 4) {
                            eatK = 4
                            say("آخیش، سیر شدم! 😋" to "Ahh, I'm full! 😋", 1.6f)
                        }
                        armA2 = 40f                  // pats his belly
                        mouth = 0.5f
                        tilt = sin(subT * 8f) * 3f
                    }
                }
                if (subT > hold + 4f * per + 0.9f) {
                    spawn("✨", mx, my - 80f * d, 0f, -30f * d, 0.9f, 18f * d)
                    next()
                }
            }
            Act.DANCE -> actDance(dt)
            Act.SLEEP -> actSleep(dt)
            Act.WAVE -> {
                armA2 = 150f + sin(subT * 14f) * 28f
                eyes = 1
                mouth = 0.5f
                bob = abs(sin(subT * 4f)) * 2f
                if (subT > 2.6f) next()
            }
            Act.SWING -> actSwing(dt)
            Act.THROWN -> actThrown(dt)
            Act.SHOW -> actShow(dt)
            Act.BALL -> actBall(dt)
            Act.BUTTERFLY -> actButterfly(dt)
            Act.SIT -> actSit(dt)
            Act.PEEK -> actPeek(dt)
            Act.CROSS -> actCross(dt)
            Act.GOODBYE -> actGoodbye(dt)
            Act.BACKFLIP -> actBackflip()
            Act.FLEX -> actFlex(dt)
            Act.MOONWALK -> actMoonwalk(dt)
            Act.KUNGFU -> actKungfu()
            Act.PUNCH -> actPunch(dt)
            Act.JACKS -> actJacks()
            Act.SPIN -> actSpin(dt)
            Act.SNEEZE -> actSneeze()
            Act.SNEAK -> actSneak(dt)
            Act.MEDITATE -> actMeditate(dt)
            Act.HEADSPIN -> actHeadspin()
            Act.BRAWL -> actBrawl(dt)
            Act.TOUCHED -> actTouched(dt)
            Act.WOOZY -> actWoozy()
            Act.DIE -> actDie(dt)
            Act.GENIUS -> actGenius(dt)
            Act.DRAG -> {
                armA1 = -150f + sin(subT * 12f) * 20f
                armA2 = 150f - sin(subT * 12f) * 20f
                footA = sin(subT * 14f) * 10f
                footB = -footA
                liftA = 6f
                liftB = 6f
                lift = 16f * d
                tilt = sin(subT * 7f) * 8f
                pivotY = -100f
                eyes = 3
                mouth = 0.8f
            }
            Act.DROP -> {
                if (sub == 0) {
                    armA1 = -150f
                    armA2 = 150f
                    eyes = 3
                    mouth = 0.9f
                    if (justLanded) {
                        setSub(1)
                    }
                } else {
                    eyes = 1
                    mouth = 0.6f
                    if (subT > 0.8f && bubbleT <= 0f) next()
                }
            }
            Act.LAUGH -> {
                tilt = sin(subT * 22f) * 9f
                eyes = 1
                mouth = 1f
                armA1 = -60f + sin(subT * 18f) * 20f
                armA2 = 60f - sin(subT * 18f) * 20f
                if (subT > 0.6f && !kicked) {
                    kicked = true
                    hopG = 1800f * d
                    hopV = 240f * d
                }
                if (subT > 1.6f) next()
            }
        }

        // v145: keep every autonomous action grounded on the marked red line. Vertical tricks use hop/lift,
        // so the feet anchor remains on the line; only direct user dragging/throwing may leave it.
        if (act != Act.DRAG && act != Act.THROWN && act != Act.GOODBYE && act != Act.SWING && act != Act.SHOW && act != Act.PUNCH) {
            my = maxY()
        }

        // safety net: whatever happened (layout change, ...) the monkey is never left on the connect button
        if (wall != null && act != Act.SWING && act != Act.GOODBYE && act != Act.DRAG && act != Act.THROWN &&
            act != Act.BALL && act != Act.BUTTERFLY && !floorTrip && inWall(mx, my)) {
            push(mx, my)
            mx = tmp[0]
            my = tmp[1]
        }

        squash *= (1f - 0.22f * squashK)

        bubbleT = max(0f, bubbleT - dt)
        if (bubbleT <= 0f) {
            bubbleText = null
            if (speechQueue.isNotEmpty()) {
                val queued = speechQueue.removeFirst()
                bubbleText = queued.first
                bubbleDur = queued.second
                bubbleT = queued.second
            }
        }
        bub2T = max(0f, bub2T - dt)

        // particles
        val it = pts.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.life -= dt
            p.x += p.vx * dt
            p.y += p.vy * dt
            if (p.life <= 0f) it.remove()
        }
        justLanded = false
    }

    // ---------------- actions ----------------
    private fun actEnter() {
        if (sub == 0) {
            armA1 = -165f
            armA2 = 165f
            eyes = 3
            mouth = 0.9f
            tilt = sin(subT * 9f) * 6f
            if (justLanded) {
                setSub(1)
                say("سلام! اومدم 👋🐵" to "Hello! I'm here 👋🐵", 2f)   // the only hello: once, when he first appears
            }
        } else {
            armA2 = 150f + sin(subT * 14f) * 25f
            eyes = 1
            mouth = 0.5f
            if (!enterFollowUpSpoken && bubbleT <= 0f && subT > 1.25f) {
                enterFollowUpSpoken = true
                sayNow(if (fa) "تا فیلترشکن رو روشن نکنی من اینجا هستم! 🐵" else "Until you turn the VPN on, I'm staying here! 🐵", 1.65f)
            } else if (enterFollowUpSpoken && bubbleT <= 0f && subT > 1.25f) {
                next()
            }
        }
    }

    private fun actJump() {
        when (sub) {
            0 -> {
                squash *= 0.8f
                armA1 = -25f
                armA2 = 25f
                if (subT > 0.18f) {
                    launch(tx, ty, 0.65f, 40f * d)
                    flip = Random.nextInt(100) < 35
                    setSub(1)
                }
            }
            1 -> {
                armA1 = -150f
                armA2 = 150f
                mouth = 0.6f
                eyes = 1
                if (flip) tilt = 360f * (subT / 0.65f).coerceIn(0f, 1f)
                if (justLanded) setSub(2)
            }
            else -> {
                eyes = 1
                if (subT > 0.3f) next()
            }
        }
    }

    private fun actCartwheel(dt: Float) {
        val dur = 1.1f
        val p = (subT / dur).coerceIn(0f, 1f)
        mx += cwDir * (cwDist / dur) * dt
        tilt = 720f * p
        lift = sin(PI.toFloat() * p) * 30f * d
        armA1 = -170f
        armA2 = 170f
        eyes = 1
        mouth = 0.7f
        if (subT >= dur) {
            squashK = 1f
            next()
        }
    }

    private fun actDance(dt: Float) {
        // A more playful modern dance: alternating side-steps, arm waves and a gentle bounce.
        val beat = subT * 9.5f
        val s = sin(beat)
        val side = sin(beat * 0.5f)
        armA1 = -132f + sin(beat + 0.8f) * 42f
        armA2 = 132f + sin(beat - 0.8f) * 42f
        tilt = side * 13f
        bob = abs(s) * 7f
        footA = s * 13f + side * 4f
        footB = -s * 13f - side * 4f
        liftA = max(0f, s) * 10f
        liftB = max(0f, -s) * 10f
        lift = abs(sin(beat * 0.5f)) * 3f * d
        eyes = 1
        mouth = 0.65f
        noteT -= dt
        if (noteT <= 0f) {
            noteT = 0.38f
            val fx = mx + rnd(-30f, 30f) * d
            spawn(if (Random.nextBoolean()) "🎵" else "✨", fx, my - 100f * d,
                rnd(-24f, 24f) * d, -48f * d, 1.25f, 19f * d)
        }
        if (subT > 4.6f) next()
    }

    private fun actSleep(dt: Float) {
        if (sub == 0) {
            squash *= 0.78f
            footA = -14f
            footB = 14f
            armA1 = 18f
            armA2 = 18f
            eyes = 2
            tilt = sin(subT * 1.6f) * 7f
            mouth = 0.25f + 0.2f * sin(subT * 2.2f)
            zT -= dt
            if (zT <= 0f) {
                zT = 0.9f
                spawn("💤", mx + 20f * d, my - 80f * d, 14f * d, -36f * d, 1.8f, 18f * d)
            }
            if (subT > 4.4f) {
                hopG = 1800f * d
                hopV = 260f * d
                setSub(1)
                say("هااا؟ خوابم برده بود 😳" to "Huh? I fell asleep 😳", 2f)
            }
        } else {
            eyes = 3
            mouth = 0.8f
            armA1 = -120f
            armA2 = 120f
            if (subT > 0.9f) next()
        }
    }

    /** Geometry of the round connect button (live: the page may be scrolled). */
    private fun refreshSlide() {
        val ar = avoidCache ?: return
        slideCx = ar.centerX()
        slideCy = ar.centerY()
        slideR = max(1f, min(ar.width(), ar.height()) / 2f)
    }

    /** Is the free column on side [s] (-1 left, 1 right) of the button wide enough to land in? */
    private fun colOk(s: Int): Boolean {
        val w = wall ?: return false
        return if (s > 0) vw - marginX() - w.right > 34f * d else w.left - marginX() > 34f * d
    }

    /** After the pull-ups / hanging: leap onto the connect button if it is round and a free column exists, else drop. */
    private fun swingFinish() {
        fallV = 0f
        val ar = avoidCache
        val w = wall
        if (ar != null && w != null && ar.width() > 0f && ar.height() > 0f &&
            abs(ar.width() - ar.height()) < 0.25f * max(ar.width(), ar.height())
        ) {
            refreshSlide()
            val pref = if (swHx < slideCx) -1 else 1
            val side = if (colOk(pref)) pref else if (colOk(-pref)) -pref else 0
            if (side != 0) {
                slideSide = side
                slideLandX = slideCx + side * slideR * rnd(0.1f, 0.3f)
                swX0 = mx
                swY0 = my
                setSub(21)   // backflip from the bar / icon onto the connect button
                return
            }
        }
        // no round button to slide on: he just drops beside it
        dropY = clampY(rnd(ay(0.4f), ay(0.95f)))
        push(mx, dropY)
        dropX = tmp[0]
        dropY = tmp[1]
        setSub(9)
    }

    private fun actSwing(dt: Float) {
        if (swMode == 1) {
            // follow the corner button we hang from (it moves when the page is scrolled)
            swView?.let { v ->
                val r = rectOf(v)
                if (r != null) {
                    swHx = r.centerX()
                    hangY = r.bottom - 4f * d + 86f * sc
                }
            }
        }
        when (sub) {
            0 -> {
                val arrived = moveToward(swHx, my, 200f * d, dt)
                cycle(dt, 16f, 1.4f)
                tilt = 8f
                if (arrived || t > 6f) {
                    swY0 = my
                    swX0 = mx
                    setSub(1)
                }
            }
            1 -> {
                val p = (subT / 0.9f).coerceIn(0f, 1f)
                my = swY0 + (hangY - swY0) * (1f - (1f - p) * (1f - p))
                mx = swX0 + (swHx - swX0) * p   // one leap up to the bar
                armA1 = -150f * p   // arms spread: both hands open on the bar
                armA2 = 150f * p
                eyes = 3
                if (subT >= 0.9f) {
                    my = hangY
                    mx = swHx
                    pullK = -1
                    setSub(2)
                    sitHopT = 1.85f
                    swView?.let { poke(it) }
                    say("ووووی! 🎢" to "Wheee! 🎢", 2f)
                }
            }
            2 -> {
                if (swMode == 0) {
                    // v187: he only holds the middle bar and swings on it, then lets go and drops to the floor
                    my = hangY
                    mx = swHx
                    val ramp = min(1f, subT / 0.5f)
                    tilt = sin(subT * 3.4f) * 30f * ramp
                    pivotY = -86f
                    armA1 = -150f
                    armA2 = 150f
                    footA = sin(subT * 3.4f + 0.6f) * 9f
                    footB = -footA
                    eyes = 1
                    mouth = 0.8f
                    if (subT > 3.4f) {
                        fallV = 0f
                        dropY = clampY(rnd(ay(0.4f), ay(0.95f)))
                        push(mx, dropY)
                        dropX = tmp[0]
                        dropY = tmp[1]
                        setSub(9)
                    }
                    return
                }
                my = hangY
                mx = swHx
                sitHopT -= dt
                if (sitHopT <= 0f) {
                    sitHopT = 1.85f
                    swView?.let { poke(it) }
                }
                val ramp = min(1f, subT / 0.5f)
                tilt = sin(subT * 3.4f) * 30f * ramp
                pivotY = -86f
                armA1 = -150f
                armA2 = 150f
                footA = sin(subT * 3.4f + 0.6f) * 9f
                footB = -footA
                eyes = 1
                mouth = 0.8f
                if (subT > 2.3f) {
                    if (swIdx + 1 < swList.size) {
                        // let go and leap over to the other corner button
                        swIdx++
                        swView = swList[swIdx]
                        swX0 = mx
                        swY0 = my
                        setSub(20)
                        return
                    }
                    swingFinish()
                }
            }
            20 -> {
                // leap from one corner button to the other, hands up
                val p = (subT / 0.8f).coerceIn(0f, 1f)
                mx = swX0 + (swHx - swX0) * p
                my = swY0 + (hangY - swY0) * p - sin(PI.toFloat() * p) * 40f * d
                pivotY = -86f
                tilt = (if (swHx > swX0) 1f else -1f) * 14f * sin(PI.toFloat() * p)
                armA1 = -150f
                armA2 = 150f
                eyes = 3
                mouth = 0.8f
                if (subT >= 0.8f) {
                    my = hangY
                    mx = swHx
                    setSub(2)
                    sitHopT = 1.85f
                    swView?.let { poke(it) }
                    say("ووووی! 🎢" to "Wheee! 🎢", 1.6f)
                }
            }
            21 -> {
                // backflip from the hanging button up onto the top of the connect button
                refreshSlide()
                val th0 = 0.18f
                val lx = slideCx + slideSide * slideR * sin(th0)
                val ly = slideCy - slideR * cos(th0)
                val p = (subT / 1.0f).coerceIn(0f, 1f)
                mx = swX0 + (lx - swX0) * p
                my = swY0 + (ly - swY0) * p - sin(PI.toFloat() * p) * 110f * d
                tilt = -360f * p
                armA1 = -150f
                armA2 = 150f
                eyes = 1
                mouth = 0.8f
                if (subT >= 1.0f) {
                    mx = lx
                    my = ly
                    tilt = 0f
                    squashK = 1f
                    if (swMode == 1) {
                        bagView = pickBagView()
                        bagW += -slideSide * 60f       // the landing makes the button shake (a little)
                    }
                    spawn("💥", mx, my, 0f, -20f * d, 0.5f, 22f * d)
                    say("پشتک روی دکمه! 🤸" to "Backflip on the button! 🤸", 1.6f)
                    setSub(22)
                }
            }
            22 -> {
                // a second backflip, in place, on top of the connect button; every landing shakes it
                refreshSlide()
                val th0 = 0.18f
                val bx = slideCx + slideSide * slideR * sin(th0)
                val by = slideCy - slideR * cos(th0)
                val p = (subT / 0.9f).coerceIn(0f, 1f)
                mx = bx
                my = by - sin(PI.toFloat() * p) * 80f * d
                tilt = -360f * p
                armA1 = -150f
                armA2 = 150f
                eyes = 1
                mouth = 0.8f
                if (subT >= 0.9f) {
                    mx = bx
                    my = by
                    tilt = 0f
                    squashK = 1f
                    if (swMode == 1) {
                        if (bagView == null) bagView = pickBagView()
                        bagW += slideSide * 70f
                    }
                    spawn("💥", mx, my, 0f, -20f * d, 0.5f, 22f * d)
                    spawn("✨", mx, my - 40f * d, 0f, -30f * d, 0.9f, 18f * d)
                    slideTh = asin((abs(bx - slideCx) / slideR).coerceIn(0f, 1f))
                    slideThV = 0.3f
                    slideT = 0f
                    sitHopT = 0f
                    setSub(4)
                }
            }
            3 -> {
                // falling onto the top of the button
                refreshSlide()
                fallV += 1800f * d * dt
                my += fallV * dt
                mx += (slideLandX - mx) * min(1f, dt * 5f)
                armA1 = -150f
                armA2 = 150f
                eyes = 3
                mouth = 0.9f
                val dx = (mx - slideCx).coerceIn(-slideR * 0.95f, slideR * 0.95f)
                val surf = slideCy - sqrt(slideR * slideR - dx * dx)
                if (my >= surf) {
                    slideTh = asin((abs(dx) / slideR).coerceIn(0f, 1f))
                    slideThV = 0.3f
                    slideT = 0f
                    sitHopT = 0f
                    mx = slideCx + slideSide * slideR * sin(slideTh)
                    my = slideCy - slideR * cos(slideTh)
                    squashK = 1f
                    spawn("💨", mx, my - 4f * d, 0f, -20f * d, 0.7f, 18f * d)
                    say("واااای! سُر خوردم! 🛝" to "Whoa, I'm sliding! 🛝", 1.8f)
                    setSub(4)
                }
            }
            4 -> {
                // sliding down the side of the round button
                refreshSlide()
                slideT += dt
                slideThV += (130f * d / slideR) * sin(slideTh) * dt
                slideTh += slideThV * dt
                mx = slideCx + slideSide * slideR * sin(slideTh)
                my = slideCy - slideR * cos(slideTh)
                facing = slideSide
                tilt = slideTh * 180f / PI.toFloat()
                pivotY = 0f
                armA1 = -140f + sin(slideT * 20f) * 12f
                armA2 = 140f - sin(slideT * 20f) * 12f
                footA = 14f
                footB = 9f
                eyes = 1
                mouth = 0.9f
                sitHopT -= dt
                if (sitHopT <= 0f) {
                    sitHopT = 0.12f
                    spawn("💨", mx - slideSide * 10f * d, my - 8f * d, -slideSide * 20f * d, -15f * d, 0.5f, 14f * d)
                }
                if (slideTh >= 1.2f) {
                    // he leaves the button's side and falls to the floor beside it
                    val w = wall
                    val vTan = slideR * slideThV
                    fallV = vTan * sin(slideTh) * 0.6f
                    dropX = if (w != null) {
                        (if (slideSide > 0) w.right + 6f * d else w.left - 6f * d).coerceIn(marginX(), max(vw - marginX(), marginX()))
                    } else mx
                    dropY = min(max(clampY(rnd(ay(0.45f), ay(0.95f))), my + 30f * d), maxY())
                    setSub(5)
                }
            }
            5 -> {
                fallV += 1800f * d * dt
                my += fallV * dt
                mx += (dropX - mx) * min(1f, dt * 6f)
                armA1 = -150f
                armA2 = 150f
                eyes = 3
                mouth = 0.9f
                tilt = 10f * slideSide
                if (my >= dropY) {
                    my = dropY
                    mx = dropX
                    swView = null
                    squashK = 1f
                    spawn("💨", mx, my - 4f * d, 0f, -20f * d, 0.7f, 18f * d)
                    say("سریع‌تر فیلترشکن رو روشن کن تا من دست و پامو نشکوندم! 🤕" to "Turn the VPN on quickly before I break my arms and legs! 🤕", 1.9f)
                    next()
                }
            }
            else -> {
                fallV += 1800f * d * dt
                my += fallV * dt
                mx += (dropX - mx) * min(1f, dt * 5f)
                armA1 = -150f
                armA2 = 150f
                eyes = 3
                mouth = 0.9f
                if (my >= dropY) {
                    my = dropY
                    mx = dropX
                    swView = null
                    squashK = 1f
                    spawn("💨", mx, my - 4f * d, 0f, -20f * d, 0.7f, 18f * d)
                    next()
                }
            }
        }
    }

    // ----- v133: he stands beside the green banner and points at it -----
    private fun actShow(dt: Float) {
        val b = try { bannerProvider?.invoke() } catch (_: Throwable) { null }
        if (b != null) {
            // v134: he stands in the gap between the banner and the corner icon (settings / update), never on an icon
            var lim0 = marginX()
            var lim1 = vw - marginX()
            try {
                val hs = hangers?.invoke()?.mapNotNull { rectOf(it) } ?: emptyList()
                val lh = hs.filter { it.centerX() < vw / 2f }.maxByOrNull { it.centerX() }
                val rh = hs.filter { it.centerX() >= vw / 2f }.minByOrNull { it.centerX() }
                if (lh != null) lim0 = max(lim0, lh.centerX() + 21f * d)
                if (rh != null) lim1 = min(lim1, rh.centerX() - 21f * d)
            } catch (_: Throwable) {
            }
            val gapL = b.left - lim0
            val gapR = lim1 - b.right
            val useLeft = if (gapL >= 30f * d && gapR >= 30f * d) mx < b.centerX() else gapL >= gapR
            val gap = max(if (useLeft) gapL else gapR, 12f * d)
            drawScale = ((gap / 2f - 3f * d) / (28f * sc)).coerceIn(0.38f, 0.62f)
            showX = if (useLeft) b.left - gap / 2f else b.right + gap / 2f
            showFace = if (useLeft) 1 else -1
            showY = b.bottom - 6f * d
            showHave = true
        }
        if (sub == 0) {
            if (!showHave) {
                // the banner is not on the screen yet: wait a moment
                cycle(dt, 6f, 0.2f)
                if (t > 1.5f) leaveShow()   // the banner never came: he leaves
                return
            }
            val arrived = moveToward(showX, showY, 200f * d, dt)
            cycle(dt, 14f, 1.2f)
            if (arrived || t > 9f) {
                facing = showFace
                setSub(1)
            }
            return
        }
        facing = showFace
        armA1 = 6f
        armA2 = 100f + sin(subT * 9f) * 12f   // his arm points at the banner
        eyes = 1
        mouth = 0.5f
        bob = abs(sin(subT * 5f)) * 2f
        if (b != null && !kicked && subT > 0.3f) {
            kicked = true
            spawn(if (facing > 0) "👉" else "👈", mx + facing * 30f * sc * drawScale, my - 62f * sc * drawScale, facing * 20f * d, 0f, 1.2f, 18f * d)
        }
        if (b != null && Random.nextInt(100) < 3) {
            spawn(
                if (Random.nextBoolean()) "🎉" else "✨",
                b.centerX() + rnd(-b.width() / 3f, b.width() / 3f), b.bottom,
                0f, 40f * d, 1.4f, rnd(16f, 22f) * d
            )
        }
        // v135: he stays beside the banner as long as it is there; when it is gone he leaves too
        if (subT > 20f || (b == null && subT > 0.8f)) leaveShow()
    }

    /** v135: the banner is gone: he waves, vanishes with a little poof and does not come back until the VPN disconnects. */
    private fun leaveShow() {
        begin(Act.GOODBYE)
    }

    // ----- v132: thrown with the finger: flies around, bounces off the screen edges, the floor and the button -----
    private fun actThrown(dt: Float) {
        val rdt = min(dt / TIME_SCALE, 0.04f)   // real time: the throw must feel like the finger
        pivotY = -55f
        if (sub == 0) {
            var onGround = false
            tvy += 2300f * d * rdt
            mx += tvx * rdt
            my += tvy * rdt
            tAng += tSpin * rdt
            // v135: he flies straight over the connect button (no bouncing off it)
            val w = wall
            val under = w != null && mx > w.left && mx < w.right
            val hw = 22f * sc + 4f * d
            if (mx < hw) { mx = hw; tvx = abs(tvx) * 0.65f; tSpin = -tSpin * 0.7f }
            if (mx > vw - hw) { mx = vw - hw; tvx = -abs(tvx) * 0.65f; tSpin = -tSpin * 0.7f }
            val ceil = 122f * sc + 2f * d
            if (my < ceil) { my = ceil; tvy = abs(tvy) * 0.55f }
            val fl = maxY()
            if (my >= fl) {
                my = fl
                if (tvy > 300f * d) {
                    spawn("💫", mx, my - 24f * d, rnd(-30f, 30f) * d, -30f * d, 0.6f, 16f * d)
                    squashK = 1f
                    tvy = -tvy * 0.45f
                    tvx *= 0.8f
                    tSpin *= 0.6f
                } else {
                    tvy = 0f
                    onGround = true
                }
            }
            if (onGround && under && w != null) {
                // landed in front of the button: he slides out on the nearest free side
                val toLeft = (mx - w.left) < (w.right - mx)
                val goLeft = if (toLeft) column(true) != null else column(false) == null
                tvx = (if (goLeft) -170f else 170f) * d
                tSpin *= 0.9f
            } else if (onGround) {
                val fr = max(0f, 1f - 5f * rdt)
                tvx *= fr
                tSpin *= fr
            }
            tilt = tAng
            armA1 = -140f + sin(subT * 16f) * 20f
            armA2 = 140f - sin(subT * 16f) * 20f
            footA = sin(subT * 14f) * 10f
            footB = -footA
            eyes = 3
            mouth = 0.9f
            if (onGround && !under && abs(tvx) < 40f * d && abs(tSpin) < 60f) {
                setSub(1)
            }
        } else {
            var a = tAng % 360f
            if (a > 180f) a -= 360f
            if (a < -180f) a += 360f
            val p = min(1f, subT / 0.4f)
            tilt = a * (1f - p)
            eyes = 3
            mouth = 0.3f
            if (subT > 0.45f && !kicked) {
                kicked = true
                say("اوووف! سرم گیج رفت 😵‍💫" to "Ooof! I'm dizzy 😵‍💫", 1.6f)
                for (i in 0 until 3) {
                    spawn("💫", mx + rnd(-16f, 16f) * d, my - 124f * sc, rnd(-25f, 25f) * d, rnd(-40f, -20f) * d, 1f, 16f * d)
                }
            }
            if (subT > 1.5f) next()
        }
    }

    // ----- ball -----
    private fun updateBall(dt: Float) {
        if (!ballOn) return
        if (ballSkyShot) {
            // Final kick: leave through the top of the viewport, with no bounce or return.
            bx += bvx * dt
            by += bvy * dt
            bvx *= max(0f, 1f - 0.18f * dt)
            if (by < -42f * d) {
                ballOn = false
                ballSkyShot = false
            }
            return
        }
        bx += bvx * dt
        by += bvy * dt
        if (bx < marginX()) {
            bx = marginX()
            bvx = abs(bvx) * 0.6f
        } else if (bx > vw - marginX()) {
            bx = vw - marginX()
            bvx = -abs(bvx) * 0.6f
        }
        if (by < gTop) {
            by = gTop
            bvy = abs(bvy) * 0.6f
        } else if (by > maxY()) {
            by = maxY()
            bvy = -abs(bvy) * 0.6f
        }
        // v135: the connect button never stops the ball: it rolls along the red line right over it
        val w = wall
        if (w != null && bx > w.left && bx < w.right && by > w.top && ballSpeed() < 60f * d && !(act == Act.BALL && sub == 3)) {
            // it came to rest in front of the button: it rolls out sideways
            val toLeft = (bx - w.left) < (w.right - bx)
            val goLeft = if (toLeft) column(true) != null else column(false) == null
            bvx = (if (goLeft) -130f else 130f) * d
        }
        val damp = max(0f, 1f - 1.2f * dt)
        bvx *= damp
        bvy *= damp
        bvz -= 1500f * d * dt
        bz += bvz * dt
        if (bz <= 0f) {
            bz = 0f
            bvz = if (bvz < -80f * d) -bvz * 0.55f else 0f
        }
    }

    private fun ballSpeed() = hypot(bvx, bvy) + abs(bvz) * 0.3f

    /** A random free ground spot in the half of the screen where [fromX] is NOT (the other column of the connect button). Result in [tmp]. */
    private fun pickFarSpot(fromX: Float) {
        val right = fromX < vw / 2f
        val col = column(!right)
        val lo: Float
        val hi: Float
        if (col != null) {
            lo = col[0]
            hi = col[1]
        } else if (right) {
            lo = vw / 2f + 20f * d
            hi = vw - marginX()
        } else {
            lo = marginX()
            hi = vw / 2f - 20f * d
        }
        push(rnd(lo, max(hi, lo + 1f)), maxY() - rnd(0f, 4f) * d)   // v135: on the red line
    }

    private fun doKick() {
        // The second kick is the finale: send the ball steeply into the sky.
        // It exits the viewport and is removed there instead of rolling into a goal.
        if (kicks >= 1) {
            ballSkyShot = true
            ballFlying = false
            bvx = facing * 95f * d
            bvy = -780f * d
            bvz = 0f
            ballDir = facing
            kicks++
            say("چه شوت بلندی! 🚀" to "What a sky-high shot! 🚀", 1.5f)
            return
        }
        // First kick: send the ball to the far side so the monkey has to chase it.
        pickFarSpot(mx)
        val px = tmp[0]
        val py = tmp[1]
        val dx = px - bx
        val dy = py - by
        val n = max(1f, hypot(dx, dy))
        val sp = max(330f * d, 1.35f * n)   // far kicks are harder (the ball slows down on its own)
        bvx = dx / n * sp
        bvy = dy / n * sp
        val sb = sideOf(bx)
        val sp2 = sideOf(px)
        ballFlying = sb >= 0 && sp2 >= 0 && sb != sp2
        ballDir = if (dx >= 0f) 1 else -1
        bvz = 250f * d
        facing = if (dx >= 0f) 1 else -1
        kicks++
    }

    private fun actBall(dt: Float) {
        when (sub) {
            0 -> {
                if (kicks >= 2) {
                    // No goal and no chase: watch the final ball leave the screen.
                    cycle(dt, 8f, 0.7f)
                    armA1 = -115f
                    armA2 = 115f
                    eyes = 1
                    mouth = 0.65f
                    if (!ballOn) {
                        spawn("✨", mx, my - 72f * sc, 0f, -35f * d, 0.9f, 18f * d)
                        setSub(2)
                        say("رفت تو آسمون! 🚀" to "Off into the sky! 🚀", 1.5f)
                    }
                } else {
                    val dist = hypot(bx - mx, by - my)
                    if (dist > 22f * d) {
                        moveToward(bx, by, 190f * d, dt)
                        cycle(dt, 15f, 1.3f)
                        tilt = 7f
                    } else if (bz < 25f * d) {
                        if (!juggled) {
                            juggled = true
                            juggleN = 0
                            setSub(3)
                            say("روپایی! ⚽" to "Keepy-uppy! ⚽", 2f)
                        } else setSub(1)
                    }
                }
                if (t > 40f) {
                    ballOn = false
                    next()
                }
            }
            1 -> {
                val p = (subT / 0.3f).coerceIn(0f, 1f)
                liftB = 10f * sin(PI.toFloat() * p)
                footB = -8f + 26f * p
                armA1 = 40f
                armA2 = -40f
                mouth = 0.5f
                if (!kicked && subT >= 0.12f) {
                    kicked = true
                    doKick()
                }
                if (subT >= 0.3f) setSub(0)
            }
            3 -> {
                // v135: keepy-uppy: the ball bounces on his feet (left, right, left ...), then he shoots it
                bx = mx + facing * 8f * d
                by = my
                bvx = 0f
                bvy = 0f
                val per = 0.45f
                if (juggleN < 6 && subT >= juggleN * per) {
                    bz = max(bz, 0f)
                    bvz = 300f * d
                    juggleN++
                }
                val k = ((subT % per) / per * 2f).coerceAtMost(1f)
                val s2 = sin(PI.toFloat() * k)
                if (juggleN % 2 == 1) {
                    liftA = 9f * s2
                    footA = 14f * s2
                } else {
                    liftB = 9f * s2
                    footB = 14f * s2
                }
                armA1 = 40f
                armA2 = -40f
                mouth = 0.4f
                eyes = 1
                bob = abs(sin(subT * 14f)) * 1.5f
                if (subT >= 6 * per + 0.1f) setSub(1)
            }
            else -> {
                eyes = 1
                armA1 = -150f
                armA2 = 150f
                mouth = 0.8f
                bob = abs(sin(subT * 10f)) * 4f
                if (subT > 1.3f) next()
            }
        }
    }

    // ----- butterfly -----
    private fun updateButterfly(dt: Float) {
        if (!bfOn) return
        bt += dt
        if (bfCaught) {
            // he caught it: it sits between his raised hands
            val k = min(1f, dt * 8f)
            bfx += (mx - bfx) * k
            bfy += ((my - hop - lift - 134f * sc) - bfy) * k
            return
        }
        if (!bfLeaving) {
            // v134: after the first miss the butterfly gets tired: it glides back and flutters lazily just above his
            // reach, so a jump really brings his hands to it (no more butterfly that suddenly teleports into his hands)
            val tired = act == Act.BUTTERFLY && bfMiss >= 1 && bfCool <= 0f
            val txp: Float
            val typ: Float
            if (tired) {
                txp = mx + sin(bt * 2.1f) * 12f * d
                typ = my - 134f * sc - 20f * d + cos(bt * 2.3f) * 5f * d
            } else {
                txp = bcx + sin(bt * 3.1f) * 42f * d
                typ = bcy + cos(bt * 2.3f) * 16f * d
            }
            val k = min(1f, dt * (if (bfFast > 0f) 9f else 2.6f))
            bfFast = max(0f, bfFast - dt)
            bfx += (txp - bfx) * k
            bfy += (typ - bfy) * k
            // never flutter onto his face: stay above his head while he is right underneath
            if (!tired && act == Act.BUTTERFLY && abs(bfx - mx) < 40f * d) bfy = min(bfy, my - hop - lift - 126f * sc - 10f * d)
        } else {
            bfx += bfVx * dt
            bfy += bfVy * dt
        }
    }

    private val bfLines = listOf(
        "نشد! 😤" to "Missed! 😤",
        "یه بار دیگه! 💪" to "One more try! 💪",
        "چه تیزه! 😅" to "So quick! 😅",
        "وایسا دیگه! 😠" to "Hold still! 😠",
        "بیا اینجا پروانه! 🦋" to "Come here, butterfly! 🦋",
        "فرار نکن! 😩" to "Don't run away! 😩"
    )

    /** The butterfly slips away from him. */
    private fun butterflyFlee() {
        bfMiss++
        pickButterflySpot()
        bfFast = 0.8f
        bfNext = rnd(2.0f, 3.0f)
        bfCool = 0.9f
        bfDodgeT = -1f
        if (bubbleT <= 0f || Random.nextInt(100) < 40) say(bfLines[(bfMiss - 1) % bfLines.size], 1.5f)
    }

    /** He finally gets it: the butterfly lands between his hands. */
    private fun butterflyCatch() {
        bfCaught = true
        bfDodgeT = -1f
        if (hop == 0f) {   // a big jump: he grabs it
            hopG = 8f * 34f * d / (0.55f * 0.55f)
            hopV = hopG * 0.55f / 2f
        }
        setSub(2)
        // The catch line must appear on the exact frame the butterfly is caught,
        // not after an earlier line finishes speaking.
        sayNow(if (fa) "گرفتمت! 🦋✨" else "Got you! 🦋✨", 1.45f)
    }

    private fun actButterfly(dt: Float) {
        if (sub == 0) {
            // he runs after it (only inside his own column) and jumps for it - it always slips away
            // v132: he really goes to the butterfly, round the top of the button if it is on the other side
            val tired = bfMiss >= 1
            if (tired) moveToward(clampX(bfx), clampY(my), 150f * d, dt)
            else moveToward(clampX(bfx), clampY(bfy + 150f * sc), 150f * d, dt)
            cycle(dt, 12f, 1.1f)
            mouth = 0.3f
            bfCool -= dt
            bfNext -= dt
            if (bfNext <= 0f) {
                bfNext = rnd(2.2f, 3.2f)
                pickButterflySpot(if (bcx >= vw / 2f) 1 else -1)   // it keeps to its own side while he is running over
            }
            hopT -= dt
            if (!tired) {
                if (hopT <= 0f && hop == 0f && abs(bfx - mx) < 130f * d) {
                    hopT = rnd(0.9f, 1.5f)
                    hopG = 8f * 34f * d / (0.55f * 0.55f)
                    hopV = hopG * 0.55f / 2f
                    bfDodgeT = 0.22f   // a grab attempt: just before he gets it, it darts away
                }
                if (bfDodgeT > 0f) {
                    bfDodgeT -= dt
                    if (bfDodgeT <= 0f) butterflyFlee()   // the first grab always misses
                } else if (bfCool <= 0f && abs(bfx - mx) < 60f * d) {
                    butterflyFlee()
                }
            } else if (bfCool <= 0f) {
                // v134: he jumps when it flutters right above him, and catches it only when his hands really reach it
                if (hopT <= 0f && hop == 0f && abs(bfx - mx) < 40f * d) {
                    if (bfMiss == 1) {
                        bfMiss = 2
                        say(bfLines[1], 1.5f)   // "One more try!" right before the second grab
                    }
                    hopT = rnd(0.9f, 1.4f)
                    hopG = 8f * 34f * d / (0.55f * 0.55f)
                    hopV = hopG * 0.55f / 2f
                }
                if (hop > 10f * d && hypot(bfx - mx, bfy - (my - hop - lift - 134f * sc)) < 22f * d) {
                    butterflyCatch()
                    return
                }
            }
            if (hop > 0f) {
                armA1 = -150f
                armA2 = 150f
                mouth = 0.7f
            }
            if (subT > 14f) {
                // v135: it never just flies away: in the end he always catches it (then lets it go)
                butterflyCatch()
                return
            }
        } else if (sub == 2) {
            // v132: the butterfly is on him: arms up, happy, hearts
            armA1 = -150f
            armA2 = 150f
            eyes = 1
            mouth = 0.6f
            tilt = sin(subT * 5f) * 3f
            if (!kicked && subT > 0.3f) {
                kicked = true
                spawnHearts(5)
            }
            if (subT > 2.2f) {
                bfCaught = false
                bfLeaving = true
                bfVx = (if (mx < vw / 2f) 200f else -200f) * d
                bfVy = -110f * d
                setSub(1)
                say("برو خوش باش! 🦋💕" to "Go on, fly free! 🦋💕", 1.8f)
            }
        } else {
            armA2 = 150f + sin(subT * 14f) * 25f
            eyes = 2
            if (subT > 1.6f) {
                bfOn = false
                next()
            }
        }
    }

    // ----- sit on a real button and bounce -----
    private fun actSit(dt: Float) {
        when (sub) {
            0 -> {
                squash *= 0.8f
                armA1 = -25f
                armA2 = 25f
                if (subT > 0.15f) {
                    val v = sitView
                    val r = if (v != null) rectOf(v) else null
                    if (v == null || r == null) {
                        next()
                    } else {
                        launch(r.centerX() + sitOx, r.top - 3f * d, 0.7f, 45f * d)
                        setSub(1)
                    }
                }
            }
            1 -> {
                armA1 = -150f
                armA2 = 150f
                eyes = 1
                mouth = 0.6f
                if (justLanded) {
                    setSub(2)
                    say(jumpLines.filterNot { it.second.contains("again") }.random(), 2f)   // not "again" on the first jump
                    sitView?.let { poke(it) }
                }
            }
            2 -> {
                val v = sitView
                val r = if (v != null) rectOf(v) else null
                if (v == null || r == null) {
                    next()
                    return
                }
                mx = r.centerX() + sitOx
                my = r.top - 3f * d
                if (hop == 0f && hopV == 0f) {
                    sitHopT -= dt
                    if (sitHopT <= 0f) {
                        sitHopN++
                        if (sitHopN % 4 == 0) {
                            // show-off: a big hop with a full backflip
                            sitFlip = true
                            sitFlightT = 0.64f
                            sitHopStart = subT
                            hopG = 8f * 48f * d / (sitFlightT * sitFlightT)
                            hopV = hopG * sitFlightT / 2f
                            say(flipLines.random(), 1.7f)
                        } else {
                            sitFlip = false
                            hopG = 8f * 20f * d / 0.25f
                            hopV = hopG * 0.5f / 2f
                            if (sitHopN % 3 == 2 && bubbleT <= 0f) say(jumpLines.random(), 2f)
                        }
                        sitHopT = 0.02f
                    }
                }
                if (justLanded) {
                    poke(v)
                    if (sitFlip) {
                        sitFlip = false
                        spawn("✨", mx, my - 90f * d, 0f, -30f * d, 0.9f, 18f * d)
                    }
                }
                val up = hop > 0f
                if (sitFlip && up) tilt = -360f * ((subT - sitHopStart) / sitFlightT).coerceIn(0f, 1f)
                armA1 = if (up) -110f else 20f
                armA2 = if (up) 110f else 20f
                eyes = 1
                mouth = if (up) 0.8f else 0.3f
                if (subT > 5.4f) begin(Act.JUMP)
            }
        }
    }

    // ----- peek-a-boo from the edge of the screen -----
    private fun actPeek(dt: Float) {
        when (sub) {
            0 -> {
                val arrived = moveToward(hideX, peekY, 220f * d, dt)
                cycle(dt, 17f, 1.5f)
                tilt = 9f
                if (arrived || t > 7f) {
                    mx = hideX
                    setSub(1)
                }
            }
            1 -> {
                mx = hideX
                if (subT > 0.9f) setSub(2)
            }
            2 -> {
                val p = (subT / 0.45f).coerceIn(0f, 1f)
                mx = hideX + (shownX - hideX) * p
                facing = if (peekLeft) 1 else -1
                lookX = 1f
                if (subT >= 0.45f) setSub(3)
            }
            3 -> {
                mx = shownX
                facing = if (peekLeft) 1 else -1
                lookX = sin(subT * 3f)
                bob = abs(sin(subT * 5f)) * 1.5f
                if (subT > 1.4f) {
                    val inner = if (peekLeft) shownX + 70f * d else shownX - 70f * d
                    push(inner, peekY)
                    launch(tmp[0], tmp[1], 0.5f, 30f * d)
                    setSub(4)
                    say("بو! 👀" to "Boo! 👀", 1.6f)
                }
            }
            4 -> {
                armA1 = -150f
                armA2 = 150f
                eyes = 1
                mouth = 1f
                if (justLanded) setSub(5)
            }
            else -> {
                eyes = 1
                mouth = 0.6f
                if (subT > 0.3f) next()
            }
        }
    }

    // ----- run off one side of the screen completely, come back in from the other side -----
    private fun actCross(dt: Float) {
        // This is a deliberate horizontal edge-crossing on the red baseline. Do not route
        // it through the generic obstacle navigator: that can keep selecting the same
        // button corner and make the monkey look stuck beside the ping/number area.
        my = maxY()
        when (sub) {
            0 -> {
                val edge = if (crossRight) vw + 55f * sc else -55f * sc
                val dx = edge - mx
                val step = 230f * d * dt
                mx = if (abs(dx) <= step) edge else mx + kotlin.math.sign(dx) * step
                cycle(dt, 16f, 1.4f)
                tilt = 8f
                mouth = 0.3f
                if (abs(edge - mx) < 1f) setSub(1)
            }
            1 -> {
                // Fully outside the viewport: remain invisible briefly, then re-enter
                // from the opposite edge on the same baseline.
                mx = if (crossRight) vw + 55f * sc else -55f * sc
                if (subT > 0.85f) {
                    mx = if (crossRight) -55f * sc else vw + 55f * sc
                    val cw2 = wall
                    tx = if (cw2 != null && cw2.left > marginX() + 4f * d && crossRight) {
                        rnd(marginX() + 8f * d, cw2.left - 4f * d)
                    } else if (cw2 != null && cw2.right < vw - marginX() - 4f * d && !crossRight) {
                        rnd(cw2.right + 4f * d, vw - marginX() - 8f * d)
                    } else {
                        if (crossRight) marginX() + 12f * d else vw - marginX() - 12f * d
                    }
                    tx = clampX(tx)
                    ty = maxY()
                    setSub(2)
                    say("از اون طرف اومدم! 😄" to "Back from the other side! 😄", 2f)
                }
            }
            else -> {
                val dx = tx - mx
                val step = 230f * d * dt
                mx = if (abs(dx) <= step) tx else mx + kotlin.math.sign(dx) * step
                cycle(dt, 16f, 1.4f)
                tilt = 8f
                mouth = 0.4f
                if (abs(tx - mx) < 1f) next()
            }
        }
    }

    private fun actGoodbye(dt: Float) {
        if (sub == 0) {
            armA2 = 150f + sin(subT * 14f) * 28f
            eyes = 1
            mouth = 0.8f
            if (subT > 0.9f) {
                setSub(1)
                spawnPoof()
            }
        } else {
            val p = (subT / 0.7f).coerceIn(0f, 1f)
            drawScale = byeScale * max(0f, 1f - p)
            tilt = 720f * p
            lift = sin(PI.toFloat() * p) * 25f * d
            eyes = 1
            armA1 = -150f
            armA2 = 150f
            if (p >= 1f) {
                showing = false
                running = false
                removeCallbacks(tick)
            }
        }
    }

    // ================= ten extra tricks =================

    // 1. backflip: crouch, then a high jump backwards with a full backwards somersault
    private fun actBackflip() {
        when (sub) {
            0 -> {
                squash *= 0.78f
                armA1 = -25f
                armA2 = 25f
                if (subT > 0.2f) {
                    val f0 = facing
                    push(clampX(mx - f0 * 55f * d), my)
                    if (segHitsWall(mx, my, tmp[0], tmp[1])) {
                        tmp[0] = mx
                        tmp[1] = my
                    }
                    launch(tmp[0], tmp[1], 0.8f, 46f * d)
                    facing = f0
                    setSub(1)
                }
            }
            1 -> {
                tilt = -360f * (subT / 0.8f).coerceIn(0f, 1f)
                armA1 = -150f
                armA2 = 150f
                eyes = 1
                mouth = 0.6f
                if (justLanded) {
                    setSub(2)
                    say("ایول! 😎" to "Nailed it! 😎", 1.4f)
                }
            }
            else -> {
                eyes = 1
                mouth = 0.5f
                armA1 = -150f
                armA2 = 150f
                if (subT > 0.6f) next()
            }
        }
    }

    // 2. flexing like a bodybuilder (two poses)
    private fun actFlex(dt: Float) {
        val pulse = sin(subT * 30f)
        val strong = (subT / 1.2f).toInt() % 2 == 0
        footA = -8f
        footB = 8f
        eyes = 0
        mouth = 0.15f
        tilt = pulse * 1.6f
        squash = 1.03f
        if (strong) {
            armA1 = -112f
            armA2 = 112f
            armLen2 = 27f + pulse * 1.5f
        } else {
            armA1 = -50f
            armA2 = 50f
        }
        noteT -= dt
        if (noteT <= 0f) {
            noteT = 0.6f
            spawn(
                if (Random.nextBoolean()) "💪" else "✨",
                mx + rnd(-30f, 30f) * d, my - 100f * d, rnd(-15f, 15f) * d, -40f * d, 1.2f, 18f * d
            )
        }
        if (subT > 3.6f) next()
    }

    // 3. moonwalk with sunglasses: slides backwards while facing the other way
    private fun actMoonwalk(dt: Float) {
        shades = true
        facing = -mwDir
        if (sub == 0) {
            val rem = tx - mx
            val stp = 75f * d * dt
            if (abs(rem) <= stp) {
                mx = tx
                setSub(1)
                spawn("✨", mx, my - 90f * d, 0f, -30f * d, 0.9f, 18f * d)
            } else {
                mx += (if (rem > 0f) 1f else -1f) * stp
            }
            legPh += dt * 7f
            val s = sin(legPh)
            val c = cos(legPh)
            footA = s * 9f
            footB = -footA
            liftA = max(0f, c) * 2.5f
            liftB = max(0f, -c) * 2.5f
            armA1 = 20f
            armA2 = 155f
            tilt = -4f
            bob = abs(s) * 1.2f
            eyes = 1
            mouth = 0.3f
            noteT -= dt
            if (noteT <= 0f) {
                noteT = 0.5f
                spawn("✨", mx + rnd(-20f, 20f) * d, my - rnd(10f, 70f) * d, 0f, -25f * d, 0.8f, 14f * d)
            }
            if (t > 9f) setSub(1)
        } else {
            armA1 = -150f
            armA2 = 150f
            eyes = 1
            mouth = 0.6f
            bob = abs(sin(subT * 9f)) * 2f
            if (subT > 0.9f) next()
        }
    }

    // 4. kung-fu: punches, a kick and a victory pose
    private val punchLines = listOf(
        "هیااا! 🥊" to "Hiyaa! 🥊",
        "بزن بزن! 💥" to "Bam bam! 💥",
        "این یکی محکم بود! 💪" to "That was a strong one! 💪",
        "تحمل کن کیسه! 😤" to "Take it, bag! 😤"
    )

    // boxes the big connect button like a punching bag: punches and kicks, the button swings
    private fun actPunch(dt: Float) {
        if (sub == 0) {
            val arrived = moveToward(tx, ty, 150f * d, dt)
            cycle(dt, 12f, 1.2f)
            if (arrived || t > 8f) {
                facing = if (punchSide == 0) 1 else -1
                setSub(1)
            }
            return
        }
        val ph = 0.34f
        val k = (subT / ph).toInt()
        val f = (subT - k * ph) / ph
        val ext = sin(PI.toFloat() * f)
        if (k != punchK) {
            punchK = k
            kicked = false
            if (k == 2 || k == 6) say(punchLines.random(), 1.2f)
        }
        facing = if (punchSide == 0) 1 else -1
        footA = -7f
        footB = 7f
        squash = 0.93f
        eyes = 0
        mouth = 0.5f
        armA1 = 35f
        armA2 = 35f
        armLen2 = 20f
        tilt = facing * 7f * ext     // v185: he leans into every punch
        lift = 2.5f * d * ext
        var power = 0f
        when (k) {
            0, 2, 5 -> {
                armA2 = 40f + 100f * ext      // uppercut towards the button above him
                armLen2 = 18f + 18f * ext
                power = 1f
            }
            1, 3, 6 -> {
                armA1 = 40f + 100f * ext
                power = 1f
            }
            4, 7 -> {
                armA1 = 40f + 100f * ext      // double uppercut, feet stay on the line
                armA2 = 40f + 100f * ext
                armLen2 = 18f + 18f * ext
                squash = 0.9f
                power = 1.8f
            }
            8 -> {
                armA1 = -150f
                armA2 = 150f
                eyes = 1
                mouth = 0.9f
                footA = -10f
                footB = 10f
                if (!kicked) {
                    kicked = true
                    say("آخیش! 😅" to "Phew! 😅", 1.4f)
                }
            }
            else -> {
                eyes = 1
                if (subT > 9.8f * ph) next()
            }
        }
        if (power > 0f && f > 0.45f && !kicked) {
            kicked = true
            val ar = avoidCache
            val hitX = mx + facing * 16f * sc
            val hitY = if (ar != null) {
                val rr = min(ar.width(), ar.height()) / 2f
                val dx = (hitX - ar.centerX()).coerceIn(-rr * 0.95f, rr * 0.95f)
                ar.centerY() + sqrt(rr * rr - dx * dx) - 4f * d
            } else my - 96f * sc
            spawn("💥", hitX, hitY, 0f, -20f * d, 0.5f, 20f * d)
            spawn("✨", hitX + facing * 6f * d, hitY - 12f * d, facing * 40f * d, -34f * d, 0.6f, 14f * d)
            spawn("⭐", hitX - facing * 4f * d, hitY + 4f * d, -facing * 30f * d, -18f * d, 0.55f, 12f * d)
            bagW += (if (k % 2 == 0) -1f else 1f) * 45f * power   // the button gives a small shake left and right like a boxing bag
        }
    }

    private fun actKungfu() {
        val ph = 0.42f
        val k = (subT / ph).toInt()
        val f = (subT - k * ph) / ph
        val ext = sin(PI.toFloat() * f)
        if (k != sub) {
            sub = k
            kicked = false
            if (k == 6) say("هیااااا! 🥋" to "Hiyaaa! 🥋", 1.4f)
        }
        footA = -7f
        footB = 7f
        squash = 0.92f
        eyes = 0
        mouth = 0.5f
        armA1 = 35f
        armA2 = 35f
        armLen2 = 20f
        val hx = mx + facing * 48f * sc
        when (k) {
            0 -> mouth = 0.1f
            1, 4 -> {
                armA2 = 40f + 48f * ext
                armLen2 = 18f + 18f * ext
                if (f > 0.45f && !kicked) {
                    kicked = true
                    spawn("💥", hx, my - 62f * sc, 0f, -20f * d, 0.5f, 20f * d)
                }
            }
            2, 5 -> {
                armA1 = 40f + 48f * ext
                if (f > 0.45f && !kicked) {
                    kicked = true
                    spawn("💥", hx, my - 62f * sc, 0f, -20f * d, 0.5f, 20f * d)
                }
            }
            3 -> {
                footB = 7f + 22f * ext
                liftB = 14f * ext
                tilt = -12f * ext
                armA1 = -50f
                armA2 = 60f
                if (f > 0.45f && !kicked) {
                    kicked = true
                    spawn("💥", mx + facing * 34f * sc, my - 14f * sc, 0f, -20f * d, 0.5f, 20f * d)
                }
            }
            else -> {
                armA1 = -150f
                armA2 = 150f
                eyes = 1
                mouth = 0.9f
                footA = -10f
                footB = 10f
            }
        }
        if (subT > 7f * ph) next()
    }

    // 5. jumping jacks, counting out loud
    private fun actJacks() {
        val per = 0.55f
        val n = (subT / per).toInt()
        val u = (subT - n * per) / per
        val open = 0.5f - 0.5f * cos(2f * PI.toFloat() * u)
        if (n < 6 && n + 1 != sub) {
            sub = n + 1
            say((if (fa) "۱۲۳۴۵۶"[n] else "123456"[n]).toString(), 0.5f)
        }
        armA1 = -(6f + 170f * open)
        armA2 = 6f + 170f * open
        footA = -(3f + 11f * open)
        footB = 3f + 11f * open
        lift = 9f * d * open
        bob = open * 2f
        eyes = 1
        mouth = 0.5f
        if (n >= 6) next()
    }

    // 6. pirouette (fake 3D spin) and then a little dizzy wobble
    private fun actSpin(dt: Float) {
        if (sub == 0) {
            val dur = 2.4f
            val p = (subT / dur).coerceIn(0f, 1f)
            val e = p * p * (3f - 2f * p)
            spinX = cos(6f * PI.toFloat() * e)
            armA1 = -88f
            armA2 = 88f
            footA = -3f
            footB = 3f
            lift = sin(PI.toFloat() * p) * 12f * d
            eyes = 1
            mouth = 0.7f
            noteT -= dt
            if (noteT <= 0f) {
                noteT = 0.3f
                spawn("💫", mx + rnd(-26f, 26f) * d, my - 95f * d, rnd(-30f, 30f) * d, -30f * d, 0.9f, 16f * d)
            }
            if (subT >= dur) {
                setSub(1)
                say("سرم گیج رفت... 😵" to "So dizzy... 😵", 1.6f)
            }
        } else {
            val k = max(0f, 1f - subT / 1.3f)
            tilt = sin(subT * 8f) * 14f * k
            eyes = 2
            mouth = 0.4f
            armA1 = 20f
            armA2 = 20f
            if (subT > 1.3f) next()
        }
    }

    // 7. sneeze: builds up "aah... aah...", then ACHOO and wipes the nose
    private fun actSneeze() {
        when (sub) {
            0 -> {
                val p = (subT / 1.5f).coerceIn(0f, 1f)
                armA1 = 6f + 40f * p
                armA2 = 6f + 40f * p
                tilt = -14f * p + sin(subT * 16f) * 1.5f * p
                eyes = 2
                mouth = 0.2f + 0.7f * p
                squash = 1f + 0.03f * p
                if (subT >= 1.5f) {
                    setSub(1)
                    say("هاچی! 🤧" to "Achoo! 🤧", 1.6f)
                    for (i in 0 until 5) {
                        spawn(
                            "💦", mx + facing * 22f * d, my - 78f * d,
                            facing * rnd(60f, 130f) * d, rnd(-30f, 20f) * d, 0.7f, 16f * d
                        )
                    }
                    hopG = 1800f * d
                    hopV = 180f * d
                }
            }
            1 -> {
                tilt = 22f * max(0f, 1f - subT / 0.35f)
                eyes = 2
                mouth = 1f
                armA1 = -40f
                armA2 = 40f
                if (subT > 0.7f) setSub(2)
            }
            else -> {
                armA2 = 150f + sin(subT * 16f) * 10f
                eyes = 1
                mouth = 0.3f
                if (subT > 1.1f) next()
            }
        }
    }

    // 8. sneaking on tiptoes with a finger on the lips, looking around
    private fun actSneak(dt: Float) {
        val arrived = moveToward(tx, ty, 42f * d, dt)
        cycle(dt, 5.5f, 0.7f)
        liftA *= 1.8f
        liftB *= 1.8f
        squash = 0.9f
        tilt = 9f
        armA1 = 6f
        armA2 = 150f
        eyes = 0
        mouth = 0f
        lookX = sin(subT * 2.6f)
        noteT -= dt
        if (noteT <= 0f) {
            noteT = 1.6f
            spawn("🤫", mx + facing * 20f * d, my - 100f * d, 0f, -25f * d, 1f, 16f * d)
        }
        if (arrived || t > 8f) next()
    }

    // 9. meditation: sits cross-legged, levitates a little and glows
    private fun actMeditate(dt: Float) {
        val ramp = (subT / 0.8f).coerceIn(0f, 1f)
        squash = 1f - 0.2f * ramp
        footA = -12f * ramp
        footB = 12f * ramp
        armA1 = 6f + 34f * ramp
        armA2 = 6f + 34f * ramp
        eyes = 2
        mouth = 0.1f
        lift = (7f + 3f * sin(subT * 2.2f)) * d * ramp
        aura = ramp
        zT -= dt
        if (zT <= 0f) {
            zT = 0.7f
            spawn(
                when (Random.nextInt(3)) {
                    0 -> "✨"
                    1 -> "🌸"
                    else -> "🕉️"
                },
                mx + rnd(-22f, 22f) * d, my - 80f * d, rnd(-12f, 12f) * d, -34f * d, 1.5f, 16f * d
            )
        }
        if (subT > 5f) next()
    }

    // 10. headspin (break-dance): upside down on its head, legs in a V, spinning around
    private fun actHeadspin() {
        val dur = 4.2f
        val up = (subT / 0.45f).coerceIn(0f, 1f)
        val down = ((dur - subT) / 0.45f).coerceIn(0f, 1f)
        val p = min(up, down)
        tilt = 180f * p
        lift = 27f * sc * p
        val sp = ((subT - 0.45f) / (dur - 0.9f)).coerceIn(0f, 1f)
        val e = sp * sp * (3f - 2f * sp)
        spinX = cos(6f * PI.toFloat() * e)
        armA1 = -100f * p
        armA2 = 100f * p
        footA = (-12f + sin(subT * 10f) * 5f) * p
        footB = (12f - sin(subT * 10f) * 5f) * p
        eyes = if (p > 0.5f) 3 else 1
        mouth = 0.7f
        if (subT > dur) next()
    }

    // ================= v122: brawl, touch reactions, genius =================

    private fun snapFrom(m: Mk) {   // m -> the live fields drawMonkey() reads
        mx = m.x; my = m.y; lift = m.lift; facing = m.facing
        footA = m.footA; footB = m.footB; liftA = m.liftA; liftB = m.liftB
        armA1 = m.armA1; armA2 = m.armA2; armLen2 = m.armLen2
        tilt = m.tilt; squash = m.squash; mouth = m.mouth; eyes = m.eyes; bob = m.bob
        pivotY = m.pivotY; angry = m.angry; lookX = m.lookX; spinX = m.spinX
    }

    private fun snapTo(m: Mk) {     // live fields -> m
        m.x = mx; m.y = my; m.lift = lift; m.facing = facing
        m.footA = footA; m.footB = footB; m.liftA = liftA; m.liftB = liftB
        m.armA1 = armA1; m.armA2 = armA2; m.armLen2 = armLen2
        m.tilt = tilt; m.squash = squash; m.mouth = mouth; m.eyes = eyes; m.bob = bob
        m.pivotY = pivotY; m.angry = angry; m.lookX = lookX; m.spinX = spinX
    }

    private fun brSub(n: Int) {
        setSub(n)
        brLine = 0
    }

    /** Follows the button the monkeys fight on (it moves when the page is scrolled). */
    private fun brArena() {
        val v = brView ?: return
        val r = rectOf(v) ?: return
        brX = r.centerX()
        brY = r.top - 3f * d
        brHalf = max(14f * d, r.width() / 2f - 36f * d)
    }

    private fun rivalSay(p: Pair<String, String>, dur: Float = 2f) {
        bub2 = if (fa) p.first else p.second
        val d2 = readTime(bub2 ?: "", dur)
        bub2Dur = d2
        bub2T = d2
    }

    /** who: 0 = the hero speaks, 1 = the rival speaks. */
    private fun brSay(who: Int, p: Pair<String, String>, dur: Float = 1.8f) {
        if (who == 0) say(p, dur) else rivalSay(p, dur)
    }

    private fun actBrawl(dt: Float) {
        brArena()
        val s = brSide
        val hx = brX - s * brSpread     // where the hero stands
        val rx = brX + s * brSpread     // where the rival lands
        if (sub == 0) {
            // the hero crouches and leaps onto the button
            squash *= 0.8f
            armA1 = -25f
            armA2 = 25f
            facing = s
            if (subT > 0.18f) {
                launch(hx, brY, 0.7f, 45f * d)
                facing = s
                buddyOn = true
                mb.reset()
                mb.x = rivalStartX
                mb.y = brY
                brSub(1)
            }
            return
        }
        if (sub == 1) {
            // the rival flies in from the side of the screen with a somersault
            armA1 = -150f
            armA2 = 150f
            eyes = 1
            mouth = 0.6f
            val p = ((subT - 0.25f) / 1.0f).coerceIn(0f, 1f)
            mb.reset()
            mb.x = rivalStartX + (rx - rivalStartX) * p
            mb.y = brY
            mb.lift = 4f * p * (1f - p) * 90f * d
            mb.facing = -s
            mb.tilt = 360f * p
            mb.armA1 = -150f
            mb.armA2 = 150f
            mb.mouth = 0.9f
            mb.angry = true
            if (p >= 0.18f && brLine == 0) {
                brLine = 1
                sayNow("حریفم رسید! 🥊", 1.45f)
            }
            if (p >= 1f && hop == 0f && !airMove) {
                mb.squash = 0.8f
                spawn("💨", rx, brY - 4f * d, 0f, -20f * d, 0.7f, 18f * d)
                brSub(2)
            }
            return
        }

        // from here on this function drives both monkeys
        ma.reset()
        mb.reset()
        ma.facing = s
        mb.facing = -s
        val u = subT
        var cx = brX
        var gap = brSpread         // half the distance between them
        var ax = Float.NaN
        var bx2 = Float.NaN
        var ay0 = brY
        var by0 = brY
        var jump = 0f
        var cloudTarget = 0f
        var finished = false
        val winner = brWinner
        val loser = 1 - brWinner
        when (sub) {
            2 -> {
                // face to face, shaking fists
                val sh = sin(u * 14f)
                ma.armA1 = 100f + sh * 20f
                ma.armA2 = 120f - sh * 20f
                mb.armA1 = 100f - sh * 20f
                mb.armA2 = 120f + sh * 20f
                ma.angry = true
                mb.angry = true
                ma.mouth = 0.5f
                mb.mouth = 0.5f
                ma.tilt = 6f + sh * 2f
                mb.tilt = 6f - sh * 2f
                ma.bob = abs(sin(u * 10f)) * 2f
                mb.bob = abs(sin(u * 10f + 1f)) * 2f
                ma.footA = -6f
                ma.footB = 6f
                mb.footA = -6f
                mb.footB = 6f
                if (brLine == 0 && u > 0.1f) {
                    brLine = 1
                    say((if (brView != null) dkTauntHero else dkTauntHeroFloor).next(), 1.8f)
                }
                if (brLine == 1 && u > 0.95f) {
                    brLine = 2
                    rivalSay((if (brView != null) dkTauntRival else dkTauntRivalFloor).next(), 1.8f)
                }
                if (u > 2.0f) brSub(3)
            }
            3 -> {
                val shoveEnd = 1.3f
                ma.angry = true
                mb.angry = true
                if (u < shoveEnd) {
                    // shoving: they lean into each other and push back and forth
                    val sw = sin(u * 20f)
                    cx = brX + sin(u * 3.4f) * 10f * d
                    gap = (13f + 3f * sw) * d
                    ma.tilt = 14f + sw * 4f
                    mb.tilt = 14f - sw * 4f
                    ma.armA1 = 75f + sw * 12f
                    ma.armA2 = 95f - sw * 12f
                    mb.armA1 = 75f - sw * 12f
                    mb.armA2 = 95f + sw * 12f
                    ma.footA = sw * 8f
                    ma.footB = -sw * 8f
                    mb.footA = -sw * 8f
                    mb.footB = sw * 8f
                    ma.mouth = 0.6f
                    mb.mouth = 0.6f
                    if (brLine == 0 && u > 0.2f) {
                        brLine = 1
                        say(dkStart.next(), 1.6f)
                    }
                } else {
                    // a rolling ball of fur: they tumble around each other, bouncing on the button
                    val v = u - shoveEnd
                    brTheta = v * 8.5f
                    cx = brX + sin(v * 1.9f) * brHalf
                    jump = abs(sin(v * 5.5f)) * 24f * d
                    val rr = 10f * d
                    val cs = cos(brTheta)
                    val sn = sin(brTheta)
                    ax = cx + cs * rr
                    bx2 = cx - cs * rr
                    ay0 = brY + sn * 3f * d
                    by0 = brY - sn * 3f * d
                    ma.tilt = brTheta * 57.3f
                    mb.tilt = brTheta * 57.3f + 180f
                    ma.lift = jump + 22f * sc
                    mb.lift = jump + 22f * sc
                    val fl = sin(v * 21f)
                    ma.armA1 = 100f + fl * 60f
                    ma.armA2 = 100f - fl * 60f
                    mb.armA1 = 100f - fl * 60f
                    mb.armA2 = 100f + fl * 60f
                    ma.footA = fl * 12f
                    ma.footB = -fl * 12f
                    mb.footA = -fl * 12f
                    mb.footB = fl * 12f
                    ma.eyes = 2
                    mb.eyes = 2
                    ma.mouth = 0.9f
                    mb.mouth = 0.9f
                    cloudTarget = min(1f, v / 0.3f)
                    noteT -= dt
                    if (noteT <= 0f) {
                        noteT = 0.22f
                        spawn(
                            arrayOf("💥", "💢", "⭐", "💫").random(),
                            cx + rnd(-26f, 26f) * d, brY - rnd(20f, 80f) * d - jump,
                            rnd(-50f, 50f) * d, rnd(-60f, -10f) * d, 0.7f, rnd(16f, 22f) * d
                        )
                    }
                    if (brLine == 1 && v > 0.5f) {
                        brLine = 2
                        rivalSay(dkFightRival.next(), 1.6f)
                    }
                    if (brLine == 2 && v > 1.7f) {
                        brLine = 3
                        say(dkFightHero.next(), 1.6f)
                    }
                    if (brLine == 3 && v > 2.9f) {
                        brLine = 4
                        rivalSay(dkFightRival.next(), 1.6f)
                    }
                    if (v > 4.3f) {
                        spawn("💥", cx, brY - 50f * sc, 0f, -20f * d, 0.6f, 26f * d)
                        brSub(4)
                    }
                }
            }
            4 -> {
                // one of them wins and jumps for joy, the other lies there, dizzy
                val w = if (winner == 0) ma else mb
                val l = if (winner == 0) mb else ma
                w.armA1 = -150f
                w.armA2 = 150f
                w.eyes = 1
                w.mouth = 0.9f
                w.lift = abs(sin(u * 7f)) * 16f * d
                w.bob = abs(sin(u * 14f)) * 2f
                val fall = min(1f, u / 0.3f)
                l.tilt = -88f * fall
                l.lift = -20f * sc * fall
                l.eyes = 4
                l.mouth = 0.4f
                l.armA1 = 25f
                l.armA2 = 25f
                noteT -= dt
                if (noteT <= 0f) {
                    noteT = 0.5f
                    val lx = if (loser == 1) cx + s * gap else cx - s * gap
                    spawn("💫", lx + rnd(-14f, 14f) * d, brY - 52f * sc, 0f, -26f * d, 0.9f, 18f * d)
                }
                if (brLine == 0 && u > 0.2f) {
                    brLine = 1
                    brSay(winner, dkWin.next())
                }
                if (brLine == 1 && u > 1.0f) {
                    brLine = 2
                    brSay(loser, dkLose.next(), 1.6f)
                }
                if (u > 2.6f) brSub(5)
            }
            5 -> {
                // the loser gets up and they make peace with a handshake
                val up = min(1f, u / 0.5f)
                val l = if (winner == 0) mb else ma
                val w = if (winner == 0) ma else mb
                l.tilt = -88f * (1f - up)
                l.lift = -20f * sc * (1f - up)
                l.eyes = if (up < 0.6f) 4 else 1
                w.eyes = 1
                ma.mouth = 0.4f
                mb.mouth = 0.4f
                if (u > 0.9f) {
                    val hs = sin(u * 12f) * 6f
                    ma.armA1 = 8f
                    mb.armA1 = 8f
                    ma.armA2 = 88f + hs
                    mb.armA2 = 88f + hs
                    if (brLine == 2) {
                        brLine = 3
                        spawn("🤝", cx, brY - 62f * sc, 0f, -30f * d, 1.2f, 22f * d)
                    }
                }
                if (brLine == 0 && u > 0.7f) {
                    brLine = 1
                    brSay(winner, dkPeaceA.next(), 1.5f)
                }
                if (brLine == 1 && u > 1.4f) {
                    brLine = 2
                    brSay(loser, dkPeaceB.next(), 1.5f)
                }
                if (u > 2.6f) brSub(6)
            }
            else -> {
                // the rival waves and leaps off the screen, the hero waves bye
                val p = (u / 1.0f).coerceIn(0f, 1f)
                bx2 = rx + (rivalStartX - rx) * p
                by0 = brY
                mb.lift = 4f * p * (1f - p) * 70f * d
                mb.facing = if (rivalStartX < rx) -1 else 1
                mb.tilt = 360f * p
                mb.armA1 = -150f
                mb.armA2 = 150f
                mb.eyes = 1
                mb.mouth = 0.8f
                ma.armA2 = 150f + sin(u * 14f) * 28f
                ma.eyes = 1
                ma.mouth = 0.8f
                if (brLine == 0 && u > 0.15f) {
                    brLine = 1
                    say(dkBye.next(), 1.6f)
                }
                if (p >= 1f) buddyOn = false
                if (u > 1.7f) finished = true
            }
        }

        // v134: whoever is talking moves his mouth, so it is clear who is speaking
        if (bubbleT > 0f && bubbleText != null) ma.mouth = max(ma.mouth, 0.3f + 0.4f * abs(sin(t * 14f)))
        if (bub2T > 0f && bub2 != null) mb.mouth = max(mb.mouth, 0.3f + 0.4f * abs(sin(t * 14f + 1.3f)))
        if (ax.isNaN()) ax = cx - s * gap
        if (bx2.isNaN()) bx2 = cx + s * gap
        ma.x = ax
        ma.y = ay0
        mb.x = bx2
        mb.y = by0
        brCx = cx
        brCy = brY - 34f * sc - jump * 0.7f
        brCloud += (cloudTarget - brCloud) * min(1f, dt * 10f)
        snapFrom(ma)
        if (finished) {
            buddyOn = false
            brCloud = 0f
            brView = null
            next()
        }
    }

    // ----- touched: first he is offended ("don't touch me, I'm sensitive"), then he dances anyway -----
    private fun actTouched(dt: Float) {
        if (sub == 0) {
            angry = true
            armA1 = 62f
            armA2 = 62f
            tilt = sin(subT * 34f) * 2.5f
            squash *= 0.98f
            if (subT > 1.3f) {
                setSub(1)
                noteT = 0f
                say(danceLines.random(), 2.4f)
            }
        } else {
            actDance(dt)
        }
    }

    // ----- woozy: tapped a few times in a row, he gets dizzy and warns you -----
    private fun actWoozy() {
        tilt = sin(subT * 22f) * 10f
        eyes = 3
        mouth = 0.7f
        armA1 = -60f + sin(subT * 18f) * 15f
        armA2 = 60f - sin(subT * 18f) * 15f
        lookX = sin(subT * 25f)
        if (subT > 1.3f) next()
    }

    // ----- die: tapped too fast too often. Falls over, halo + ghost, then pops back to life -----
    private fun actDie(dt: Float) {
        when (sub) {
            0 -> {
                tilt = sin(subT * 38f) * 13f
                armA1 = -150f + sin(subT * 30f) * 20f
                armA2 = 150f - sin(subT * 30f) * 20f
                eyes = 3
                mouth = 1f
                if (subT > 1.0f) setSub(1)
            }
            1 -> {
                val p = (subT / 0.45f).coerceIn(0f, 1f)
                tilt = -90f * p
                lift = sin(PI.toFloat() * p) * 10f * d - 20f * sc * p
                armA1 = -150f * (1f - p) + 25f * p
                armA2 = 150f * (1f - p) + 25f * p
                eyes = 4
                mouth = 0.4f
                if (subT >= 0.45f) {
                    setSub(2)
                    squashK = 1f
                    zT = 0f
                    spawn("💨", mx, my - 4f * d, 0f, -20f * d, 0.7f, 18f * d)
                }
            }
            2 -> {
                tilt = -90f
                lift = -20f * sc
                armA1 = 25f
                armA2 = 25f
                eyes = 4
                mouth = 0.4f
                zT -= dt
                if (zT <= 0f) {
                    zT = 0.8f
                    spawn(
                        if (Random.nextBoolean()) "👻" else "😇",
                        mx - facing * 41f * sc, my - 50f * sc, rnd(-14f, 14f) * d, -50f * d, 1.8f, 24f * d
                    )
                }
                if (subT > 3.8f) {
                    setSub(3)
                    say(reviveLines.random(), 2.4f)
                }
            }
            else -> {
                val p = (subT / 0.35f).coerceIn(0f, 1f)
                tilt = -90f * (1f - p)
                lift = -20f * sc * (1f - p) + sin(PI.toFloat() * p) * 14f * d
                eyes = if (p < 1f) 3 else 1
                mouth = 0.8f
                armA1 = -150f
                armA2 = 150f
                if (subT > 1.8f) {
                    tapCount = 0
                    next()
                }
            }
        }
    }

    // ----- genius: finger on the temple, light bulbs -----
    private fun actGenius(dt: Float) {
        armA2 = 160f + sin(subT * 9f) * 7f
        eyes = 1
        mouth = 0.25f
        tilt = -3f + sin(subT * 2f) * 2f
        noteT -= dt
        if (noteT <= 0f) {
            noteT = 0.7f
            spawn(
                if (Random.nextBoolean()) "💡" else "🧠",
                mx + rnd(-22f, 22f) * d, my - 128f * d, 0f, -40f * d, 1.2f, 20f * d
            )
        }
        if (subT > 3.4f) next()
    }

    /** A tap on the monkey: 1 = offended + dance, 2 = ticklish, 3-4 = dizzy warning, 5 in a row = he dies. */
    private fun onTapped() {
        val now = SystemClock.uptimeMillis()
        tapCount = if (now - lastTapMs < 900L) tapCount + 1 else 1
        lastTapMs = now
        when {
            tapCount >= 5 -> begin(Act.DIE)
            tapCount >= 3 -> begin(Act.WOOZY)
            tapCount == 2 -> begin(Act.TOUCHED)
            else -> begin(Act.TOUCHED)
        }
    }

    // ---------------- touch: tap = pout + dance, fast taps = he dies, drag = pick the monkey up ----------------
    private fun hitMonkey(px: Float, py: Float): Boolean {
        val halfW = 26f * sc + 8f * d
        val top = my - hop - lift - 124f * sc
        val bottom = my - hop + 8f * d
        return px >= mx - halfW && px <= mx + halfW && py >= top - 8f * d && py <= bottom
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!showing || act == Act.GOODBYE || act == Act.DIE || (act == Act.ENTER && sub == 0)) return false
        val ey = e.y + scrollNow()   // touch position in page coordinates
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!hitMonkey(e.x, ey)) return false
                if (act == Act.THROWN) {   // caught in the air
                    tvx = 0f
                    tvy = 0f
                    tSpin = 0f
                }
                dragging = true
                moved = false
                lastMoveMs = SystemClock.uptimeMillis()
                lastMoveX = e.x
                lastMoveY = ey
                fingVx = 0f
                fingVy = 0f
                downX = e.x
                downY = ey
                grabDx = mx - e.x
                grabDy = my - ey
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return false
                if (!moved && (abs(e.x - downX) > 12f * d || abs(ey - downY) > 12f * d)) {
                    moved = true
                    ballOn = false
                    bfOn = false
                    begin(Act.DRAG)
                }
                if (moved) {
                    mx = (e.x + grabDx).coerceIn(0f, vw)
                    my = (ey + grabDy).coerceIn(minY(), maxY())
                    // v135: no pushing out of the connect button while he is carried: he can go over it
                }
                // finger speed (px/s), smoothed: used to throw him when he is let go
                val nowMs = SystemClock.uptimeMillis()
                val dtm = (nowMs - lastMoveMs) / 1000f
                if (dtm > 0.004f) {
                    fingVx = fingVx * 0.4f + ((e.x - lastMoveX) / dtm) * 0.6f
                    fingVy = fingVy * 0.4f + ((ey - lastMoveY) / dtm) * 0.6f
                    lastMoveMs = nowMs
                    lastMoveX = e.x
                    lastMoveY = ey
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) return false
                dragging = false
                if (moved || act == Act.THROWN) {
                    val idle = SystemClock.uptimeMillis() - lastMoveMs > 90L
                    val sp = if (idle) 0f else hypot(fingVx, fingVy)
                    if (moved && sp > 240f * d) {
                        // v132: a flick: he is thrown and flies around
                        val cap = 1500f * d
                        val kk = if (sp > cap) cap / sp else 1f
                        tvx = fingVx * kk
                        tvy = fingVy * kk
                        begin(Act.THROWN)
                    } else {
                        val fromY = my
                        my = clampY(my)
                        push(mx, my)
                        mx = tmp[0]
                        my = tmp[1]
                        begin(Act.DROP)
                        hop += max(0f, my - fromY)   // he falls from where he was let go
                    }
                } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                    onTapped()
                }
                return true
            }
        }
        return false
    }

    // ---------------- drawing ----------------
    override fun onDraw(c: Canvas) {
        if (!showing || vw <= 0f) return
        // the monkey lives in the page: when the page is scrolled he moves with it
        c.save()
        c.translate(0f, -scrollNow())

        // ground shadows
        drawShadow(c, mx, my, hop + lift, drawScale)
        if (buddyOn) drawShadow(c, mb.x, mb.y, mb.lift, 1f)

        if (act == Act.SWING && swMode == 0 && sub >= 0 && sub <= 2) drawBar(c)
        if (ballOn && by <= my) drawBall(c)
        if (aura > 0f) drawAura(c)
        if (brCloud > 0f) drawCloud(c, false)
        if (buddyOn && mb.y < my) drawRival(c)
        drawMonkey(c)
        if (buddyOn && mb.y >= my) drawRival(c)
        if (brCloud > 0f) drawCloud(c, true)
        if (ballOn && by > my) drawBall(c)
        if (bfOn) drawButterfly(c)
        if (act == Act.DIE && sub == 2) drawHalo(c)
        drawParticles(c)
        drawBubble(c)
        c.restore()
    }

    /** The little wooden bar at the top edge of the screen he swings on. */
    private fun drawBar(c: Canvas) = drawBarAt(c, swHx, hangY - 86f * sc)

    private fun drawBarAt(c: Canvas, swHx: Float, y: Float) {
        fill.shader = null
        fill.color = 0x33000000
        rc.set(swHx - 34f * d, y - 1f * d, swHx + 34f * d, y + 6f * d)
        c.drawRoundRect(rc, 3f * d, 3f * d, fill)
        fill.color = 0xFF8D6E63.toInt()
        rc.set(swHx - 34f * d, y - 4f * d, swHx + 34f * d, y + 2.5f * d)
        c.drawRoundRect(rc, 3f * d, 3f * d, fill)
        fill.color = 0x55FFFFFF
        rc.set(swHx - 31f * d, y - 3f * d, swHx + 31f * d, y - 1.2f * d)
        c.drawRoundRect(rc, 1.5f * d, 1.5f * d, fill)
    }

    private fun drawShadow(c: Canvas, x: Float, y: Float, h: Float, scl: Float) {
        val sh = 1f / (1f + max(0f, h) / (80f * d))
        fill.color = 0x33000000
        val sw = 17f * sc * scl * sh
        rc.set(x - sw, y - 3f * d, x + sw, y + 3f * d)
        c.drawOval(rc, fill)
    }

    /** The rival monkey: the hero's drawing code, run with the rival's pose and golden skin. */
    private fun drawRival(c: Canvas) {
        snapTo(sv)
        val oHop = hop
        val oItem = item
        val oShades = shades
        val oScale = drawScale
        val oSkin = skin
        snapFrom(mb)
        hop = 0f
        item = 0
        shades = false
        drawScale = 1f
        skin = rival
        drawMonkey(c)
        skin = oSkin
        drawScale = oScale
        shades = oShades
        item = oItem
        hop = oHop
        snapFrom(sv)
    }

    /** The cartoon dust cloud of the fight: a big soft one behind them and a few puffs in front. */
    private fun drawCloud(c: Canvas, front: Boolean) {
        val a = brCloud
        val n = if (front) 4 else 7
        for (i in 0 until n) {
            val ang = brTheta * 0.6f + i * (2f * PI.toFloat() / n)
            val rr = (if (front) 20f else 26f) * sc
            val px = brCx + cos(ang) * rr * 1.1f
            val py = brCy + sin(ang) * rr * 0.8f
            val rad = (if (front) 9f else 14f + 3f * sin(brTheta * 2f + i)) * sc
            fill.color = Color.argb(((if (front) 150f else 205f) * a).toInt().coerceIn(0, 255), 238, 238, 238)
            c.drawCircle(px, py, rad, fill)
        }
        if (!front) {
            fill.color = Color.argb((205f * a).toInt().coerceIn(0, 255), 250, 250, 250)
            c.drawCircle(brCx, brCy, 22f * sc, fill)
        }
    }

    /** Golden halo floating over the head of the (dead) monkey. */
    private fun drawHalo(c: Canvas) {
        val hxp = mx - facing * 41f * sc
        val hyp = my - 58f * sc - 3f * sc * sin(t * 4f)
        line.color = 0x55FFD54F
        line.strokeWidth = 6f * sc
        rc.set(hxp - 12f * sc, hyp - 3.5f * sc, hxp + 12f * sc, hyp + 3.5f * sc)
        c.drawOval(rc, line)
        line.color = 0xFFFFD54F.toInt()
        line.strokeWidth = 2.6f * sc
        c.drawOval(rc, line)
    }

    private fun drawAura(c: Canvas) {
        val cy = my - hop - lift - 52f * sc
        val r = 62f * sc * (1f + 0.05f * sin(t * 3f))
        fill.color = Color.argb((46f * aura).toInt(), 255, 224, 130)
        c.drawCircle(mx, cy, r, fill)
        fill.color = Color.argb((70f * aura).toInt(), 255, 241, 190)
        c.drawCircle(mx, cy, r * 0.68f, fill)
    }

    private fun drawBall(c: Canvas) {
        val r = 9f * d
        fill.color = 0x33000000
        val k = 1f / (1f + bz / (60f * d))
        rc.set(bx - r * k, by - 2.5f * d, bx + r * k, by + 2.5f * d)
        c.drawOval(rc, fill)
        val cy = by - bz - r
        fill.color = 0xFFFFFFFF.toInt()
        c.drawCircle(bx, cy, r, fill)
        fill.color = 0xFFEF6C00.toInt()
        c.drawCircle(bx - r * 0.25f, cy - r * 0.2f, r * 0.45f, fill)
        line.color = 0xFF37474F.toInt()
        line.strokeWidth = 1.3f * d
        c.drawCircle(bx, cy, r, line.apply { style = Paint.Style.STROKE })
    }

    private val bfUp = Path().apply {
        moveTo(0f, -1f)
        cubicTo(3f, -15f, 18f, -18f, 16f, -7f)
        cubicTo(14.5f, -2f, 7f, 0f, 0f, 1.5f)
        close()
    }
    private val bfLow = Path().apply {
        moveTo(0f, 1f)
        cubicTo(9f, 0f, 15f, 3f, 12f, 9.5f)
        cubicTo(9f, 14f, 2f, 11f, 0f, 4.5f)
        close()
    }

    private fun drawButterfly(c: Canvas) {
        val wf = 0.18f + 0.82f * abs(sin(bt * 16f))   // wings flap
        val s = d * 1.45f
        fill.shader = null
        c.save()
        c.translate(bfx, bfy)
        c.rotate(sin(bt * 3.1f) * 12f)
        // soft glow
        fill.color = 0x18FFF59D
        c.drawCircle(0f, 0f, 21f * s, fill)
        fill.color = 0x22FFF59D
        c.drawCircle(0f, 0f, 13f * s, fill)
        for (side in 0..1) {
            c.save()
            c.scale((if (side == 0) 1f else -1f) * wf * s, s)
            // lower wing: warm orange
            fill.color = 0xFFFF8A65.toInt()
            c.drawPath(bfLow, fill)
            fill.color = 0xFFFFCCBC.toInt()
            c.save(); c.scale(0.58f, 0.58f); c.translate(2f, 2.5f); c.drawPath(bfLow, fill); c.restore()
            // upper wing: violet with a light patch
            fill.color = 0xFF7E57C2.toInt()
            c.drawPath(bfUp, fill)
            fill.color = 0xFFB39DDB.toInt()
            c.save(); c.scale(0.62f, 0.62f); c.translate(3f, -2f); c.drawPath(bfUp, fill); c.restore()
            // white dots on the edge
            fill.color = 0xFFFFFFFF.toInt()
            c.drawCircle(14f, -8.5f, 1.5f, fill)
            c.drawCircle(11f, -13f, 1.2f, fill)
            c.drawCircle(9.5f, 8.5f, 1.3f, fill)
            // outline
            line.color = 0xFF311B92.toInt()
            line.strokeWidth = 0.9f
            c.drawPath(bfUp, line)
            line.color = 0xFFBF360C.toInt()
            c.drawPath(bfLow, line)
            c.restore()
        }
        // body, head and feelers
        fill.color = 0xFF3E2723.toInt()
        rc.set(-1.4f * s, -7f * s, 1.4f * s, 8f * s)
        c.drawOval(rc, fill)
        c.drawCircle(0f, -8f * s, 1.9f * s, fill)
        line.color = 0xFF3E2723.toInt()
        line.strokeWidth = 0.9f * s
        path.reset()
        path.moveTo(-0.6f * s, -9.5f * s)
        path.quadTo(-3f * s, -15f * s, -6f * s, -15.5f * s)
        c.drawPath(path, line)
        path.reset()
        path.moveTo(0.6f * s, -9.5f * s)
        path.quadTo(3f * s, -15f * s, 6f * s, -15.5f * s)
        c.drawPath(path, line)
        c.drawCircle(-6f * s, -15.5f * s, 1f * s, fill)
        c.drawCircle(6f * s, -15.5f * s, 1f * s, fill)
        c.restore()
    }

    private fun drawParticles(c: Canvas) {
        for (p in pts) {
            txtP.typeface = Typeface.DEFAULT
            txtP.textSize = p.size
            txtP.alpha = (255f * min(1f, p.life / 0.4f)).toInt().coerceIn(0, 255)
            c.drawText(p.txt, p.x, p.y, txtP)
        }
        txtP.alpha = 255
    }

    private fun drawBubble(c: Canvas) {
        val on1 = bubbleText != null && bubbleT > 0f
        val on2 = buddyOn && bub2 != null && bub2T > 0f
        if (!on1) { bubZone[0] = -1; bubRight[0] = 0 }
        if (!on2) { bubZone[1] = -1; bubRight[1] = 0 }
        if (!on1 && !on2) return
        computeZones()
        var used = 0f
        val text = bubbleText
        // v134: while two monkeys talk, each bubble gets its speaker's colour (red = hero, blue = rival)
        val duo = act == Act.BRAWL
        if (on1 && text != null) {
            val headTop = my - hop - lift - 126f * sc * drawScale
            used = bubbleBox(
                c, text, bubbleT, bubbleDur, mx, headTop, 0f,
                if (duo) 0xFFFFE4E4.toInt() else 0xFFFFFFFF.toInt(), if (duo) hero.tie else 0,
                if (duo) 0xFF8E1B1B.toInt() else 0xFF263238.toInt()
            ) + 4f * d
        }
        val text2 = bub2
        if (on2 && text2 != null) {
            val headTop = mb.y - mb.lift - 126f * sc
            // when both are talking the rival's bubble goes above the hero's
            bubbleBox(
                c, text2, bub2T, bub2Dur, mb.x, headTop, if (on1) used else 0f,
                0xFFDCEBFF.toInt(), rival.tie, 0xFF0D3C87.toInt(), 1
            )
        }
    }

    // The three free areas where speech bubbles may appear (they never touch a button):
    // left of the connect button, right of it, and the strip above it between the two corner icons.
    private val zL = RectF()
    private val zR = RectF()
    private val zTRect = RectF()
    private var zonesOk = false
    private val bubZone = intArrayOf(-1, -1)   // latched zone per speaker: 0 left column, 1 right column, 2 top strip
    private val bubRight = intArrayOf(0, 0)     // latched side of the bubble in the top strip: 1 = right of him, -1 = left
    private val tp = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG)

    private fun computeZones() {
        zonesOk = false
        val r = try { avoidProvider?.invoke() } catch (_: Throwable) { null } ?: return
        if (r.width() <= 0f || r.height() <= 0f) return
        val m = 4f * d
        zL.set(m, r.top, r.left - m, maxY())
        zR.set(r.right + m, r.top, vw - m, maxY())
        // top strip: between the corner icons (or just over the button when the icons are not found)
        var l = r.left
        var rt = r.right
        try {
            val hs = hangers?.invoke()?.mapNotNull { rectOf(it) } ?: emptyList()
            val lh = hs.filter { it.centerX() < vw / 2f }.maxByOrNull { it.right }
            val rh = hs.filter { it.centerX() >= vw / 2f }.minByOrNull { it.left }
            if (lh != null) l = lh.right + m
            if (rh != null) rt = rh.left - m
        } catch (_: Throwable) {}
        zTRect.set(l, 6f * d, max(rt, l + 40f * d), max(r.top - m, 6f * d + 30f * d))
        zonesOk = true
    }

    /** Draws a wrapped speech bubble in the free zone of the monkey; returns its height (for stacking). */
    private fun bubbleBox(
        c: Canvas, text: String, left: Float, dur: Float, ax: Float, headTop: Float, yOff: Float,
        bg: Int = 0xFFFFFFFF.toInt(), border: Int = 0, ink: Int = 0xFF263238.toInt(), slot: Int = 0
    ): Float {
        val fadeIn = min(1f, (dur - left) / 0.15f)
        val fadeOut = min(1f, left / 0.3f)
        val a = min(fadeIn, fadeOut).coerceIn(0f, 1f)
        val r = try { avoidProvider?.invoke() } catch (_: Throwable) { null }

        // which zone: the column he is standing in, or the top strip when he is above the button
        // v185: the zone is "latched" with a margin, so while he walks past the button the bubble does not
        // jump back and forth between the left column, the top strip and the right column.
        var zone: RectF? = null
        if (zonesOk && r != null) {
            val okL = zL.width() > 44f * d
            val okR = zR.width() > 44f * d
            val hy = 44f * d
            val want = when {
                ax < r.left && okL -> 0
                ax > r.right && okR -> 1
                else -> 2
            }
            val key = bubZone[slot]
            val keep = when (key) {
                0 -> okL && ax < r.left + hy
                1 -> okR && ax > r.right - hy
                2 -> ax > r.left - hy && ax < r.right + hy || (!okL && !okR)
                else -> false
            }
            bubZone[slot] = if (keep) key else want
            zone = when (bubZone[slot]) { 0 -> zL; 1 -> zR; else -> zTRect }
        } else {
            bubZone[slot] = -1
        }
        val narrow = zone != null && zone !== zTRect
        tp.typeface = Typeface.DEFAULT_BOLD
        tp.textSize = (if (narrow) 11.5f else 12.5f) * d
        val padX = 9f * d
        val padY = 7f * d
        val natural = tp.measureText(text)
        val maxW = if (zone != null) max(24f * d, zone.width() - 2f * padX) else vw - 40f * d
        val lw = max(10f, min(natural + 2f, maxW)).toInt()
        val lay = android.text.StaticLayout.Builder.obtain(text, 0, text.length, tp, lw)
            .setAlignment(android.text.Layout.Alignment.ALIGN_CENTER).setIncludePad(false).build()
        var tw = 0f
        for (i in 0 until lay.lineCount) tw = max(tw, lay.getLineWidth(i))
        val bw = tw + 2f * padX
        val bh = lay.height + 2f * padY

        var cx: Float
        var top: Float
        var tail = false
        var sideDir = 0   // -1: little tail on the left edge of the bubble, 1: on the right edge (he is on that side)
        if (zone == null) {
            cx = ax.coerceIn(bw / 2f + 6f * d, max(vw - bw / 2f - 6f * d, bw / 2f + 6f * d))
            top = max(4f * d, headTop - bh - 8f * d - yOff)
            tail = true
        } else {
            val wantTop = headTop - bh - 8f * d - yOff
            if (zone !== zTRect && wantTop < zone.top) {
                // not enough room above his head inside the column: use the free strip at the top instead
                zone = zTRect
                bubZone[slot] = 2
            }
            if (zone === zTRect) {
                // he is up high (swinging from an icon, bouncing on the button): the bubble goes right
                // next to him, on the side with more room, at head height
                // the side only changes when he is clearly past the middle of the screen
                val mid = vw / 2f
                if (bubRight[slot] == 0) bubRight[slot] = if (ax < mid) 1 else -1
                else if (bubRight[slot] > 0 && ax > mid + 50f * d) bubRight[slot] = -1
                else if (bubRight[slot] < 0 && ax < mid - 50f * d) bubRight[slot] = 1
                val toRight = bubRight[slot] > 0
                val half = bw / 2f
                cx = (if (toRight) ax + 26f * d + half else ax - 26f * d - half)
                    .coerceIn(half + 4f * d, max(vw - half - 4f * d, half + 4f * d))
                val headMid = headTop + 30f * sc
                top = max(4f * d, headMid - bh / 2f - yOff)
                sideDir = if (toRight) -1 else 1
            } else {
                cx = ax.coerceIn(zone.left + bw / 2f, max(zone.right - bw / 2f, zone.left + bw / 2f))
                top = wantTop.coerceIn(zone.top, max(zone.bottom - bh, zone.top))
                tail = abs((top + bh + 8f * d) - (headTop - yOff)) < 3f * d
            }
        }

        fill.color = Color.argb((22f * a).toInt(), 0, 0, 0)
        rc.set(cx - bw / 2f - 1f * d, top + 1f * d, cx + bw / 2f + 3f * d, top + bh + 5f * d)
        c.drawRoundRect(rc, 16f * d, 16f * d, fill)
        fill.color = Color.argb((38f * a).toInt(), 0, 0, 0)
        rc.set(cx - bw / 2f + 1f * d, top + 2f * d, cx + bw / 2f + 1f * d, top + bh + 2.5f * d)
        c.drawRoundRect(rc, 15f * d, 15f * d, fill)
        val fcx = cx
        val ftop = top
        val fTail = tail
        val fSide = sideDir
        // pass 0 = coloured outline (a little bigger), pass 1 = the filled box; no border colour = just the box
        for (pass in 0..1) {
            val inf = if (pass == 0) (if (border == 0) 1.1f * d else 2.2f * d) else 0f
            fill.color = withAlpha(if (pass == 0) (if (border == 0) 0xFFC9D6DC.toInt() else border) else bg, a)
            rc.set(fcx - bw / 2f - inf, ftop - inf, fcx + bw / 2f + inf, ftop + bh + inf)
            c.drawRoundRect(rc, 15f * d + inf, 15f * d + inf, fill)
            if (fSide != 0) {
                val ex = if (fSide < 0) fcx - bw / 2f else fcx + bw / 2f
                val ey = ftop + bh / 2f
                path.reset()
                path.moveTo(ex - fSide * 1f * d, ey - 6f * d - inf)
                path.lineTo(ex + fSide * (7f * d + inf * 1.4f), ey)
                path.lineTo(ex - fSide * 1f * d, ey + 6f * d + inf)
                path.close()
                c.drawPath(path, fill)
            }
            if (fTail) {
                val tailLo = fcx - bw / 2f + 12f * d
                val tailHi = fcx + bw / 2f - 12f * d
                val tailX = if (tailLo <= tailHi) ax.coerceIn(tailLo, tailHi) else fcx
                path.reset()
                path.moveTo(tailX - 6f * d - inf, ftop + bh - 1f * d)
                path.lineTo(tailX, ftop + bh + 7f * d + inf * 1.4f)
                path.lineTo(tailX + 6f * d + inf, ftop + bh - 1f * d)
                path.close()
                c.drawPath(path, fill)
            }
        }
        tp.color = withAlpha(ink, a)
        c.save()
        c.translate(cx - lay.width / 2f, top + padY)
        lay.draw(c)
        c.restore()
        return bh
    }

    private fun withAlpha(col: Int, a: Float): Int =
        Color.argb((255f * a).toInt().coerceIn(0, 255), Color.red(col), Color.green(col), Color.blue(col))

    private fun drawMonkey(c: Canvas) {
        val s = sc * drawScale
        if (s <= 0.001f) return
        c.save()
        c.translate(mx, my - hop - lift)
        c.scale(s * facing * spinX, s * squash)
        c.rotate(tilt, 0f, pivotY)

        // slender tail with a lighter tuft
        line.style = Paint.Style.STROKE
        line.color = cDark
        line.strokeWidth = 5f
        val wv = sin(tailT * 4f) * 8f
        val tex = -26f + wv * 0.4f
        path.reset()
        path.moveTo(-9f, -34f)
        path.cubicTo(-36f, -30f + wv, -40f, -60f, tex, -66f)
        c.drawPath(path, line)
        fill.color = cBrown
        c.drawCircle(tex, -66f, 4.4f, fill)
        fill.color = skin.light
        c.drawCircle(tex - 1f, -67f, 2f, fill)

        // legs (with sneakers)
        drawLeg(c, -7f, footA, liftA)
        drawLeg(c, 7f, footB, liftB)

        c.translate(0f, -bob)

        // slim body + belly, both shaded
        fill.shader = skin.body
        rc.set(-14f, -68f, 14f, -24f)
        c.drawOval(rc, fill)
        fill.shader = skin.belly
        rc.set(-8.5f, -63f, 8.5f, -30f)
        c.drawOval(rc, fill)
        fill.shader = null

        // arms
        drawArm(c, -13f, armA1, 27f)
        drawArm(c, 13f, armA2, armLen2)

        // ears
        fill.color = cBrown
        c.drawCircle(-23f, -88f, 10f, fill)
        c.drawCircle(23f, -88f, 10f, fill)
        fill.color = 0xFFF2B696.toInt()
        c.drawCircle(-23f, -88f, 6f, fill)
        c.drawCircle(23f, -88f, 6f, fill)
        fill.color = 0x33FFFFFF
        c.drawCircle(-24.5f, -90f, 2.4f, fill)
        c.drawCircle(21.5f, -90f, 2.4f, fill)

        // head (shaded) + soft rim light
        fill.shader = skin.head
        c.drawCircle(0f, -86f, 23f, fill)
        fill.shader = null
        line.color = 0x44FFFFFF
        line.strokeWidth = 2.2f
        rc.set(-20.5f, -106f, 20.5f, -66f)
        c.drawArc(rc, 200f, 55f, false, line)

        // cool swept-back quiff
        fill.color = cDark
        path.reset()
        path.moveTo(-17f, -101f)
        path.cubicTo(-19f, -118f, 2f, -127f, 19f, -116f)
        path.cubicTo(23f, -113f, 23f, -108f, 19f, -103f)
        path.cubicTo(10f, -110f, -4f, -107f, -17f, -101f)
        path.close()
        c.drawPath(path, fill)
        line.color = 0x66FFFFFF
        line.strokeWidth = 1.8f
        path.reset()
        path.moveTo(-10f, -113f)
        path.quadTo(0f, -121f, 11f, -116.5f)
        c.drawPath(path, line)

        drawFace(c)
        drawBowTie(c)
        if (item == 1) {
            // v132: the eating arm and the banana are drawn over the face so they are always visible
            drawArm(c, 13f, armA2, armLen2)
            drawBanana(c)
        }

        c.restore()
        line.style = Paint.Style.STROKE
    }

    private fun drawBowTie(c: Canvas) {
        fill.color = skin.tie
        path.reset()
        path.moveTo(0f, -59f)
        path.lineTo(-11.5f, -65f)
        path.lineTo(-11.5f, -53f)
        path.close()
        c.drawPath(path, fill)
        path.reset()
        path.moveTo(0f, -59f)
        path.lineTo(11.5f, -65f)
        path.lineTo(11.5f, -53f)
        path.close()
        c.drawPath(path, fill)
        fill.color = skin.tieDark
        rc.set(-3.2f, -62.8f, 3.2f, -55.2f)
        c.drawRoundRect(rc, 2.2f, 2.2f, fill)
        line.color = 0x66FFFFFF
        line.strokeWidth = 1.1f
        c.drawLine(-9.5f, -62.5f, -4.5f, -59.8f, line)
        c.drawLine(9.5f, -62.5f, 4.5f, -59.8f, line)
    }

    private fun drawLeg(c: Canvas, hx: Float, foot: Float, lf: Float) {
        line.color = cDark
        line.strokeWidth = 7.5f
        val fx = hx + foot
        c.drawLine(hx, -30f, fx, -lf - 6f, line)
        // white sneaker with a coloured toe cap and a dark sole
        fill.color = 0xFFFFFFFF.toInt()
        rc.set(fx - 7f, -lf - 10f, fx + 11f, -lf + 1.5f)
        c.drawRoundRect(rc, 5f, 5f, fill)
        fill.color = skin.tie
        rc.set(fx + 3f, -lf - 8f, fx + 11f, -lf + 0.5f)
        c.drawRoundRect(rc, 4f, 4f, fill)
        fill.color = 0xFF263238.toInt()
        rc.set(fx - 7.5f, -lf - 1.5f, fx + 11.5f, -lf + 2f)
        c.drawRoundRect(rc, 2f, 2f, fill)
    }

    private fun drawArm(c: Canvas, sx: Float, ang: Float, len: Float) {
        val a = ang * (PI.toFloat() / 180f)
        val ex = sx + sin(a) * len
        val ey = -60f + cos(a) * len
        line.color = cDark
        line.strokeWidth = 6.2f
        c.drawLine(sx, -60f, ex, ey, line)
        if (act == Act.PUNCH && sub >= 1) {
            fill.color = 0xFFD32F2F.toInt()
            c.drawCircle(ex, ey, 7.4f, fill)
            fill.color = 0x66FFFFFF
            c.drawCircle(ex - 1.6f, ey - 2.2f, 2.8f, fill)
            fill.color = 0xFFFFFFFF.toInt()
            c.drawRect(ex - 3.5f, ey - 9.5f, ex + 3.5f, ey - 6.6f, fill)
        } else {
            fill.color = cTan
            c.drawCircle(ex, ey, 4.8f, fill)
            fill.color = 0x22000000
            c.drawCircle(ex + 1.2f, ey + 1.4f, 2.4f, fill)
        }
        handX = ex
        handY = ey
    }

    private fun drawBanana(c: Canvas) {
        val len = 30f * (1f - eaten)
        c.save()
        c.translate(handX, handY)
        c.rotate(banRot)
        // the peel hangs down from his fist (stays in his hand after the last bite)
        line.color = 0xFFFFC107.toInt()
        line.strokeWidth = 4f
        c.drawLine(0f, -2f, -7f, 7f, line)
        c.drawLine(0f, -2f, 7f, 7f, line)
        c.drawLine(0f, -2f, 0f, 9f, line)
        if (len > 1f) {
            // the peeled fruit
            line.color = 0xFFFFF3B0.toInt()
            line.strokeWidth = 8.5f
            path.reset()
            path.moveTo(0f, -2f)
            path.quadTo(5f, -2f - len * 0.5f, 2f, -2f - len)
            c.drawPath(path, line)
            line.color = 0xFFFFD54F.toInt()
            line.strokeWidth = 9.5f
            c.drawLine(0f, -2f, 0f, -8f, line)
        }
        // his fist on top
        fill.color = cTan
        c.drawCircle(0f, -1f, 4.8f, fill)
        c.restore()
    }

    private fun drawEye(c: Canvas, ex: Float, ey: Float, side: Float) {
        val blink = blinkOn > 0f
        when {
            eyes == 4 -> {
                // knocked out: X eyes
                line.color = cInk
                line.strokeWidth = 2.2f
                c.drawLine(ex - 3.6f, ey - 3.6f, ex + 3.6f, ey + 3.6f, line)
                c.drawLine(ex - 3.6f, ey + 3.6f, ex + 3.6f, ey - 3.6f, line)
            }
            eyes == 3 -> {
                fill.color = 0xFFFFFFFF.toInt()
                c.drawCircle(ex, ey, 5.4f, fill)
                fill.color = cInk
                c.drawCircle(ex + lookX * 1.2f, ey, 2.8f, fill)
                fill.color = 0xFFFFFFFF.toInt()
                c.drawCircle(ex + lookX * 1.2f + 0.9f, ey - 1f, 0.9f, fill)
            }
            eyes == 2 || blink -> {
                line.color = cInk
                line.strokeWidth = 2.2f
                c.drawLine(ex - 3.6f, ey, ex + 3.6f, ey, line)
            }
            eyes == 1 -> {
                line.color = cInk
                line.strokeWidth = 2.4f
                rc.set(ex - 4f, ey - 3f, ex + 4f, ey + 4f)
                c.drawArc(rc, 200f, 140f, false, line)
            }
            else -> {
                // big shiny eyes: white, amber iris, pupil, two highlights and a confident upper lid
                val lx = lookX * 1.4f
                fill.color = 0xFFFFFFFF.toInt()
                rc.set(ex - 4.6f, ey - 5.6f, ex + 4.6f, ey + 5f)
                c.drawOval(rc, fill)
                fill.color = 0xFF6D3F1E.toInt()
                c.drawCircle(ex + lx, ey, 3.7f, fill)
                fill.color = 0xFFE0A030.toInt()
                c.drawCircle(ex + lx, ey + 0.9f, 2.5f, fill)
                fill.color = cInk
                c.drawCircle(ex + lx, ey - 0.2f, 2f, fill)
                fill.color = 0xFFFFFFFF.toInt()
                c.drawCircle(ex + lx + 1.2f, ey - 1.6f, 1.2f, fill)
                c.drawCircle(ex + lx - 1.2f, ey + 1.6f, 0.6f, fill)
                line.color = cInk
                line.strokeWidth = 1.6f
                rc.set(ex - 4.8f, ey - 6f, ex + 4.8f, ey + 4f)
                c.drawArc(rc, 195f, 150f, false, line)
            }
        }
        // eyebrows: thick and straight-ish (a guy), slanted down when angry
        if (!(eyes == 2 || blink)) {
            line.color = cInk
            if (angry) {
                line.strokeWidth = 2.8f
                c.drawLine(ex + side * 4.8f, ey - 11.6f, ex - side * 3.8f, ey - 6.8f, line)
            } else {
                line.strokeWidth = 2.4f
                val up = if (eyes == 3) 2.5f else 0f
                rc.set(ex - 4.4f, ey - 11.2f - up, ex + 4.4f, ey - 6.4f - up)
                c.drawArc(rc, 200f, 140f, false, line)
            }
        }
    }

    private fun drawFace(c: Canvas) {
        val fs = 2f + lookX * 2.5f   // the face looks a little towards the walking direction
        fill.shader = skin.face
        c.drawCircle(-8f + fs, -88f, 12.5f, fill)
        c.drawCircle(8f + fs, -88f, 12.5f, fill)
        rc.set(-12f + fs, -84f, 12f + fs, -66f)
        c.drawOval(rc, fill)
        fill.shader = null

        drawEye(c, -8.5f + fs, -90f, -1f)
        drawEye(c, 8.5f + fs, -90f, 1f)

        if (shades) {
            fill.color = 0xFF111111.toInt()
            rc.set(-14.5f + fs, -94.5f, -2.5f + fs, -85f)
            c.drawRoundRect(rc, 3f, 3f, fill)
            rc.set(2.5f + fs, -94.5f, 14.5f + fs, -85f)
            c.drawRoundRect(rc, 3f, 3f, fill)
            line.color = 0xFF111111.toInt()
            line.strokeWidth = 2f
            c.drawLine(-2.5f + fs, -91f, 2.5f + fs, -91f, line)
            fill.color = 0x66FFFFFF
            c.drawCircle(-10.5f + fs, -92.3f, 1.4f, fill)
            c.drawCircle(6.5f + fs, -92.3f, 1.4f, fill)
        }

        // rosy cheek on one side, a tough-guy band-aid on the other
        fill.color = 0x55FF7A93
        c.drawCircle(14.5f + fs, -80.5f, 3.6f, fill)
        c.save()
        c.rotate(-28f, -14f + fs, -79.5f)
        fill.color = 0xFFF1C7A0.toInt()
        rc.set(-19f + fs, -82f, -9f + fs, -77f)
        c.drawRoundRect(rc, 2.2f, 2.2f, fill)
        fill.color = 0x33000000
        rc.set(-16.2f + fs, -81.4f, -11.8f + fs, -77.6f)
        c.drawRect(rc, fill)
        c.restore()

        // little bean nose
        fill.color = cInk
        rc.set(-2.6f + fs, -81.5f, 2.6f + fs, -78.5f)
        c.drawOval(rc, fill)

        if (mouth > 0.15f) {
            val oh = 2.5f + 8f * mouth
            fill.color = 0xFF6B2A2A.toInt()
            rc.set(-4f + fs, -77f, 4f + fs, -77f + oh)
            c.drawOval(rc, fill)
            if (mouth > 0.5f) {
                fill.color = 0xFFE57373.toInt()
                rc.set(-2.5f + fs, -77f + oh - 4f, 2.5f + fs, -77f + oh - 0.4f)
                c.drawOval(rc, fill)
            }
            if (eyes == 4) {
                // tongue hanging out
                fill.color = 0xFFEF6C8A.toInt()
                rc.set(-2f + fs, -77f + oh - 3f, 3.2f + fs, -77f + oh + 3.5f)
                c.drawOval(rc, fill)
            }
        } else if (angry) {
            line.color = cInk
            line.strokeWidth = 1.8f
            rc.set(-5f + fs, -75.5f, 5f + fs, -69.5f)
            c.drawArc(rc, 200f, 140f, false, line)
        } else {
            // cool smirk: the smile is lifted on one side
            line.color = cInk
            line.strokeWidth = 1.9f
            path.reset()
            path.moveTo(-4.5f + fs, -75.3f)
            path.quadTo(1f + fs, -72.2f, 6.8f + fs, -77.6f)
            c.drawPath(path, line)
        }
    }
}
